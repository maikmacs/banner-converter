(function (lib, img, cjs, ss) {

var p; // shortcut to reference prototypes
lib.webFontTxtFilters = {}; 

// library properties:
lib.properties = {
	width: 300,
	height: 600,
	fps: 30,
	color: "#FFFFFF",
	webfonts: {},
	manifest: [
		{src:"images/multiva_fondo_IVR_HB.jpg", id:"multiva_fondo_IVR_HB"}
	]
};



lib.webfontAvailable = function(family) { 
	lib.properties.webfonts[family] = true;
	var txtFilters = lib.webFontTxtFilters && lib.webFontTxtFilters[family] || [];
	for(var f = 0; f < txtFilters.length; ++f) {
		txtFilters[f].updateCache();
	}
};
// symbols:



(lib.multiva_fondo_IVR_HB = function() {
	this.initialize(img.multiva_fondo_IVR_HB);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,470,600);


(lib.Símbolo15 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AhCC9IAii9IhFAAIAAi8IDKAAIAACnIg+DSg");
	this.shape.setTransform(138,20.7,0.234,0.234);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AjrFcIAAiZIClAAIAACZQAABOBGAAQBHAAABhOIAAiCQgBhSiYhvQiahtAAidIAAhrQAAjwDrAAQDsAAAADwIAACaIikAAIAAiaQgBhMhHgBIAAAAQhHAAABBNIAABoQAABMCYBuQCaBtAACZIAACQQAADxjsAAQjrgBAAjwg");
	this.shape_1.setTransform(127,7.3,0.234,0.234);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AjrFcIAAq4QAAjwDrAAQDsAAAADwIAAK4QAADwjsABQjrAAAAjxgAhGlcIAAK4QAABOBGAAQBHAAAAhOIAAq4QAAhMhHgBIAAAAQhGAAAABNg");
	this.shape_2.setTransform(112.9,7.3,0.234,0.234);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("ABII6IiVp/IAAJ/IieAAIAAx0IClAAICZKVIAAqVICZAAIAAR0g");
	this.shape_3.setTransform(98.6,7.3,0.234,0.234);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("ABMI6IiSn2IgVADIAAHzIilAAIAAx0IDwAAQDZACAADvIAACrQAACXiBAuIC5ITgAhbhQIAmAAQAiAAANgFQArgSAAg3IAAirQAAhOhGAAIg6AAg");
	this.shape_4.setTransform(84.9,7.3,0.234,0.234);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AjUI6IAAx0IGpAAIAACjIkFAAIAAFHIDgAAIAAChIjgAAIAAFHIEFAAIAACig");
	this.shape_5.setTransform(71,7.3,0.234,0.234);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AjrI6IAAx0ID8AAQDbACAADvIAAKUQAADvjmAAgAhGGYIBGAAQBHAAAAhNIAAqUQAAhOhHAAIhGAAg");
	this.shape_6.setTransform(57.2,7.3,0.234,0.234);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#000000").s().p("ABHI6IiUp/IAAJ/IieAAIAAx0ICkAAICbKVIAAqVICYAAIAAR0g");
	this.shape_7.setTransform(42.7,7.3,0.234,0.234);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#000000").s().p("AjUI6IAAx0IGpAAIAACjIkEAAIAAFHIDgAAIAAChIjgAAIAAFHIEEAAIAACig");
	this.shape_8.setTransform(29.3,7.3,0.234,0.234);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#000000").s().p("ABMI6IiSn2IgVADIAAHzIilAAIAAx0IDwAAQDZACAADvIAACrQAACXiCAuIC6ITgAhbhQIAmAAQAiAAANgFQArgSAAg3IAAirQAAhOhGAAIg6AAg");
	this.shape_9.setTransform(16.1,7.3,0.234,0.234);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#000000").s().p("AjkI6IAAx0IDtAAQDcACAADvIAACrQAACvidA0QgmAMhGAAIgbAAIAAHpgAg/hQIAmAAQAgAAAMgFQAtgSAAg3IAAirQAAhOhFAAIg6AAg");
	this.shape_10.setTransform(1.9,7.3,0.234,0.234);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#000000").s().p("ABMI6IiSn2IgVADIAAHzIilAAIAAx0IDwAAQDZACAADvIAACrQAACXiCAuIC6ITgAhbhQIAmAAQAiAAANgFQArgSAAg3IAAirQAAhOhGAAIg6AAg");
	this.shape_11.setTransform(-11.7,7.3,0.234,0.234);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#000000").s().p("AjrFcIAAq4QAAjwDrAAQDsAAAADwIAAK4QAADwjsABQjrAAAAjxgAhGlcIAAK4QgBBOBHAAQBIAAAAhOIAAq4QgBhMhHgBIAAAAQhGAAAABNg");
	this.shape_12.setTransform(-26.5,7.3,0.234,0.234);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#000000").s().p("AjrFcIAAiZIClAAIAACZQgBBOBHAAQBHAAABhOIAAiCQAAhSiZhvQiahsAAieIAAhrQAAjwDrAAQDsAAAADwIAACaIikAAIAAiaQgBhMhHgBIAAAAQhHAAABBNIAABoQAABMCYBuQCaBtAACZIAACQQAADxjsAAQjrgBAAjwg");
	this.shape_13.setTransform(-40.5,7.3,0.234,0.234);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#000000").s().p("ABzI6IgfjyIinAAIggDyIimAAIA1mTIB0rhIDgAAIB0LfIA2GVgAg+ClIB8AAIg+nYg");
	this.shape_14.setTransform(-61.6,7.3,0.234,0.234);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#000000").s().p("ABMI6IiSn2IgVADIAAHzIilAAIAAx0IDwAAQDaACAADvIAACrQAACXiCAuIC5ITgAhbhQIAmAAQAiAAANgFQArgSAAg3IAAirQAAhOhGAAIg6AAg");
	this.shape_15.setTransform(-75.2,7.3,0.234,0.234);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#000000").s().p("AjrFcIAAq4QAAjwDrAAQDsAAAADwIAACaIilAAIAAiaQAAhMhHgBIAAAAQhHAAABBNIAAK4QAABOBGAAQBHAAAAhOIAAkLIhRAAIAAihID2AAIAAGsQAADwjsABQjrAAAAjxg");
	this.shape_16.setTransform(-90,7.3,0.234,0.234);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#000000").s().p("AjrFcIAAq4QAAjwDrAAQDsAAAADwIAAK4QAADwjsABQjrAAAAjxgAhGlcIAAK4QAABOBGAAQBHAAAAhOIAAq4QAAhMhHgBIAAAAQhGAAAABNg");
	this.shape_17.setTransform(-104.1,7.3,0.234,0.234);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#000000").s().p("AjUI6IAAx0IClAAIAAPSIEEAAIAACig");
	this.shape_18.setTransform(-116.6,7.3,0.234,0.234);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#000000").s().p("AjUI6IAAxzIGpAAIAACiIkFAAIAAFHIDhAAIAAChIjhAAIAAFHIEFAAIAACig");
	this.shape_19.setTransform(135.9,-29.7,0.234,0.234);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#000000").s().p("ABNI6IiTn2IgVADIAAHzIikAAIAAxzIDvAAQDaAAAADwIAACsQAACWiDAuIC6ITgAhbhQIAmAAQAiAAANgFQArgSAAg2IAAisQAAhOhGAAIg6AAg");
	this.shape_20.setTransform(122.8,-29.7,0.234,0.234);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#000000").s().p("AjkI6IAAxzIDuAAQDbAAAADwIAACsQAACvidAzQgmAMhHAAIgbAAIAAHpgAhAhQIAnAAQAgAAANgFQAsgSABg2IAAisQAAhOhGAAIg7AAg");
	this.shape_21.setTransform(108.5,-29.7,0.234,0.234);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#000000").s().p("ADHI6IAAp+IiNJ+IhtAAIiRp+IAAJ+IigAAIAAxzIClAAIDAMMIC/sMIClAAIAARzg");
	this.shape_22.setTransform(91.3,-29.7,0.234,0.234);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#000000").s().p("AjUI6IAAxzIGpAAIAACiIkEAAIAAFHIDgAAIAAChIjgAAIAAFHIEEAAIAACig");
	this.shape_23.setTransform(75.1,-29.7,0.234,0.234);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#000000").s().p("AhRI6IAAxzICjAAIAARzg");
	this.shape_24.setTransform(64.6,-29.7,0.234,0.234);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#000000").s().p("AjrFdIAAiaIClAAIAACaQAABNBGAAQBIAAAAhNIAAiDQAAhSiZhvQiahtAAidIAAhrQAAjwDrABQDsgBAADwIAACZIikAAIAAiZQAAhNhIAAIAAAAQhGgBAABOIAABoQAABLCYBwQCaBsAACZIAACRQAADwjsAAQjrAAAAjwg");
	this.shape_25.setTransform(53.8,-29.7,0.234,0.234);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#000000").s().p("ABzI6IgfjyIinAAIggDyIimAAIA1mTIB1rgIDfAAIB1LeIA1GVgAg9ClIB7AAIg+nZg");
	this.shape_26.setTransform(32.7,-29.7,0.234,0.234);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#000000").s().p("AhaKaIAAxzICiAAIAARzgAhooGIBSiTIB/AAIh2CTg");
	this.shape_27.setTransform(22,-32,0.234,0.234);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#000000").s().p("AjrFdIAAq5QAAjwDrABQDsgBAADwIAACZIikAAIAAiZQAAhNhIAAIAAAAQhGgBAABOIAAK5QAABNBGAAQBHAAABhNIAAkNIhRAAIAAihID1AAIAAGuQAADwjsAAQjrAAAAjwg");
	this.shape_28.setTransform(11,-29.7,0.234,0.234);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#000000").s().p("AjrFdIAAq5QAAjwDrABQDsgBAADwIAAK5QAADwjsAAQjrAAAAjwgAhHlcIAAK5QAABNBHAAQBHAAAAhNIAAq5QAAhNhHAAIAAAAQhGgBgBBOg");
	this.shape_29.setTransform(-3,-29.7,0.234,0.234);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#000000").s().p("AjUI6IAAxzICkAAIAAPRIEFAAIAACig");
	this.shape_30.setTransform(-15.6,-29.7,0.234,0.234);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#000000").s().p("AjrFdIAAq5QAAjwDrABQDsgBAADwIAAK5QAADwjsAAQjrAAAAjwgAhGlcIAAK5QAABNBGAAQBHAAAAhNIAAq5QAAhNhHAAIAAAAQhGgBAABOg");
	this.shape_31.setTransform(-29.4,-29.7,0.234,0.234);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#000000").s().p("ABII6IiVp/IAAJ/IieAAIAAxzIClAAICZKUIAAqUICZAAIAARzg");
	this.shape_32.setTransform(-43.7,-29.7,0.234,0.234);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#000000").s().p("AjrFdIAAq5QAAjwDrABQDsgBAADwIAACZIilAAIAAiZQABhNhIAAIAAAAQhHgBAABOIAAK5QAABNBHAAQBHAAAAhNIAAiaIClAAIAACaQAADwjsAAQjrAAAAjwg");
	this.shape_33.setTransform(-57.9,-29.7,0.234,0.234);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#000000").s().p("AjUI6IAAxzIGpAAIAACiIkEAAIAAFHIDfAAIAAChIjfAAIAAFHIEEAAIAACig");
	this.shape_34.setTransform(-71,-29.7,0.234,0.234);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#000000").s().p("AhRI6IAAvRIiaAAIAAiiIHXAAIAACiIiaAAIAAPRg");
	this.shape_35.setTransform(-84,-29.7,0.234,0.234);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#000000").s().p("AB0I6IghjyIilAAIghDyIimAAIA2mTIB0rgIDgAAIBzLeIA2GVgAg+ClIB8AAIg+nZg");
	this.shape_36.setTransform(-104.2,-29.7,0.234,0.234);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#000000").s().p("AjUI6IAAxzIClAAIAAPRIEEAAIAACig");
	this.shape_37.setTransform(-116.9,-29.7,0.234,0.234);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#000000").s().p("Ag4A5IAAhxIBxAAIAABxg");
	this.shape_38.setTransform(137.1,42.4,0.22,0.22);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#000000").s().p("AiNDSIAAmkQAAiRCNAAQCOAAAACRIAAGkQAACSiOgBQiNABAAiSgAgqjSIAAGkQAAAvAqAAQArAAAAgvIAAmkQAAgugrAAIAAAAQgqAAAAAug");
	this.shape_39.setTransform(130.9,36.1,0.22,0.22);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#000000").s().p("AiNDSIAAmkQAAiRCNAAQCOAAAACRIAABeIhjAAIAAheQAAgugrAAIAAAAQgqAAAAAuIAAGkQAAAvAqAAQArAAAAgvIAAhcIBjAAIAABcQAACSiOgBQiNABAAiSg");
	this.shape_40.setTransform(123,36.1,0.22,0.22);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#000000").s().p("AArFYIhZmBIAAGBIhgAAIAAqwIBkAAIBcGPIAAmPIBcAAIAAKwg");
	this.shape_41.setTransform(114.8,36.1,0.22,0.22);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#000000").s().p("ABFFYIgTiSIhjAAIgUCSIhkAAIAgjzIBHm9ICGAAIBGG8IAgD0gAglBkIBLAAIgmkdg");
	this.shape_42.setTransform(106.6,36.1,0.22,0.22);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#000000").s().p("AiOFYIAAqwICYAAQCEABABCRIAABnQgBBFg2AaQA2AcABBDIAABpQAACQiMAAgAgqD2IAqAAQArAAAAguIAAhpQAAgggbgLQgIgDgSgBIggAAgAgqgwIAgAAQASAAAIgCQAbgMAAghIAAhnQAAgwgrAAIgqAAg");
	this.shape_43.setTransform(98.6,36.1,0.22,0.22);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#000000").s().p("AAuFYIhYkvIgMACIAAEtIhkAAIAAqwICRAAQCCABAACRIAABnQAABchOAaIBwFBgAg2gwIAWAAQAVAAAIgCQAZgMAAghIAAhnQAAgwgqAAIgiAAg");
	this.shape_44.setTransform(86.9,36.1,0.22,0.22);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#000000").s().p("AiNDSIAAmkQAAiRCNAAQCOAAAACRIAAGkQAACSiOgBQiNABAAiSgAgqjSIAAGkQAAAvAqAAQArAAAAgvIAAmkQAAgugrAAIAAAAQgqAAAAAug");
	this.shape_45.setTransform(78.5,36.1,0.22,0.22);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#000000").s().p("AiODNIAAgpIBkAAIAAApQAAAvAqAAQArAAAAgvIAAoqIBjAAIAAIqQABCRiPAAQiNAAgBiRg");
	this.shape_46.setTransform(70.3,36.2,0.22,0.22);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#000000").s().p("Ah/FYIAAqwID/AAIAABiIicAAIAADGICGAAIAABgIiGAAIAADGICcAAIAABig");
	this.shape_47.setTransform(63.5,36.1,0.22,0.22);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#000000").s().p("AB4FYIAAmAIhVGAIhBAAIhYmAIAAGAIhhAAIAAqwIBkAAIBzHXIB0nXIBjAAIAAKwg");
	this.shape_48.setTransform(53.9,36.1,0.22,0.22);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#000000").s().p("AArFYIhZmBIAAGBIhfAAIAAqwIBjAAIBcGPIAAmPIBcAAIAAKwg");
	this.shape_49.setTransform(40.1,36.1,0.22,0.22);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#000000").s().p("AiODNIAAoqIBkAAIAAIqQAAAvAqAAQArAAAAgvIAAoqIBjAAIAAIqQABCRiPAAQiNAAgBiRg");
	this.shape_50.setTransform(31.9,36.2,0.22,0.22);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#000000").s().p("AArFYIhZmBIAAGBIhfAAIAAqwIBjAAIBcGPIAAmPIBcAAIAAKwg");
	this.shape_51.setTransform(19.7,36.1,0.22,0.22);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#000000").s().p("AiAGSIAAqwIEBAAIAABiIidAAIAADEICGAAIAABiIiGAAIAADGICdAAIAABigAg5k4IAzhZIBLAAIhHBZg");
	this.shape_52.setTransform(12.1,34.8,0.22,0.22);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#000000").s().p("AgwFYIAAqwIBhAAIAAKwg");
	this.shape_53.setTransform(6.1,36.1,0.22,0.22);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#000000").s().p("AiNFYIAAqwICXAAQCEABAACRIAABnQAABFg2AaQA2AcAABDIAABpQAACQiKAAgAgqD2IAqAAQArAAAAguIAAhpQAAgggbgLQgJgDgSgBIgfAAgAgqgwIAfAAQATAAAIgCQAbgMAAghIAAhnQAAgwgrAAIgqAAg");
	this.shape_54.setTransform(0.1,36.1,0.22,0.22);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("#000000").s().p("AB4FYIAAmAIhVGAIhBAAIhYmAIAAGAIhhAAIAAqwIBkAAIBzHXIB0nXIBjAAIAAKwg");
	this.shape_55.setTransform(-9.8,36.1,0.22,0.22);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("#000000").s().p("ABGFYIgUiSIhjAAIgUCSIhkAAIAgjzIBGm9ICHAAIBGG8IAgD0gAglBkIBKAAIglkdg");
	this.shape_56.setTransform(-19.7,36.1,0.22,0.22);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("#000000").s().p("AgxFYIAApOIhcAAIAAhiIEcAAIAABiIheAAIAAJOg");
	this.shape_57.setTransform(-26.8,36.1,0.22,0.22);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("#C0E3F7").s().p("Ag4A5IAAhxIBxAAIAABxg");
	this.shape_58.setTransform(137.1,42.4,0.22,0.22);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("#C0E3F7").s().p("AiNDSIAAmkQAAiRCNAAQCOAAAACRIAAGkQAACSiOgBQiNABAAiSgAgqjSIAAGkQAAAvAqAAQArAAAAgvIAAmkQAAgugrAAIAAAAQgqAAAAAug");
	this.shape_59.setTransform(130.9,36.1,0.22,0.22);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("#C0E3F7").s().p("AiNDSIAAmkQAAiRCNAAQCOAAAACRIAABeIhjAAIAAheQAAgugrAAIAAAAQgqAAAAAuIAAGkQAAAvAqAAQArAAAAgvIAAhcIBjAAIAABcQAACSiOgBQiNABAAiSg");
	this.shape_60.setTransform(123,36.1,0.22,0.22);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("#C0E3F7").s().p("AArFYIhZmBIAAGBIhgAAIAAqwIBkAAIBcGPIAAmPIBcAAIAAKwg");
	this.shape_61.setTransform(114.8,36.1,0.22,0.22);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("#C0E3F7").s().p("ABFFYIgTiSIhjAAIgUCSIhkAAIAgjzIBHm9ICGAAIBGG8IAgD0gAglBkIBLAAIgmkdg");
	this.shape_62.setTransform(106.6,36.1,0.22,0.22);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("#C0E3F7").s().p("AiOFYIAAqwICYAAQCEABABCRIAABnQgBBFg2AaQA2AcABBDIAABpQAACQiMAAgAgqD2IAqAAQArAAAAguIAAhpQAAgggbgLQgIgDgSgBIggAAgAgqgwIAgAAQASAAAIgCQAbgMAAghIAAhnQAAgwgrAAIgqAAg");
	this.shape_63.setTransform(98.6,36.1,0.22,0.22);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f("#C0E3F7").s().p("AAuFYIhYkvIgMACIAAEtIhkAAIAAqwICRAAQCCABAACRIAABnQAABchOAaIBwFBgAg2gwIAWAAQAVAAAIgCQAZgMAAghIAAhnQAAgwgqAAIgiAAg");
	this.shape_64.setTransform(86.9,36.1,0.22,0.22);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f("#C0E3F7").s().p("AiNDSIAAmkQAAiRCNAAQCOAAAACRIAAGkQAACSiOgBQiNABAAiSgAgqjSIAAGkQAAAvAqAAQArAAAAgvIAAmkQAAgugrAAIAAAAQgqAAAAAug");
	this.shape_65.setTransform(78.5,36.1,0.22,0.22);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f("#C0E3F7").s().p("AiODNIAAgpIBkAAIAAApQAAAvAqAAQArAAAAgvIAAoqIBjAAIAAIqQABCRiPAAQiNAAgBiRg");
	this.shape_66.setTransform(70.3,36.2,0.22,0.22);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f("#C0E3F7").s().p("Ah/FYIAAqwID/AAIAABiIicAAIAADGICGAAIAABgIiGAAIAADGICcAAIAABig");
	this.shape_67.setTransform(63.5,36.1,0.22,0.22);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f("#C0E3F7").s().p("AB4FYIAAmAIhVGAIhBAAIhYmAIAAGAIhhAAIAAqwIBkAAIBzHXIB0nXIBjAAIAAKwg");
	this.shape_68.setTransform(53.9,36.1,0.22,0.22);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f("#C0E3F7").s().p("AArFYIhZmBIAAGBIhfAAIAAqwIBjAAIBcGPIAAmPIBcAAIAAKwg");
	this.shape_69.setTransform(40.1,36.1,0.22,0.22);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f("#C0E3F7").s().p("AiODNIAAoqIBkAAIAAIqQAAAvAqAAQArAAAAgvIAAoqIBjAAIAAIqQABCRiPAAQiNAAgBiRg");
	this.shape_70.setTransform(31.9,36.2,0.22,0.22);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f("#C0E3F7").s().p("AArFYIhZmBIAAGBIhfAAIAAqwIBjAAIBcGPIAAmPIBcAAIAAKwg");
	this.shape_71.setTransform(19.7,36.1,0.22,0.22);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f("#C0E3F7").s().p("AiAGSIAAqwIEBAAIAABiIidAAIAADEICGAAIAABiIiGAAIAADGICdAAIAABigAg5k4IAzhZIBLAAIhHBZg");
	this.shape_72.setTransform(12.1,34.8,0.22,0.22);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f("#C0E3F7").s().p("AgwFYIAAqwIBhAAIAAKwg");
	this.shape_73.setTransform(6.1,36.1,0.22,0.22);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f("#C0E3F7").s().p("AiNFYIAAqwICXAAQCEABAACRIAABnQAABFg2AaQA2AcAABDIAABpQAACQiKAAgAgqD2IAqAAQArAAAAguIAAhpQAAgggbgLQgJgDgSgBIgfAAgAgqgwIAfAAQATAAAIgCQAbgMAAghIAAhnQAAgwgrAAIgqAAg");
	this.shape_74.setTransform(0.1,36.1,0.22,0.22);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f("#C0E3F7").s().p("AB4FYIAAmAIhVGAIhBAAIhYmAIAAGAIhhAAIAAqwIBkAAIBzHXIB0nXIBjAAIAAKwg");
	this.shape_75.setTransform(-9.8,36.1,0.22,0.22);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f("#C0E3F7").s().p("ABGFYIgUiSIhjAAIgUCSIhkAAIAgjzIBGm9ICHAAIBGG8IAgD0gAglBkIBKAAIglkdg");
	this.shape_76.setTransform(-19.7,36.1,0.22,0.22);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f("#C0E3F7").s().p("AgxFYIAApOIhcAAIAAhiIEcAAIAABiIheAAIAAJOg");
	this.shape_77.setTransform(-26.8,36.1,0.22,0.22);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_77},{t:this.shape_76},{t:this.shape_75},{t:this.shape_74},{t:this.shape_73},{t:this.shape_72},{t:this.shape_71},{t:this.shape_70},{t:this.shape_69},{t:this.shape_68},{t:this.shape_67},{t:this.shape_66},{t:this.shape_65},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-121.9,-47.5,262.9,91.4);


(lib.Símbolo13 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("Ag4AxQgMgRAMggQAMgfAYgRQATgOAYAAQAaAAAIAOQAMARgMAfQgMAggYARQgTAOgYAAQgaAAgIgOgAgLgeQgNAMgHASQgHATAEAMQAFALAPAAQAOAAAMgLQANgMAHgTQAHgSgEgMQgFgLgPAAQgPAAgLALg");
	this.shape.setTransform(33.7,0,1.37,1.37);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("Ag3AuQgJgQALgeQALgdAXgRQATgPAVAAQAeAAAHAUQAEALgEALIgZAAQAAgIgCgFQgDgIgOAAQgMAAgLALQgMAMgHASQgHAUAEAKQAFAKAMAAQAMAAAJgJQAEgDAHgLIAZAAQgKATgSANQgQAMgUAAQgaAAgIgQg");
	this.shape_1.setTransform(16.7,0,1.37,1.37);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AABA7IgQhTIgfBTIgXAAIAsh1IAZAAIAQBRIAehRIAYAAIgsB1g");
	this.shape_2.setTransform(0.1,0,1.37,1.37);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AAcA7IACgYIgqAAIgRAYIgbAAIBVh1IAcAAIgBB1gAAAAOIAfAAIACgtg");
	this.shape_3.setTransform(-19.3,0,1.37,1.37);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgTg6IA3AAQAWAAAFAMQADAIgEAKQgEAMgIAGQgEAEgIADQAIADACAFQACAIgDAKQgEAKgJAJIgMAKQgIAEgHACIhGABgAggAnIAdAAQAHAAAEgCQAKgEAEgLQAEgKgHgDQgFgDgGAAIgcAAgAgNgLIAbAAQAIAAAGgDQAGgCADgJQADgIgGgDQgGgCgHAAIgYAAg");
	this.shape_4.setTransform(-33.5,0,1.37,1.37);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-42.4,-8.7,84.8,17.4);


(lib.Símbolo12 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#E9362F").s().p("AhkDcICsndIAdAAIi6IDg");
	this.shape.setTransform(4.1,0,1.37,1.37);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#E9362F").s().p("AhbDEICamsIAdAAIioHRg");
	this.shape_1.setTransform(0.2,-3.3,1.37,1.37);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#E9362F").s().p("AhTCsICJl8IAeAAIiXGhg");
	this.shape_2.setTransform(-3.8,-6.6,1.37,1.37);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#E9362F").s().p("AhKCUIB4lMIAdAAIiFFxg");
	this.shape_3.setTransform(-7.7,-9.9,1.37,1.37);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-18.1,-35.3,36.2,70.7);


(lib.Símbolo11 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AmnByQgRgdAAg1IAAjIIBQAAIAADIQAAAfAHAOQALAXAkAAQAkAAALgXQAIgPAAgeIAAjIIBPAAIAADIQAAA1gRAdQgeA3hXAAQhWAAgfg3gANJChIgVhCIhsAAIgVBCIhTAAIB2lJIBTAAIB1FJgALeAcIBBAAIghhhgAH0ChIhslAIAAFAIhPAAIAAlJICgAAIBADgIBBjgIBRAAIhwFJgABzChIAAkEIhgAAIAAhFIEOAAIAABFIhfAAIAAEEgAiQChIAAlJIBPAAIAAEDICcAAIAABGgAptChIAAi0IA1iVIBjAAIAAFJgAudChIAAlJIBaAAIA+CVIAAC0g");
	this.shape.setTransform(0,-10.2,1.37,1.37);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgXAYQgKgKAAgOQAAgNAKgKQAKgKANAAQAOAAALAKQAJAKABANQgBAOgJAKQgLAKgOAAQgNAAgKgKgAgSgTQgIAJAAAKQAAALAIAIQAIAIAKAAQALAAAJgIQAIgIAAgLQAAgKgIgJQgJgIgLAAQgKAAgIAIgAAQAKIAAgEQAAgEgEAAIgEAAIAAAIIgFAAIAAgTIALAAQAHAAAAAGQAAADgDAAQACABAAAEQAAAEABABgAAIAAIAFAAQABAAAAAAQABAAAAAAQABgBAAAAQAAgBAAgBQAAAAAAgBQAAgBgBAAQAAAAgBgBQAAAAgBAAIgFAAgAgEAKIAAgQIgDAQIgFAAIgEgQIAAAQIgEAAIAAgTIAGAAIAFAPIADgPIAGAAIAAATg");
	this.shape_1.setTransform(122.3,-29.5,1.37,1.37);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AggAqQgQgPgBgbQABgbAQgPQAMgMAUAAQAWAAAMAMQAPAOAAAcQAAAcgPAOQgNANgVAAQgUAAgMgNgAgTgaQgIAJABARQgBARAIAJQAHAKAMAAQANAAAHgKQAIgIAAgSQAAgQgIgKQgHgKgNAAQgMAAgHAKg");
	this.shape_2.setTransform(120.3,26.7,1.37,1.37);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AggAoQgNgQABgYQAAgaAOgOQANgNARAAQAaAAAMARQAHAJAAALIgVAAQgCgHgEgFQgFgHgMAAQgKAAgGAKQgHAKAAAPQAAASAHAIQAHAJAJAAQAMAAAFgHQAEgFACgHIAVAAQgCARgMAKQgMALgSAAQgTAAgOgOg");
	this.shape_3.setTransform(105.3,26.8,1.37,1.37);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AAUA0IgohIIAABIIgVAAIAAhnIAXAAIAoBHIAAhHIAUAAIAABng");
	this.shape_4.setTransform(91.1,26.7,1.37,1.37);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AAZA0IgHgWIgkAAIgHAWIgXAAIAlhnIAXAAIAlBngAgMAMIAZAAIgNgng");
	this.shape_5.setTransform(76.8,26.7,1.37,1.37);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgpA0IAAhnIAwAAQATAAAIALQAFAIAAAIQAAAJgFAHIgIAGQAJACADAFQAEAGAAAJQAAAJgEAIQgEAFgEADQgGAEgFABIgPACgAgUAhIAXAAQAHAAADgBQAHgEAAgJQAAgJgGgDQgEgBgHAAIgXAAgAgUgKIAXAAQAHAAAEgCQAEgCAAgHQAAgHgFgDQgFgCgIAAIgUAAg");
	this.shape_6.setTransform(62.5,26.7,1.37,1.37);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AAUA0IgphIIAABIIgUAAIAAhnIAXAAIAnBHIAAhHIAVAAIAABng");
	this.shape_7.setTransform(42.5,26.7,1.37,1.37);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgjAkQgFgJAAgRIAAg+IAWAAIAAA+QAAAKACAGQAEAIAMAAQANAAAEgIQACgGAAgKIAAg+IAWAAIAAA+QAAARgFAJQgJARgbAAQgaAAgJgRg");
	this.shape_8.setTransform(28.2,26.9,1.37,1.37);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgmA0IAAhnIBKAAIAAATIg0AAIAAAWIAwAAIAAAQIgwAAIAAAbIA3AAIAAATg");
	this.shape_9.setTransform(9.1,26.7,1.37,1.37);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AAUA0IgphIIAABIIgUAAIAAhnIAXAAIAnBHIAAhHIAVAAIAABng");
	this.shape_10.setTransform(-4.9,26.7,1.37,1.37);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgmA0IAAhnIBKAAIAAATIg1AAIAAAWIAxAAIAAAQIgxAAIAAAbIA4AAIAAATg");
	this.shape_11.setTransform(-18.5,26.7,1.37,1.37);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgJA0IAAhnIATAAIAABng");
	this.shape_12.setTransform(-28.2,26.7,1.37,1.37);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AgKA0IAAhUIgfAAIAAgTIBTAAIAAATIggAAIAABUg");
	this.shape_13.setTransform(-37,26.7,1.37,1.37);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AAZA0IgHgWIgkAAIgHAWIgXAAIAlhnIAXAAIAlBngAgNAMIAZAAIgMgng");
	this.shape_14.setTransform(-55,26.7,1.37,1.37);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AgrA0IAAhnIArAAQAJAAAIADQAKADAHAKQAFAHADAKQACAIAAAJQAAASgJAPQgLAUgYAAgAgVAhIAUAAQANAAAGgPQAEgJAAgJQAAgOgFgKQgGgJgMAAIgUAAg");
	this.shape_15.setTransform(-69,26.7,1.37,1.37);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AgJA0IAAhnIATAAIAABng");
	this.shape_16.setTransform(-79.4,26.7,1.37,1.37);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AgJA0IgjhnIAXAAIAVBNIAWhNIAXAAIgjBng");
	this.shape_17.setTransform(-88.6,26.7,1.37,1.37);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AgjAkQgFgKgBgQIAAg+IAXAAIAAA+QAAALACAFQAEAIAMAAQANAAAEgIQACgFAAgLIAAg+IAXAAIAAA+QAAAQgGAKQgJARgbAAQgaAAgJgRg");
	this.shape_18.setTransform(-108,26.9,1.37,1.37);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AgKA0IAAhUIgfAAIAAgTIBTAAIAAATIggAAIAABUg");
	this.shape_19.setTransform(-121.3,26.7,1.37,1.37);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-127.1,-34.2,254.3,68.5);


(lib.Símbolo10 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AAQAiQgLAKgRAAQgMAAgJgGQgIgGAAgMQAAgPAKgFQAIgDAPgCIAQgDQAHgCAAgHQAAgLgPAAQgTAAAAANIgTAAQACgcAkAAQANAAAJAFQALAHAAAMIAAAqQAAAHAEAAIAFgBIAAANQgGACgGAAQgNAAgBgKgAADADIgKACQgQACAAAMQAAALASAAQAFAAAHgEQAHgFAAgIIAAgNQgDACgIABg");
	this.shape.setTransform(125.4,41.2,0.791,0.791);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AhtBFIALAAQAfAAAZgTQgPAAgLgJQgMgJgEgOIAIABIAMgBQgQgDgKgNQgKgKAAgRIAAAAQAJAFAMABQgVgOAAgYQABgNAFgKQAlAtA4ACIgBgKQABgTALgNQANgNASAAQAVAAANAOQAQgDAMgIQgFAQgOAJQAMgBAOgGQgKAOgNAJIAAAHQAAAughAmQglAqg4AAQgmAAgggUg");
	this.shape_1.setTransform(20.8,39.3,0.791,0.791);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AAiBZIAAhGIAWAAIAEgZIgaAAIAAgRQAAgNAMABIAPAAIAAgZQgHgBgOAAQgPAAgKAJQgKAKABARIAAATIgWAAIAAAZIAWAAIAABGIhUAAQgDAAgEgDQgDgEABgDIAAidQgBgEADgDQAEgCADgBICdAAQAEABACACQAEADAAAEIAACdQAAADgEAEQgCADgEAAg");
	this.shape_2.setTransform(-112.7,39.3,0.791,0.791);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AAQAiQgKAKgSAAQgMAAgIgGQgJgGAAgMQAAgPAKgFQAIgDAPgCIAQgDQAIgCgBgHQAAgLgPAAQgRAAgCANIgTAAQACgcAkAAQANAAAJAFQALAHAAAMIAAAqQAAAHAFAAIAEgBIAAANQgFACgHAAQgMAAgCgKgAAEADIgKACQgQACAAAMQAAALARAAQAGAAAGgEQAIgFgBgIIAAgNQgDACgHABg");
	this.shape_3.setTransform(-16,41.2,0.791,0.791);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgJAqIgfhTIAVAAIATA/IABAAIAUg/IAUAAIgfBTg");
	this.shape_4.setTransform(-23.1,41.2,0.791,0.791);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgIA6IAAhTIARAAIAABTgAgIgoIAAgRIARAAIAAARg");
	this.shape_5.setTransform(-28,39.9,0.791,0.791);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgFAyQgEgFAAgLIAAgxIgPAAIAAgNIAPAAIAAgaIARAAIAAAaIARAAIAAANIgRAAIAAAsQgBAGACADQACADAGAAIAIgBIAAAOIgNABQgMAAgFgFg");
	this.shape_6.setTransform(-31.8,40.2,0.791,0.791);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgIA6IAAhzIARAAIAABzg");
	this.shape_7.setTransform(-35.4,39.9,0.791,0.791);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgkAKIAAg0IATAAIAAAyQAAAUAQAAQATAAAAgXIAAgvIATAAIAABTIgTAAIAAgMQgIAOgOAAQggAAAAghg");
	this.shape_8.setTransform(-40.6,41.1,0.791,0.791,0,0,0,0,-0.2);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AApA6IAAhZIgBAAIggBZIgPAAIghhZIAAAAIAABZIgTAAIAAhzIAcAAIAfBaIAfhaIAeAAIAABzg");
	this.shape_9.setTransform(-50.1,39.9,0.791,0.791);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgfAgQgLgMAAgUQAAgTALgMQAMgMATAAQATAAAMAMQAMAMAAATQAAAUgMAMQgLAMgUAAQgTAAgMgMgAgRgTQgGAIAAALQAAAMAGAIQAHAKAKAAQALAAAHgKQAFgIAAgMQAAgLgFgIQgHgJgLAAQgKAAgHAJg");
	this.shape_10.setTransform(-63.3,41.2,0.791,0.791);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgcAgQgKgMAAgUQAAgSAKgMQALgNATAAQAPAAAKAHQAMAJABAOIgTAAQgCgPgRAAQgWAAAAAcQAAAMAGAIQAGAKAIAAQASAAADgUIATAAQgFAigjAAQgRAAgLgMg");
	this.shape_11.setTransform(-70.7,41.2,0.791,0.791);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AASArIAAgzQgBgTgPAAQgHAAgHAGQgFAGAAAKIAAAwIgTAAIAAhTIASAAIAAANQAKgPAOAAQAOAAAJAHQAIAIAAAOIAAA4g");
	this.shape_12.setTransform(-78,41.1,0.791,0.791);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AAQAiQgLAKgRAAQgMAAgIgGQgJgHAAgLQAAgPAKgFQAIgDAPgCIAQgDQAIgCAAgHQgBgLgPAAQgRAAgCANIgTAAQACgcAkAAQANAAAJAFQALAHAAAMIAAAqQAAAHAEAAIAFgBIAAANQgGACgGAAQgMAAgCgKgAADADIgKACQgPACAAAMQAAALARAAQAFAAAHgEQAHgFAAgIIAAgNQgDACgIABg");
	this.shape_13.setTransform(-85.2,41.2,0.791,0.791);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AgvA6IAAhzIA3AAQAQAAAJAHQAKAIAAAOQAAASgRAHIAAAAQAWADAAAZQAAAPgKAJQgLAJgWAAgAgbApIAjAAQATAAAAgSQAAgSgTAAIgjAAgAgbgIIAgAAQARAAAAgRQAAgQgRAAIggAAg");
	this.shape_14.setTransform(-93.3,39.9,0.791,0.791);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AgJAqIgfhTIAUAAIAUA/IAVg/IAUAAIgfBTg");
	this.shape_15.setTransform(118.4,41.2,0.791,0.791);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AgIA6IAAhTIARAAIAABTgAgIgoIAAgRIARAAIAAARg");
	this.shape_16.setTransform(113.5,39.9,0.791,0.791);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AgFAyQgEgFAAgLIAAgxIgPAAIAAgNIAPAAIAAgaIARAAIAAAaIARAAIAAANIgRAAIAAAsQgBAHACACQABADAHAAIAIgBIAAAOIgNABQgMAAgFgFg");
	this.shape_17.setTransform(109.6,40.2,0.791,0.791,0,0,0,-0.1,0);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AgIA6IAAhzIARAAIAABzg");
	this.shape_18.setTransform(106.1,39.9,0.791,0.791);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AgkAKIAAg0IATAAIAAAyQAAAUAQAAQATAAAAgXIAAgvIATAAIAABTIgSAAIAAgMIgBAAQgDAGgIAEQgGAEgFAAQggAAAAghg");
	this.shape_19.setTransform(101,41.1,0.791,0.791,0,0,0,0.1,-0.2);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AApA6IAAhZIAAAAIghBZIgPAAIgghZIgBAAIAABZIgUAAIAAhzIAeAAIAeBaIAAAAIAghaIAdAAIAABzg");
	this.shape_20.setTransform(91.4,39.9,0.791,0.791);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("AgeAgQgLgMAAgUQAAgTALgMQAMgMASAAQAUAAALAMQALAMAAATQAAAUgLAMQgLAMgUAAQgSAAgMgMgAgRgTQgGAIAAALQAAAMAGAIQAHAKAKAAQALAAAHgKQAGgIAAgMQAAgLgGgIQgHgJgLAAQgKAAgHAJg");
	this.shape_21.setTransform(81.9,41.2,0.791,0.791,0,0,0,0.1,0);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("AgcAgQgLgMAAgUQAAgSALgMQALgNASAAQAQAAAKAHQALAIACAPIgTAAQgCgPgRAAQgWAAAAAcQAAANAFAHQAGAKAKAAQARAAADgUIATAAQgGAighAAQgSAAgLgMg");
	this.shape_22.setTransform(74.3,41.2,0.791,0.791);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFFFFF").s().p("AASArIAAgzQAAgTgQAAQgIAAgFAGQgGAGAAAKIAAAwIgTAAIAAhTIASAAIAAANIAAAAQAJgPAQAAQAeAAAAAdIAAA4g");
	this.shape_23.setTransform(67,41.1,0.791,0.791);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FFFFFF").s().p("AAQAiQgLAKgRAAQgMAAgJgGQgIgGAAgMQAAgPAKgFQAIgDAPgCIAQgDQAHgCAAgHQAAgLgPAAQgTAAAAANIgTAAQACgcAkAAQANAAAJAFQALAHAAAMIAAAqQAAAHAEAAIAFgBIAAANQgGACgGAAQgNAAgBgKgAADADIgKACQgQACAAAMQAAALASAAQAFAAAHgEQAHgFAAgIIAAgNQgDACgIABg");
	this.shape_24.setTransform(59.9,41.2,0.791,0.791);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#FFFFFF").s().p("AgvA6IAAhzIA3AAQAjAAAAAdQAAASgRAHIAAAAQAWADAAAZQAAAPgKAJQgLAJgWAAgAgaApIAiAAQAUAAAAgSQAAgSgUAAIgiAAgAgagIIAfAAQARAAAAgRQAAgQgRAAIgfAAg");
	this.shape_25.setTransform(51.8,39.9,0.791,0.791);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#FFFFFF").s().p("AgmAsQgSgTAAgZQAAgZASgSQARgRAXAAQAWAAARANQAQAOAAAVQAAAVgOAOQgMAMgNABQgJAAAAgKIgBAAQgIAJgIAAQgKAAgHgHQgHgIAAgKQAAgPAKgNQAKgOAOAAQANABAFALIADgJIAMAAIgMApQgEAMAGAAQAIAAAGgLQAHgKAAgNQAAgSgNgLQgMgLgTAAQgTAAgNAPQgNAOAAAVQAAAWAOAPQANANATAAQAYAAAOgQIALAAQgRAbggAAQgYAAgRgRgAgMgJQgGAJAAAIQAAAHADAEQAEAEAGAAQAHAAAHgKQAGgJAAgJQAAgFgDgEQgEgFgGAAQgHAAgHAKg");
	this.shape_26.setTransform(41.8,39.9,0.791,0.791);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#FFFFFF").s().p("AAlBNIglg6IglA6IgoAAIA6hPIg2hKIAqAAIAfAwIAggwIAoAAIg1BHIA7BSg");
	this.shape_27.setTransform(64.4,5.7,0.643,0.643);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#FFFFFF").s().p("ABNBPIAAhYQAAgWgEgJQgGgLgSAAQggAAgBApIAABZIggAAIAAhhQAAgRgFgHQgGgJgQAAQgOAAgJAKQgKAMAAASIAABaIgiAAIAAiZIAgAAIAAAWIABAAQARgaAeABQAggBAKAaQARgaAeABQA0gBAAA0IAABpg");
	this.shape_28.setTransform(51,5.6,0.643,0.643);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#FFFFFF").s().p("AgTAUIAAgnIAnAAIAAAng");
	this.shape_29.setTransform(40.1,9.4,0.643,0.643);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#FFFFFF").s().p("ABNBPIAAhYQAAgWgEgJQgGgLgSAAQghAAAAApIAABZIggAAIAAhhQAAgRgGgHQgGgJgPAAQgOAAgJAKQgKAMAAASIAABaIgiAAIAAiZIAgAAIAAAWIABAAQARgaAeABQAfgBAKAaQATgaAeABQAzgBAAA0IAABpg");
	this.shape_30.setTransform(29.2,5.6,0.643,0.643);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#FFFFFF").s().p("Ag4A5QgUgVAAgkQAAgjAUgVQAVgXAjAAQAkAAAVAXQAUAVAAAjQAAAkgUAVQgVAXgkAAQgjAAgVgXgAgggjQgKAOAAAVQAAAWAKAOQAMASAUAAQAVAAAMgSQAKgOAAgWQAAgVgKgOQgMgSgVAAQgUAAgMASg");
	this.shape_31.setTransform(15.3,5.7,0.643,0.643);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#FFFFFF").s().p("Ag0A6QgTgWAAgjQAAgjATgVQAUgZAjABQAcgBATAOQAUAPACAbIghAAQgDgOgJgHQgKgIgOAAQgPAAgKAKQgPAPAAAdQAAAVAJAPQALARASAAQAQAAAJgJQAKgKADgRIAhAAQgFAegRAQQgTAQgeAAQggABgVgXg");
	this.shape_32.setTransform(4.4,5.7,0.643,0.643);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#FFFFFF").s().p("AgTAUIAAgnIAnAAIAAAng");
	this.shape_33.setTransform(-3.6,9.4,0.643,0.643);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#FFFFFF").s().p("AAcA+QgSATghgBQgWABgPgLQgPgNgBgWQABgZASgKQANgHAcgDIAegFQAOgEAAgNQAAgVgeAAQggAAgBAZIgiAAQABgcAVgNQATgKAcAAQAYgBAQAKQAUANAAAWIAABNQAAAMAIAAIAIgBIAAAYQgKADgLAAQgWABgFgTgAAHAGIgVADQgcAEABAVQgBALAMAFQAIAEAMAAQALAAALgHQAOgIAAgOIAAgZQgGAEgNACg");
	this.shape_34.setTransform(-11.2,5.7,0.643,0.643);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#FFFFFF").s().p("AgRBNIg4iZIAlAAIAlB1IAAAAIAmh1IAjAAIg3CZg");
	this.shape_35.setTransform(-21.7,5.7,0.643,0.643);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#FFFFFF").s().p("AgPBqIAAiYIAgAAIAACYgAgPhJIAAggIAgAAIAAAgg");
	this.shape_36.setTransform(-28.9,3.9,0.643,0.643);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#FFFFFF").s().p("AgKBaQgHgIgBgVIAAhZIgaAAIAAgZIAaAAIAAguIAgAAIAAAuIAfAAIAAAZIgfAAIAABQQAAAMADAEQADAFAKAAIAPgBIAAAaIgWACQgXAAgKgKg");
	this.shape_37.setTransform(-34.4,4.3,0.643,0.643);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#FFFFFF").s().p("AgPBqIAAjTIAfAAIAADTg");
	this.shape_38.setTransform(-39.7,3.9,0.643,0.643);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#FFFFFF").s().p("Ag0A/QgOgPAAgeIAAhgIAiAAIAABdQAAAlAeAAQAjAAAAgqIAAhYIAiAAIAACZIghAAIAAgWIgBAAQgGAMgMAGQgNAIgLgBQgdAAgOgPg");
	this.shape_39.setTransform(-47.4,5.9,0.643,0.643);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#FFFFFF").s().p("ABNBPIAAhYQAAgWgEgJQgGgLgSAAQggAAAAApIAABZIggAAIAAhhQAAgRgGgHQgGgJgPAAQgOAAgKAKQgKAMAAASIAABaIgiAAIAAiZIAgAAIAAAWIABAAQARgaAeABQAggBAKAaQARgaAfABQAzgBAAA0IAABpg");
	this.shape_40.setTransform(-61.2,5.6,0.643,0.643);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#FFFFFF").s().p("AgxBbQgVgRAAgeQAAgVALgOQAMgNATgDIAAgBQgigLAAgjQAAgZAUgOQASgNAYAAQAZAAASANQAUAOAAAZQAAARgJAMQgJAMgQAFIAAABQAUAEALAMQALAOAAAVQAAAegVARQgUAQgeAAQgeAAgTgQgAgkAKQgQAMAAAWQAAAWAQANQAOAMAWAAQAXAAAOgMQAPgMAAgXQAAgWgQgMQgPgKgVAAIgBAAQgVAAgOAKgAgehRQgNAKAAARQAAAUAOAKQAMAJARAAQASAAAMgJQAOgLAAgTQAAgRgNgKQgMgJgTAAQgRAAgNAJg");
	this.shape_41.setTransform(117.6,-17.5,0.643,0.643);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#FFFFFF").s().p("Ag1BSQgRgaAAg6QAAgjALgaQATgrAqAAQA6AAAGA3IgTAAQgCgSgMgKQgMgLgRAAQgfAAgOAgQgLAYAAAjIABAAQAHgOAPgJQAQgKAPAAQAfAAATAUQATARAAAfQAAAfgUAUQgUAUgfAAQgkAAgRgZgAgiAAQgOAOAAAXQAAAYANAOQANAQAYAAQAWAAAPgQQANgPAAgXQAAgXgNgOQgOgQgXAAQgWAAgOAQg");
	this.shape_42.setTransform(107.1,-17.5,0.643,0.643);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#FFFFFF").s().p("Ag1BSQgRgaAAg6QAAgjALgaQATgrAqAAQA6AAAGA3IgTAAQgCgSgMgKQgMgLgRAAQgfAAgOAgQgLAYAAAjIABAAQAHgOAPgJQAQgKAPAAQAfAAATAUQATARAAAfQAAAfgUAUQgUAUgfAAQgkAAgRgZgAgiAAQgOAOAAAXQAAAYANAOQANAQAYAAQAWAAAPgQQANgPAAgXQAAgXgNgOQgOgQgXAAQgWAAgOAQg");
	this.shape_43.setTransform(96.4,-17.5,0.643,0.643);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#FFFFFF").s().p("AhDBoQABglAkgdIA9gsQARgSAAgWQAAgTgNgMQgNgLgUAAQgXAAgMASQgLAPABAZIgTAAQgBgiARgTQASgVAfABQAcAAASAOQASAQAAAcQAAAYgQATQgMANgYAQQgXAPgMAJQgXASgDASIByAAIAAARg");
	this.shape_44.setTransform(85.5,-17.6,0.643,0.643);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#FFFFFF").s().p("Ag1BSQgRgaAAg6QAAgjAMgaQASgrAqAAQA6AAAGA3IgTAAQgCgSgLgKQgMgLgSAAQgeAAgPAgQgKAYAAAjIAAAAQAHgOAQgJQAPgKAQAAQAfAAATAUQASARAAAfQAAAfgUAUQgUAUgeAAQglAAgRgZgAgiAAQgOAOAAAXQAAAYANAOQAOAQAYAAQAVAAAPgQQAOgQAAgWQAAgXgNgOQgOgQgYAAQgWAAgOAQg");
	this.shape_45.setTransform(69.8,-17.5,0.643,0.643);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#FFFFFF").s().p("AhDBoQABglAkgdIA9gsQARgRAAgXQAAgTgNgMQgNgLgVAAQgWAAgMASQgLAPABAZIgTAAQgBgiARgTQARgVAfABQAdAAARAOQATAQAAAcQAAAYgQATQgMANgYAQIgjAYQgXASgCASIBxAAIAAARg");
	this.shape_46.setTransform(58.9,-17.6,0.643,0.643);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#FFFFFF").s().p("AhDBoQABglAlgdIA8gsQARgRAAgXQAAgTgNgMQgNgLgVAAQgWAAgMASQgLAPAAAZIgSAAQgBgiARgTQASgVAeABQAdAAARAOQATAQAAAcQAAAYgQATQgMANgYAQIgjAYQgXASgCASIBxAAIAAARg");
	this.shape_47.setTransform(48.2,-17.6,0.643,0.643);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#FFFFFF").s().p("AhHAAQAAhqBHAAQBIAAAABqQAABrhIAAQhHAAAAhrgAg0AAQAABbA0AAQA1AAAAhbQAAhag1AAQg0AAAABag");
	this.shape_48.setTransform(32.5,-17.5,0.643,0.643);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#FFFFFF").s().p("AhHAAQAAhqBHAAQBIAAAABqQAABrhIAAQhHAAAAhrgAg0AAQAABbA0AAQA1AAAAhbQAAhag1AAQg0AAAABag");
	this.shape_49.setTransform(21.8,-17.5,0.643,0.643);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#FFFFFF").s().p("AgxBbQgVgRAAgeQAAgVALgOQAMgNATgDIAAgBQgigLAAgjQAAgZAUgOQASgNAYAAQAZAAASANQAUAOAAAZQAAARgJAMQgJAMgQAFIAAABQAUAEALAMQALAOAAAVQAAAegVARQgUAQgeAAQgeAAgTgQgAgkAKQgQAMAAAWQAAAWAQANQAOAMAWAAQAXAAAOgMQAPgMAAgXQAAgWgQgMQgPgKgVAAIgBAAQgVAAgOAKgAgehRQgNAKAAARQAAAUAOAKQAMAJARAAQASAAAMgJQAOgLAAgTQAAgRgNgKQgMgJgTAAQgRAAgNAJg");
	this.shape_50.setTransform(11.2,-17.5,0.643,0.643);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#FFFFFF").s().p("AASBoIAAiZIg1AAIAAgNQAegCAHgFQAQgIADgaIAPAAIAADPg");
	this.shape_51.setTransform(-0.5,-17.6,0.643,0.643);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#FFFFFF").s().p("AhHAAQAAhqBHAAQBIAAAABqQAABrhIAAQhHAAAAhrgAg0AAQAABbA0AAQA1AAAAhbQAAhag1AAQg0AAAABag");
	this.shape_52.setTransform(-10.1,-17.5,0.643,0.643);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#FFFFFF").s().p("Ag0BuIBajbIAPAAIhZDbg");
	this.shape_53.setTransform(-23.9,-17.7,0.643,0.643);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#FFFFFF").s().p("AgxBbQgVgRAAgeQAAgVALgOQAMgNATgDIAAgBQgigLAAgjQAAgZAUgOQARgNAZAAQAYAAASANQAUAOAAAZQAAARgJAMQgJAMgQAFIAAABQAUAEAMAMQALAOAAAVQAAAegVARQgUAQgeAAQgeAAgTgQgAgkAKQgQAMAAAWQAAAWAQANQAOAMAWAAQAWAAAPgMQAPgMAAgXQAAgWgQgMQgPgKgVAAIgBAAQgVAAgOAKgAgehRQgNAKAAARQAAAUAOAKQAMAJARAAQASAAAMgJQAOgLAAgTQAAgRgNgKQgMgJgTAAQgRAAgNAJg");
	this.shape_54.setTransform(-37.8,-17.5,0.643,0.643);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("#FFFFFF").s().p("AgxBYQgTgSgBgdIATAAQABAVAOAOQAPANAUAAQAWAAAPgRQAOgQAAgYQAAgXgPgOQgPgPgVAAQgOAAgMAGQgNAHgHAKIgQAAIAThrIBnAAIAAASIhaAAIgNBFIABAAQAHgJANgFQAMgFAKAAQAgAAATAVQATARAAAgQAAAegVAVQgVAUgcAAQgeAAgTgRg");
	this.shape_55.setTransform(-48.5,-17.3,0.643,0.643);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("#FFFFFF").s().p("AgxBbQgVgRAAgeQAAgVALgOQAMgNATgDIAAgBQgigLAAgjQAAgZAUgOQARgNAZAAQAYAAASANQAUAOAAAZQAAARgJAMQgJAMgQAFIAAABQAUAEAMAMQALAOAAAVQAAAegVARQgUAQgeAAQgeAAgTgQgAgkAKQgQAMAAAWQAAAWAQANQAOAMAWAAQAWAAAPgMQAPgMAAgXQAAgWgQgMQgPgKgVAAIgBAAQgVAAgOAKgAgehRQgNAKAAARQAAAUAOAKQAMAJARAAQASAAAMgJQAOgLAAgTQAAgRgNgKQgMgJgTAAQgRAAgNAJg");
	this.shape_56.setTransform(-59,-17.5,0.643,0.643);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("#FFFFFF").s().p("AgxBYQgTgSgBgdIATAAQAAAVAPAOQAPANAUAAQAWAAAPgRQAOgQAAgYQAAgXgPgOQgPgPgVAAQgOAAgMAGQgNAHgHAKIgQAAIAThrIBnAAIAAASIhZAAIgOBFIABAAQAHgJANgFQAMgFAKAAQAgAAATAVQATARAAAgQAAAegVAVQgVAUgcAAQgeAAgTgRg");
	this.shape_57.setTransform(-69.8,-17.3,0.643,0.643);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("#FFFFFF").s().p("AhBA0IATAAQACASAMAKQALALASAAQAfAAAOggQALgYAAgjIgBAAQgHANgPAKQgQAJgPAAQgfAAgTgTQgTgSAAgeQAAgfAUgUQAUgUAeAAQAlAAARAZQARAaAAA6QAAAjgLAaQgTArgqAAQg6AAgGg3gAglhKQgOAPAAAWQAAAYANANQAOAQAXAAQAWAAAOgQQAOgNAAgYQAAgXgNgPQgNgPgYAAQgWAAgOAQg");
	this.shape_58.setTransform(-85.7,-17.5,0.643,0.643);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("#FFFFFF").s().p("AgkBmQAEg1ATgqQASgqArgxIhxAAIAAgSICEAAIAAASQhNBUgGBmg");
	this.shape_59.setTransform(-96.4,-17.5,0.643,0.643);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("#FFFFFF").s().p("AhDBoQABglAkgdQAsgcARgQQASgRAAgXQAAgTgOgMQgNgLgUAAQgWAAgNASQgLAPABAZIgTAAQgBgiARgTQASgVAfABQAcAAASAOQASAQAAAcQAAAYgQATQgMANgYAQIgjAYQgWASgEASIByAAIAAARg");
	this.shape_60.setTransform(-107.2,-17.6,0.643,0.643);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("#FFFFFF").s().p("AgxBYQgTgSgBgdIATAAQABAVAOAOQAOANAVAAQAWAAAQgRQAOgQgBgYQABgXgQgOQgPgPgVAAQgOAAgNAGQgMAHgIAKIgQAAIAUhrIBnAAIAAASIhZAAIgOBFIABAAQAIgJAMgFQAMgFAKAAQAgAAATAVQATARAAAgQAAAegVAVQgVAUgdAAQgdAAgTgRg");
	this.shape_61.setTransform(-117.7,-17.3,0.643,0.643);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("#FFFFFF").s().p("AgLBKIAAggIAXAAIAAAggAgLgpIAAggIAXAAIAAAgg");
	this.shape_62.setTransform(53.6,-37.2,0.643,0.643);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("#FFFFFF").s().p("Ag2BGQgQgMAAgWQAAgdAagIQANgFAqgGQANgBAFgDQAGgFAAgMQAAgfgmAAQgTAAgKAIQgMAKAAASIgTAAQABgaARgNQAQgNAcAAQA3AAAAAyIAABPQAAALALAAIAGgBIAAAQIgNABQgNAAgFgHQgEgGAAgOIAAAAQgLARgLAHQgNAIgTAAQgXAAgNgLgAATAAIguAIQgYAHAAAUQAAANALAJQAKAIANAAQAVAAAPgNQAQgOAAgVIAAgXIgBAAQgCAFgNABg");
	this.shape_63.setTransform(46.2,-37.3,0.643,0.643);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f("#FFFFFF").s().p("AgIBMIg7iXIAVAAIAuCEIABAAIAviEIAUAAIg6CXg");
	this.shape_64.setTransform(36.5,-37.3,0.643,0.643);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f("#FFFFFF").s().p("AgIBqIAAiYIARAAIAACYgAgIhLIAAgeIARAAIAAAeg");
	this.shape_65.setTransform(30.3,-39.2,0.643,0.643);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f("#FFFFFF").s().p("AgDBdQgHgIAAgTIAAhnIgbAAIAAgQIAbAAIAAguIAQAAIAAAuIAgAAIAAAQIggAAIAABlQABALACAEQAEAFAJABIAQgBIAAAQIgQAAQgUAAgFgHg");
	this.shape_66.setTransform(25.5,-38.8,0.643,0.643);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f("#FFFFFF").s().p("AgIBqIAAjTIARAAIAADTg");
	this.shape_67.setTransform(21.1,-39.2,0.643,0.643);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f("#FFFFFF").s().p("Ag9AUIAAhhIATAAIAABiQABAVAJAKQAKAKAVAAQAUABANgUQALgQAAgaIAAhOIATAAIAACXIgSAAIAAgbIAAAAQgIAPgNAIQgOAIgQAAQg2AAAAg6g");
	this.shape_68.setTransform(14.2,-37.2,0.643,0.643);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f("#FFFFFF").s().p("ABSBqIAAi2IAAAAIhJC2IgRAAIhJi2IAAAAIAAC2IgVAAIAAjTIAeAAIBIC5IBJi5IAeAAIAADTg");
	this.shape_69.setTransform(1.1,-39.2,0.643,0.643);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f("#FFFFFF").s().p("Ag3BGQgPgMAAgWQAAgdAagIQANgFAqgGQANgBAFgDQAGgFAAgMQAAgfgmAAQgTAAgKAIQgMAKAAASIgTAAQABgaARgNQAQgNAcAAQA3AAAAAyIAABPQAAALALAAIAGgBIAAAQIgNABQgNAAgFgHQgEgGAAgOIAAAAQgLARgLAHQgNAIgTAAQgXAAgOgLgAASAAIgtAIQgYAHAAAUQAAANAKAJQAKAIAOAAQAVAAAPgNQAQgOAAgVIAAgXIgBAAQgCAFgOABg");
	this.shape_70.setTransform(-16.9,-37.3,0.643,0.643);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f("#FFFFFF").s().p("AgzA5QgQgWAAgjQAAggAQgWQATgaAgAAQAjAAASAbQAQAYgBAhIh0AAQAAAYAMARQANAUAXAAQAmAAAKgnIATAAQgMA3g3AAQghAAgSgYgAghgvQgNAPgCAXIBhAAQgBgXgMgPQgOgRgWAAQgTAAgOARg");
	this.shape_71.setTransform(-27,-37.3,0.643,0.643);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f("#FFFFFF").s().p("AArBOIAAheQAAgugnAAQgUAAgNAPQgMAPgBAXIAABXIgTAAIAAiXIATAAIAAAaIAAAAQAFgNAOgJQAOgJAPABQAeAAAOAPQAMAOAAAdIAABhg");
	this.shape_72.setTransform(-37.2,-37.5,0.643,0.643);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f("#FFFFFF").s().p("AgSBsIAAiXIASAAIAACXgAgahBIAdgqIAYAAIgmAqg");
	this.shape_73.setTransform(-43.5,-39.4,0.643,0.643);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f("#FFFFFF").s().p("AhEBqIAAjTIAUAAIAADBIB1AAIAAASg");
	this.shape_74.setTransform(-50.3,-39.2,0.643,0.643);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_74},{t:this.shape_73},{t:this.shape_72},{t:this.shape_71},{t:this.shape_70},{t:this.shape_69},{t:this.shape_68},{t:this.shape_67},{t:this.shape_66},{t:this.shape_65},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-122.2,-46.3,251,92.8);


(lib.Símbolo8 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AglAdIhUg+IgQgvIB0AuQAHADBLASIBNAOIgIBQIgFAAQhRAAhRg0g");
	this.shape.setTransform(32.3,47.1,0.309,0.309);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("ABjChQgygeg6ABQgaABgXAFIgpggQgpgpgpg0QhRhlAGg4QAHg/AigTQAYgOAYABQAbABAPAVIAnAzQATAigVAXIgWAXIgJANQgEASAXAZIBFBAIABAAQAVAVAxAqQAbAUASgFQAJgCAEgHIAWgXQAVgWAlAQQAUAKAjAYQAUANAEAaQADAWgKAYQgPAjg9AMQgagygxgdg");
	this.shape_1.setTransform(30.9,42.2,0.309,0.309);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#1A3259").s().p("Ak3EdQghgggBguIgEmWQgBguAighQAgggAvgBIHUgFQAvgBAiAhQAhAgAAAuIAFGWQABAugiAgQggAhgwABIgcAAIAAgKQAAgxgXgrQA8gMAPgjQAKgXgDgXQgEgagUgMQgigZgVgJQgkgRgWAWIgWAXQgEAHgIADQgTAFgbgVQgzgqgTgUIAAAAIhFhBQgYgZAFgSIAIgNIAWgXQAVgWgTgjIgngzQgPgUgbgBQgYgBgYANQgiATgHBAQgGA3BRBoQApAyApAoIAqAhQhEARgtA3QgrA3AABHIAAAKIgcAAIgDAAQgtAAghggg");
	this.shape_2.setTransform(30.6,43.1,0.309,0.309);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#1A3259").s().p("AhWB4IgCjOICth9IAEGng");
	this.shape_3.setTransform(45,42.9,0.309,0.309);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AlpFHQgygygBhIIgEmQQAAhJAxgyQAyg0BIgBIHkgFQBHAAAzAyQAzAyABBIIAEGRQABBHgzA0QgyAzhIABInkAFQhHAAgzgygAj0k3QgvABghAiQghAhABAuIAEGSQABAvAhAgQAhAhAuAAIHkgFQAvgBAhghQAhgigBgvIgEmRQgBgughghQghghgvAAg");
	this.shape_4.setTransform(30.6,43.1,0.309,0.309);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#1A3259").s().p("AlTExQgqgpgBg7IgEmRQgBg7AqgrQApgqA8gBIHkgFQA6AAAqApQAqAqABA7IAEGRQABA7gqArQgoAqg9ABInkAFQg6AAgqgqg");
	this.shape_5.setTransform(30.6,43.1,0.309,0.309);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AiECaIAAkFIEIi+IAAJTgAgqg9IAAChIBUAvIAAkNg");
	this.shape_6.setTransform(45,43.1,0.309,0.309);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgFAmIAAg/IgZAAIAAgMIA9AAIAAAMIgZAAIAAA/g");
	this.shape_7.setTransform(-11.2,41.8,0.424,0.424);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AAWAmIgIgUIgcAAIgIAUIgOAAIAehLIAMAAIAfBLgAgLAHIAWAAIgLgeIAAAAg");
	this.shape_8.setTransform(-13.7,41.8,0.424,0.424);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AARAmIAAgiIghAAIAAAiIgNAAIAAhLIANAAIAAAfIAhAAIAAgfIAOAAIAABLg");
	this.shape_9.setTransform(-16.9,41.8,0.424,0.424);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgMAlQgHgDgEgGQgEgEgEgJQgCgIAAgHQAAgGACgIQADgJAFgEQAEgGAHgDQAHgDAHAAQAGAAAFACQAIACADADIAHAIQADAHAAAEIgNAAIgCgGIgFgFIgFgDIgHgBQgFAAgEADQgEACgDAEQgDADgCAHIgBAJQAAAFABAFIAFAKQADAEAEACQAFADAEAAQAEAAAEgCQADgBACgDIAFgGQABgEAAgEIANAAQAAAGgDAGQgCAGgFAEQgFAFgFACQgFACgHAAQgHAAgHgDg");
	this.shape_10.setTransform(-20.2,41.8,0.424,0.424);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#19335A").s().p("AjKDwIBhAAQh1gDgzgfQgrgaAAg2IAAluQAAgvAhghQAhghAvAAIGXAAQAvAAAhAhQAhAhAAAvIAAFuQAAAwghAgQghAigvAAIj5AAIjMBzg");
	this.shape_11.setTransform(-16.4,43.7,0.297,0.297);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#19335A").s().p("AASCfIh+AAQgbAAgYgMQgXgMgQgUIC3AAQAsAAAigiQAhghAAgvIAAjrQArAEAeAgQAeAhAAAsIAACnQAAAxgYAZQghAhhUACIA/AAIAhBQg");
	this.shape_12.setTransform(-9.5,47.7,0.297,0.297);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AkVGUIgdguIAnhdQhjgnAAhkIAAluQAAhEAwgvQAwgxBDAAIGXAAQBEAAAvAxQAwAvAABEIAAFuQAABEgwAwQgvAwhEAAIjsAAIjMBygAj4kdQgSATAAAaIAAFuQAAAaAXAOQAqAYB2AAIAAAOIAXgOIEIAAQAaAAATgTQASgSAAgbIAAluQAAgagSgTQgTgSgagBImXAAQgaABgTASg");
	this.shape_13.setTransform(-16.4,43.7,0.297,0.297);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AAcCzIhxAAQgnAAgigQQgigRgWgeIg/hRIEaAAQAaAAATgSQASgRAAgaIAAklIA3AGQA/AFAqAwQArAvABA+IAACnQgBBahAAnIBHCvgACogaQAAAzgeArQAWgHAHgPQAFgJAAgVIAAinQAAgJgEgJg");
	this.shape_14.setTransform(-10.2,48.6,0.297,0.297);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("Ag3BYIAAhBIgZAAIAAhuIChAAIAABuIgZAAIAABBg");
	this.shape_15.setTransform(-12.9,46.7,0.297,0.297);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AhsBYIBEivIBRAAIBECvg");
	this.shape_16.setTransform(-14.6,46.7,0.297,0.297);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AhQBYIAAivICgAAIAACvg");
	this.shape_17.setTransform(-16.8,46.7,0.297,0.297);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AgkBSQgQgIgMgNQgLgNgGgRQgFgPAAgQQAAgPAFgPQAGgRALgNQAMgNAQgIQAegOAgAKQAPAFALAJQAMAJAIAOIAEAJIAJAAIgCAjIAEAnIgKAAIgCAGQgGAOgMAMQgNALgOAGQgPAGgPAAQgUAAgQgIgAgEgHQgFACgBACIgDADIAAAAIAFAGIABAAIANABIADgDIADgEIAAAAIgCgDIgFgEIgFgBg");
	this.shape_18.setTransform(-19.1,46.7,0.297,0.297);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AAACWIhSg/QgigjghgsQhChWAFgvQAIg2AbgPQAUgLAUABQAWABAMARIAgAsQAQAdgSATIgSATIgHALQgEAQATAVIAVAWIAjAgQASASAoAkQAWARAPgEQAHgCADgGIATgTQASgSAeAOQARAIAcAVQAQALADAWQACATgIAUQgNAfg4AJIgLABQgtAAhQg3g");
	this.shape_19.setTransform(-64.7,43.8,0.297,0.297);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#19335A").s().p("AigEcIiaAdIAdicQgphLAAhSQAAiGBghgQBghfCGAAQCHAABfBfQBhBggBCGQABCHhhBfQhfBhiHAAQhVAAhLgrg");
	this.shape_20.setTransform(-64.6,43.5,0.297,0.297);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("AlSClQgmhOAAhXQAAhKAdhGQAchFA2g1QA1g1BFgeQBGgcBJAAQBMAABFAcQBFAeA2A1QA1A1AdBFQAdBGAABKQAABLgdBFQgdBGg1A1Qg2A2hFAcQhFAchMAAQhXAAhRgnIjSAog");
	this.shape_21.setTransform(-64.7,43.5,0.297,0.297);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#E5E5E5").s().p("AlVCkQgmhOAAhWQAAhMAdhFQAdhGA2g2QA2g2BGgdQBFgdBLAAQBMAABGAdQBGAdA2A2QA2A2AdBGQAcBFAABMQAABLgcBGQgdBFg2A2Qg2A2hGAdQhGAdhMAAQhYAAhRgoIjVAqg");
	this.shape_22.setTransform(-64.7,43.5,0.297,0.297);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFFFFF").s().p("AAmBRQgNAMgUAGQgQAGgTAAQgcAAgTgOQgVgQAAgdQAAghAYgNQAQgKAlgEIAogHQASgEAAgRQAAgbgoAAQgqAAgCAfIgsAAQADgjAcgRQAWgOAmAAQAfAAAVAOQAaAPAAAdIAABlQAAAJADACQACAEAFAAIALgBIAAAfQgQAFgLAAQgeAAgEgYgAAJAIIgbADQgkAGAAAcQAAAMAOAIQAMAFAPAAQAPAAAOgIQASgLAAgTIAAggQgJAEgQAEg");
	this.shape_23.setTransform(61,19.6,0.23,0.23);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FFFFFF").s().p("AhLBtQgWgcAAgwQAAgwAbgdQAXgZAkAAQASAAASAIQATAIAKAQIAAAAIAAhmIAtAAIAAESIgrAAIAAgbIAAAAQgJAQgRAIQgQAIgSAAQguAAgZgfgAgpgLQgMARAAAfQAAAcANATQAPAVAZAAQAbAAAQgWQANgUAAgcQAAghgPgRQgPgTgZAAQgbAAgPAXg");
	this.shape_24.setTransform(55.6,18.8,0.23,0.23);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#FFFFFF").s().p("AAlBRQgMAMgUAGQgQAGgTAAQgdAAgSgOQgVgQAAgdQAAghAYgNQARgKAkgEIAogHQASgEAAgRQAAgbgoAAQgpAAgDAfIgsAAQACgjAcgRQAXgOAmAAQAfAAAVAOQAaAPAAAdIAABlQAAAJACACQACAEAGAAIALgBIAAAfQgQAFgMAAQgdAAgFgYgAAJAIIgbADQgkAGAAAcQAAAMAOAIQAMAFAOAAQAQAAAOgIQASgLAAgTIAAggQgJAFgQADg");
	this.shape_25.setTransform(50.6,19.6,0.23,0.23);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#FFFFFF").s().p("ABlBmIAAhzQAAgcgGgKQgHgPgYAAQgqAAAAA1IAABzIgqAAIAAh+QgBgWgHgKQgJgKgTAAQgRAAgNANQgOAPAAAYIAAB0IgsAAIAAjGIArAAIAAAcIAAAAQAXghAnAAQAUAAAOAIQANAJAHAQQAXghAnAAQBDAAAABDIAACIg");
	this.shape_26.setTransform(44.2,19.5,0.23,0.23);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#FFFFFF").s().p("AAlBRQgMAMgUAGQgQAGgTAAQgdAAgSgOQgVgQAAgdQAAghAYgNQARgKAkgEIAogHQASgEAAgRQAAgbgoAAQgpAAgDAfIgsAAQACgjAcgRQAXgOAmAAQAfAAAVAOQAaAPAAAdIAABlQAAAJACACQACAEAGAAIALgBIAAAfQgQAFgMAAQgdAAgFgYgAAJAIIgbADQgkAGAAAcQAAAMAOAIQAMAFAOAAQAQAAAOgIQASgLAAgTIAAggQgJAFgQADg");
	this.shape_27.setTransform(38,19.6,0.23,0.23);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#FFFFFF").s().p("AgUCKIAAkTIAqAAIAAETg");
	this.shape_28.setTransform(34.3,18.7,0.23,0.23);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#FFFFFF").s().p("AgVCKIAAkTIAqAAIAAETg");
	this.shape_29.setTransform(32.2,18.7,0.23,0.23);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#FFFFFF").s().p("AhJBLQgagcAAgvQAAguAagcQAbgeAuAAQAuAAAcAeQAbAcgBAuQABAvgbAcQgcAeguAAQguAAgbgegAgqgvQgNAUAAAbQAAAcANATQAQAXAaAAQAbAAAQgXQANgTAAgcQAAgbgNgUQgQgWgbAAQgaAAgQAWg");
	this.shape_30.setTransform(28.5,19.6,0.23,0.23);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#FFFFFF").s().p("AhFBLQgZgcAAgvQAAgqAageQAbggApAAQAuAAAcAkQAaAigFAtIiRAAQAAAZANAQQAOASAZAAQAkAAAMghIAqAAQgHAggZATQgZARghAAQgsAAgbgegAgjg1QgOAOgBAXIBlAAQgBgWgOgPQgOgQgWAAQgUAAgPAQg");
	this.shape_31.setTransform(23.4,19.6,0.23,0.23);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#FFFFFF").s().p("AhLBtQgXgcABgwQAAgwAbgdQAXgZAkAAQASAAARAIQAUAIAKAQIAAAAIAAhmIAtAAIAAESIgqAAIAAgbIgBAAQgIAQgSAIQgQAIgSAAQgtAAgagfgAgpgLQgNARAAAfQAAAcAOATQAPAVAZAAQAbAAAPgWQAOgUAAgcQAAghgPgRQgPgTgZAAQgbAAgPAXg");
	this.shape_32.setTransform(18.1,18.8,0.23,0.23);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#FFFFFF").s().p("AgUCKIAAjGIAqAAIAADGgAgUhfIAAgqIAqAAIAAAqg");
	this.shape_33.setTransform(14.4,18.7,0.23,0.23);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#FFFFFF").s().p("AgaCKIhdkTIAzAAIBEDZIAAAAIBHjZIAwAAIheETg");
	this.shape_34.setTransform(10.5,18.7,0.23,0.23);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#FFFFFF").s().p("AgTAUQgIgJgBgLQAAgKAJgJQAJgJAKAAQALAAAJAJQAJAIgBALQABALgJAJQgJAIgLABQgLgBgIgIg");
	this.shape_35.setTransform(1.6,19.2,0.23,0.23);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#FFFFFF").s().p("AgNB2QgKgMgBgbIAAh0IghAAIAAggIAhAAIAAg9IAqAAIAAA9IAoAAIAAAgIgoAAIAABpQAAAQADAEQAFAIANgBQAMABAHgCIAAAiIgdACQgeABgMgNg");
	this.shape_36.setTransform(-8.5,18.9,0.23,0.23);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#FFFFFF").s().p("AAlBRQgMAMgUAGQgQAGgTAAQgcAAgUgOQgUgQAAgdQAAghAZgNQAPgKAlgEIAngHQATgEgBgRQAAgbgnAAQgpAAgDAfIgsAAQACgjAcgRQAYgOAlAAQAfAAAVAOQAaAPAAAdIAABlQAAAJACACQADAEAFAAIALgBIAAAfQgQAFgMAAQgcAAgGgYgAAJAIIgbADQgkAGAAAcQAAAMAPAIQALAFAPAAQAPAAAOgIQASgLAAgTIAAggQgJAEgQAEg");
	this.shape_37.setTransform(-12.3,19.6,0.23,0.23);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#FFFFFF").s().p("AArCKIAAh+QgBgVgJgMQgJgKgUAAQgTAAgOAPQgNAPAAAVIAAB2IgsAAIAAkTIAsAAIAABnIABAAQAIgOAQgJQARgJAQAAQAhAAATARQATASAAAfIAACKg");
	this.shape_38.setTransform(-17.5,18.7,0.23,0.23);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#FFFFFF").s().p("AhYBmQgjgpAAg9QAAg8AjgpQAlgqA6AAQAwAAAfAZQAiAaAEArIgwAAQgPg3g2ABQgoAAgWAgQgUAdAAAqQAAAsAUAcQAWAhAogBQAfAAATgUQARgUADggIAvAAQgDAyggAfQggAfgyAAQg6AAglgqg");
	this.shape_39.setTransform(-23.2,18.7,0.23,0.23);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#FFFFFF").s().p("AgTAUQgJgJABgLQAAgKAJgJQAIgJAKAAQALAAAJAJQAIAIABALQgBALgIAJQgIAIgMABQgKgBgJgIg");
	this.shape_40.setTransform(-32.6,19.2,0.23,0.23);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#FFFFFF").s().p("AhhCLIAAkPIApAAIAAAbIABAAQASghAqAAQAtAAAZAgQAXAcAAAvQAAApgVAdQgXAggqAAQgSAAgSgHQgTgJgKgQIAAAAIAABkgAgphUQgOATAAAhQAAAeAPASQAPAUAZAAQAbAAAPgWQAMgRAAgdQAAgegOgTQgPgWgZAAQgaAAgPATg");
	this.shape_41.setTransform(-41.4,20.4,0.23,0.23);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#FFFFFF").s().p("AhhCLIAAkPIApAAIAAAbIABAAQAJgRARgIQAQgIASAAQAtAAAZAgQAXAcAAAvQAAApgVAdQgXAggqAAQgSAAgSgHQgTgJgKgQIAAAAIAABkgAgphUQgOATAAAhQAAAeAPASQAPAUAZAAQAbAAAPgWQAMgRAAgdQAAgegOgTQgPgWgZAAQgaAAgPATg");
	this.shape_42.setTransform(-46.8,20.4,0.23,0.23);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#FFFFFF").s().p("ABQCKIgahJIhsAAIgaBJIgyAAIBqkTIAxAAIBqETgAgpAcIBSAAIgph1IAAAAg");
	this.shape_43.setTransform(-52.6,18.7,0.23,0.23);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#FFFFFF").s().p("Ag+BYQgZgSgBgjIAsAAQAEAjAoAAQAtAAgBgaQAAgPgVgIIgqgKQgegHgOgJQgUgOAAgcQAAgdAcgQQAWgMAhAAQAgAAAVAOQAZAQAEAgIguAAQgFgbgiAAQgOAAgJADQgNAGAAALQAAAPAUAHIArALQAeAGAOAKQAUANAAAbQAAAhgcASQgZAOgjAAQgmAAgYgRg");
	this.shape_44.setTransform(-57.8,19.6,0.23,0.23);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#FFFFFF").s().p("AgNB2QgKgMgBgbIAAh0IghAAIAAggIAhAAIAAg9IAqAAIAAA9IAoAAIAAAgIgoAAIAABpQAAAQADAEQAFAIANgBQANABAGgCIAAAiIgdACQgeABgMgNg");
	this.shape_45.setTransform(-61.7,18.9,0.23,0.23);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#FFFFFF").s().p("AAlBRQgMAMgUAGQgQAGgTAAQgdAAgSgOQgVgQAAgdQAAghAYgNQARgKAkgEIAogHQASgEAAgRQAAgbgoAAQgpAAgDAfIgsAAQACgjAcgRQAXgOAmAAQAfAAAWAOQAZAPAAAdIAABlQAAAJACACQACAEAGAAIALgBIAAAfQgQAFgMAAQgdAAgFgYgAAJAIIgbADQgkAGAAAcQAAAMAOAIQAMAFAPAAQAPAAAOgIQASgLAAgTIAAggQgJAFgQADg");
	this.shape_46.setTransform(-65.5,19.6,0.23,0.23);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#FFFFFF").s().p("AArCKIAAh+QAAgVgKgMQgJgKgUAAQgTAAgOAPQgNAPAAAVIAAB2IgsAAIAAkTIAsAAIAABnIABAAQAIgPAQgIQAQgJASAAQAhAAASARQATASAAAfIAACKg");
	this.shape_47.setTransform(-70.6,18.7,0.23,0.23);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#FFFFFF").s().p("AA2CKIg2jSIAAAAIg4DSIgyAAIhJkTIAxAAIAyDSIABAAIA4jSIAwAAIA2DSIAAAAIA0jSIAxAAIhMETg");
	this.shape_48.setTransform(-77.4,18.7,0.23,0.23);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-81.5,15.4,144.8,42.7);


(lib.Símbolo6 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AmoByQgQgeAAg0IAAjHIBPAAIAADHQABAfAHAOQAKAXAlAAQAlAAAKgXQAIgPgBgeIAAjHIBQAAIAADHQAAA0gRAeQgfA3hWgBQhWABggg3gANJCgIgVhBIhsAAIgWBBIhSAAIB1lHIBUAAIB1FHgALeAcIBAAAIgfhhgAH0CgIhsk/IAAE/IhPAAIAAlHICgAAIBADfIBBjfIBRAAIhwFHgAByCgIAAkDIhfAAIAAhEIEPAAIAABEIhgAAIAAEDgAiQCgIAAlHIBPAAIAAEDICdAAIAABEgAptCgIAAizIA1iUIBjAAIAAFHgAudCgIAAlHIBaAAIA+CUIAACzg");
	this.shape.setTransform(-1.1,1.6,0.639,0.639);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgXAYQgLgKAAgOQAAgNALgLQAKgJANgBQAOABALAJQAKALAAANQgBAOgJAKQgLAKgOAAQgMAAgLgKgAgSgTQgJAJABAKQgBALAJAIQAIAIAKAAQALAAAIgIQAJgIgBgLQABgKgJgJQgIgIgLAAQgKAAgIAIgAAQAKIAAgEQgBgEgDAAIgEAAIAAAIIgFAAIAAgUIALAAQAHABAAAGQAAADgEAAQADABAAAFQAAABAAAAQAAABAAABQAAAAABABQAAAAAAAAgAAIAAIAFAAQABAAAAAAQABAAAAgBQABAAAAgBQAAAAAAgBQAAgBAAAAQAAgBgBAAQAAAAgBAAQAAgBgBAAIgFAAgAgEAKIAAgQIgEAQIgEAAIgEgQIAAAQIgEAAIAAgUIAGAAIAFAQIADgQIAGAAIAAAUg");
	this.shape_1.setTransform(55.9,-7.4,0.639,0.639);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#EA372F").s().p("AhkDcICsncIAdAAIi6IBg");
	this.shape_2.setTransform(-40.3,-4.6,0.639,0.639);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#EA372F").s().p("AhbDEICamsIAdAAIioHRg");
	this.shape_3.setTransform(-42.1,-6.2,0.639,0.639);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#EA372F").s().p("AhTCsICKl8IAdAAIiXGhg");
	this.shape_4.setTransform(-43.9,-7.7,0.639,0.639);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#EA372F").s().p("AhKCTIB4lLIAdAAIiFFxg");
	this.shape_5.setTransform(-45.8,-9.2,0.639,0.639);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("Ag4AxQgMgRAMggQAMgfAYgRQAUgOAXAAQAZAAAJAOQAMARgMAfQgLAggZARQgTAOgYAAQgaAAgIgOgAgLgdQgNAKgHATQgHAUAEALQAGALAOAAQAOAAAMgLQANgMAHgTQAHgTgEgKQgFgMgPAAQgPAAgLAMg");
	this.shape_6.setTransform(2.1,-17.3,0.639,0.639);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("Ag3AuQgJgQALgeQAMgeAWgQQATgPAWAAQAeAAAGAUQAEALgEALIgZAAQABgJgCgEQgEgIgNAAQgOAAgJALQgMALgHASQgIAUAFALQAEAKANAAQAMAAAJgJQAEgEAHgKIAZAAQgKATgSANQgQAMgVAAQgZAAgJgQg");
	this.shape_7.setTransform(-5.8,-17.2,0.639,0.639);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AABA7IgQhTIgfBTIgXAAIArh1IAaAAIAQBRIAehRIAYAAIgsB1g");
	this.shape_8.setTransform(-13.6,-17.2,0.639,0.639);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AAcA7IABgYIgqAAIgQAYIgbAAIBUh1IAdAAIgCB1gAAAAOIAeAAIADgtg");
	this.shape_9.setTransform(-22.6,-17.2,0.639,0.639);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgTg6IA4AAQAVAAAFAMQADAIgEALQgEALgIAGQgFAEgHADQAIADACAGQACAGgDALQgFAMgIAHQgFAGgHAEQgHAEgIACIhGABgAggAnIAdAAQAHAAAEgCQAKgFAEgKQADgKgGgDQgEgCgHAAIgcAAgAgNgLIAbAAQAIAAAGgDQAGgDADgIQADgJgGgCQgEgCgJAAIgYAAg");
	this.shape_10.setTransform(-29.3,-17.2,0.639,0.639);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AghArQgQgPAAgcQAAgaAQgQQAMgMAVAAQAWAAAMAMQAPAPAAAbQAAAcgPAPQgMAMgWAAQgVAAgMgMgAgTgaQgHAKAAAQQAAARAHAKQAIAJALAAQANAAAHgJQAIgKAAgRQAAgQgIgKQgIgJgMAAQgLAAgIAJg");
	this.shape_11.setTransform(55,18.8,0.639,0.639);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AggAoQgMgOAAgaQAAgaAOgOQAMgNASAAQAaAAAMARQAGAJABAKIgVAAQgCgFgEgGQgGgHgLAAQgKAAgGAKQgHAKAAAPQAAARAHAJQAHAJAJAAQALAAAGgIQAEgDACgJIAVAAQgDARgLALQgLALgTAAQgUAAgNgOg");
	this.shape_12.setTransform(48,18.8,0.639,0.639);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AAUA0IgphJIAABJIgUAAIAAhnIAXAAIAnBHIAAhHIAVAAIAABng");
	this.shape_13.setTransform(41.3,18.8,0.639,0.639);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AAZA0IgGgWIglAAIgHAWIgXAAIAlhnIAXAAIAlBngAgMAMIAZAAIgNgng");
	this.shape_14.setTransform(34.6,18.8,0.639,0.639);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AgpA0IAAhnIAwAAQATAAAIALQAFAIAAAIQAAAJgFAHQgDADgFACQAJADADAFQAEAGAAAJQAAAJgEAIQgEAGgEACQgGAFgFAAIgPACgAgUAiIAXAAQAHgBADgCQAHgCAAgKQAAgJgGgCQgFgCgGgBIgXAAgAgUgJIAXAAQAHAAAEgDQAEgDAAgHQAAgGgFgDQgFgBgIgBIgUAAg");
	this.shape_15.setTransform(28,18.8,0.639,0.639);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AAUA0IgphJIAABJIgUAAIAAhnIAXAAIAnBHIAAhHIAVAAIAABng");
	this.shape_16.setTransform(18.7,18.8,0.639,0.639);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AgjAkQgFgKAAgQIAAg+IAWAAIAAA+QAAALACAEQAEAJAMAAQANAAAEgJQACgEAAgLIAAg+IAWAAIAAA+QAAAQgFAKQgKARgaAAQgZAAgKgRg");
	this.shape_17.setTransform(12,18.9,0.639,0.639);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AgmA0IAAhnIBKAAIAAATIg1AAIAAAWIAxAAIAAAQIgxAAIAAAbIA4AAIAAATg");
	this.shape_18.setTransform(3.1,18.8,0.639,0.639);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AAUA0IgphJIAABJIgUAAIAAhnIAXAAIAnBHIAAhHIAVAAIAABng");
	this.shape_19.setTransform(-3.5,18.8,0.639,0.639);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AgmA0IAAhnIBKAAIAAATIg1AAIAAAWIAxAAIAAAQIgxAAIAAAbIA4AAIAAATg");
	this.shape_20.setTransform(-9.8,18.8,0.639,0.639);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("AgJA0IAAhnIATAAIAABng");
	this.shape_21.setTransform(-14.3,18.8,0.639,0.639);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("AgKA0IAAhUIgfAAIAAgTIBTAAIAAATIggAAIAABUg");
	this.shape_22.setTransform(-18.4,18.8,0.639,0.639);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFFFFF").s().p("AAZA0IgHgWIgkAAIgHAWIgXAAIAlhnIAXAAIAlBngAgMAMIAZAAIgNgng");
	this.shape_23.setTransform(-26.8,18.8,0.639,0.639);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FFFFFF").s().p("AgrA0IAAhnIArAAQALAAAGACQALAFAGAJQAGAIACAJQACAHAAAKQAAASgJAPQgLATgYABgAgVAiIAUAAQANAAAGgPQAEgJAAgKQAAgPgFgJQgFgIgNgBIgUAAg");
	this.shape_24.setTransform(-33.4,18.8,0.639,0.639);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#FFFFFF").s().p("AgJA0IAAhnIATAAIAABng");
	this.shape_25.setTransform(-38.2,18.8,0.639,0.639);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#FFFFFF").s().p("AgJA0IgjhnIAXAAIAVBOIAWhOIAXAAIgjBng");
	this.shape_26.setTransform(-42.5,18.8,0.639,0.639);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#FFFFFF").s().p("AgkAkQgEgLAAgPIAAg+IAWAAIAAA+QAAAMACADQAFAJALAAQANAAADgJQADgDAAgMIAAg+IAXAAIAAA+QgBAQgFAKQgKARgaAAQgZAAgLgRg");
	this.shape_27.setTransform(-51.5,18.9,0.639,0.639);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#FFFFFF").s().p("AgKA0IAAhUIgfAAIAAgTIBTAAIAAATIggAAIAABUg");
	this.shape_28.setTransform(-57.7,18.8,0.639,0.639);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-60.4,-21.3,118.6,43.6);


(lib.Símbolo5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgrA3IAAhtIBXAAIAABtg");
	this.shape.setTransform(37.8,-18.7,0.13,0.13);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AiYDyQg8gxgIhhIBDAAQAEBBAtAlQArAiBDAAQA4AAAqgXQAygdAAg0QAAgrglgZQgagRg4gOIhTgTQhMgSgigbQgrgjAAhAQAAhNBCgpQA5gjBQAAQBWAAA2ArQA5AvADBVIhDAAQgCg7gqgfQglgdg7AAQg0AAgjAUQgqAZAAAxQAAAnAnAZQAZAQAxAMIBXAUQBBAKApAgQAxApAABCQAABShHAtQg8AlhYAAQhgAAg6gug");
	this.shape_1.setTransform(32.9,-21.5,0.13,0.13);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("Ai+DKQhDhQAAh6QAAh6BDhQQBHhVB3AAQB4AABHBVQBCBQAAB6QAAB6hCBQQhHBWh4AAQh3AAhHhWgAiOieQgwBBAABdQAABeAwBBQA1BJBZAAQBaAAA1hJQAwhBAAheQAAhdgwhBQg1hJhaAAQhZAAg1BJg");
	this.shape_2.setTransform(26.1,-21.5,0.13,0.13);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AggF5IAAogIBBAAIAAIggAggkNIAAhrIBBAAIAABrg");
	this.shape_3.setTransform(21.4,-22.8,0.13,0.13);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AiuDKQhChQAAh6QAAh6BChQQBHhVB3AAQBaAAA6AvQA+AxALBbIhDAAQgOg/gmghQgngjg/AAQhYAAg1BJQgxBBABBdQgBBeAxBBQA1BJBYAAQA+AAAtgrQAtgsAGhEIBDAAQgOBig7A5Qg9A4hbAAQh3AAhHhWg");
	this.shape_4.setTransform(16.9,-21.5,0.13,0.13);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AggF5IAAogIBBAAIAAIggAggkNIAAhrIBBAAIAABrg");
	this.shape_5.setTransform(12.4,-22.8,0.13,0.13);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgfEQIjSofIBKAAICpHdIACAAICpndIBFAAIjMIfg");
	this.shape_6.setTransform(8.3,-21.5,0.13,0.13);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AiFEUIAAofIA9AAIAACAIACAAQAahDAzgkQA2gkBJADIAABDQhYgFg4A6Qg5A4AABWIAAEhg");
	this.shape_7.setTransform(3.7,-21.5,0.13,0.13);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("Ai4DKQg6hNAAh9QAAh2A6hPQBDhaB4AAQB7AABABgQA5BUgEB8ImiAAQABBVApA7QAxBHBXAAQBFAAAtgnQAogjARhCIBCAAQgWBgg4AxQg7AzhkAAQh5AAhChWgAh6irQgtA1gIBRIFfAAQgDhQgtg3Qgwg7hNAAQhLAAgyA8g");
	this.shape_8.setTransform(-2.1,-21.5,0.13,0.13);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AiYDyQg8gxgIhhIBCAAQAFBBAtAlQArAiBCAAQA4AAAqgXQA0gdAAg0QgBgrgkgZQgagRg5gOIhTgTQhNgSgggbQgsgjAAhAQAAhNBCgpQA4gjBRAAQBWAAA1ArQA6AvADBVIhCAAQgDg7gpgfQgngdg6AAQg1AAgiAUQgrAZAAAxQAAAnAoAZQAaAPAwANIBXAUQBBAKApAgQAxApAABCQAABShHAtQg8AlhYAAQhgAAg6gug");
	this.shape_9.setTransform(-8.6,-21.5,0.13,0.13);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AiXDyQg+gxgHhhIBCAAQAFBBAtAlQArAiBCAAQA5AAApgXQAzgdABg0QgBgrgkgZQgbgRg4gOIhUgTQhMgSgggbQgsgjAAhAQAAhNBDgpQA3gjBRAAQBWAAA1ArQA6AvADBVIhCAAQgDg7gqgfQgmgdg6AAQg1AAgiAUQgqAZAAAxQAAAnAnAZQAZAQAwAMIBYAUQBBAKApAgQAxApAABCQAABShIAtQg8AlhXAAQhhAAg4gug");
	this.shape_10.setTransform(-18.4,-21.5,0.13,0.13);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("Ai4DKQg6hNAAh9QAAh2A6hPQBDhaB4AAQB7AABBBgQA4BUgEB8ImiAAQABBVApA7QAxBHBXAAQBGAAAsgnQAogjARhCIBDAAQgWBgg4AxQg8AzhkAAQh5AAhChWgAh6irQgsA1gJBRIFfAAQgChQgtg3Qgxg7hNAAQhLAAgyA8g");
	this.shape_11.setTransform(-24.9,-21.5,0.13,0.13);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgPFLQgagbABhFIAAlzIhfAAIAAg5IBfAAIAAikIBBAAIAACkIBvAAIAAA5IhvAAIAAFtQAAAlAJAOQAMATAhACQAYAAAhgDIAAA5IgdACIgeABQhDAAgZgbg");
	this.shape_12.setTransform(-30.3,-22.5,0.13,0.13);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("ACaEYIAAlSQABhOgdgoQgigvhMAAQhMAAguA1QgtA0gCBSIAAE8IhDAAIAAofIBDAAIAABeIACAAQASgxAxgfQAxgeA4AAQBuAAAwA4QAqAyAABoIAAFdg");
	this.shape_13.setTransform(-35.6,-21.6,0.13,0.13);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("Ai4DKQg6hNAAh9QAAh2A6hPQBDhaB3AAQB7AABBBgQA5BUgEB8ImiAAQABBVApA7QAxBHBWAAQBGAAAtgnQAogjARhCIBCAAQgWBgg4AxQg7AzhlAAQh5AAhBhWgAh6irQgtA1gIBRIFfAAQgDhQgtg3Qgwg7hOAAQhLAAgxA8g");
	this.shape_14.setTransform(-42.4,-21.5,0.13,0.13);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AiFEUIAAofIA9AAIAACAIACAAQAahDAzgkQA2gkBKADIAABDQhZgFg4A6Qg5A4AABWIAAEhg");
	this.shape_15.setTransform(-47.2,-21.5,0.13,0.13);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("Ai4DKQg6hNAAh9QAAh2A6hPQBDhaB3AAQB8AABABgQA5BUgEB8ImiAAQABBVApA7QAxBHBWAAQBGAAAtgnQAogjARhCIBCAAQgWBgg4AxQg7AzhlAAQh5AAhBhWgAh6irQgtA1gIBRIFfAAQgDhQgtg3Qgwg7hOAAQhLAAgxA8g");
	this.shape_16.setTransform(-52.9,-21.5,0.13,0.13);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AguF5IAAnnIhdAAIAAg5IBdAAIAAgxQgBhOAagmQAegsBLAAQAcAAAcAEIAAA6QgdgGgTAAQgyAAgOAfQgJARAAA5IAAAwIBsAAIAAA5IhsAAIAAHng");
	this.shape_17.setTransform(-57.9,-22.8,0.13,0.13);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AggF5IAAogIBBAAIAAIggAggkNIAAhrIBBAAIAABrg");
	this.shape_18.setTransform(-60.7,-22.8,0.13,0.13);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("Ai+EqQg8hPAAh7QAAh6A8hOQBChXB3ABQA+AAAyAeQA3AgAUA5IACAAIAAk5IBDAAIAALxIg9AAIAAhoIgCAAQgVA0g6AiQg3Aig7AAQh3AAhChXgAiOg9QgqA+AABfQAABfAqBAQAxBKBYAAQBgAAAzhKQAqg+AAhhQAAhggqg9QgzhKhgABQhYgBgxBKg");
	this.shape_19.setTransform(-65.7,-22.7,0.13,0.13);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AjFD5Qg2gqAAhOQAAhmBcgkQAtgSCagSQAvgGAQgLQAWgPAAgqQAAg/gqgbQgigWhAAAQhCAAglAeQgqAhgBBAIhDAAQAFhcA9gwQA5grBiAAQDHAAAACwIAAEfQAAApAnAAQAJAAAMgFIAAA4QgTAEgYABQgvAAgSgaQgNgWAAgwIgCAAQgmA5goAZQgvAdhIAAQhRAAgwgngABDAAIhVAMQg0AHgeAKQhVAaAABFQAAAwAmAfQAjAdAxAAQBOAAA2guQA5gwgBhNIAAhVIgCAAQgJARgvAHg");
	this.shape_20.setTransform(89.4,-36.5,0.13,0.13);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("Ai+DKQhDhPAAh7QAAh6BDhPQBHhWB3AAQB5AABGBWQBDBPAAB6QAAB7hDBPQhGBWh5AAQh3AAhHhWgAiOieQgvBAAABeQAABeAvBBQA1BJBZAAQBaAAA2hJQAvhBAAheQAAhdgvhBQg2hJhaAAQhZAAg1BJg");
	this.shape_21.setTransform(78.7,-36.5,0.13,0.13);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("AiYDyQg8gxgIhhIBCAAQAEBBAuAkQAqAjBDAAQA4AAAqgXQA0gcAAg0QgBgrgkgaQgagRg5gOIhUgTQhMgSgggbQgsgiAAhBQAAhNBCgpQA4gjBRAAQBWAAA1ArQA6AvADBWIhDAAQgCg8gqgfQgmgdg6AAQg0AAgjAVQgrAZAAAwQAAAnAoAZQAZAQAxAMIBXAUQBBALApAfQAxApAABCQAABShIAsQg7AmhYAAQhgAAg6gug");
	this.shape_22.setTransform(72,-36.5,0.13,0.13);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFFFFF").s().p("Ai4DKQg6hMAAh+QAAh1A6hQQBDhaB4AAQB7AABBBgQA4BTgEB9ImiAAQABBVApA7QAxBHBXAAQCHAAAkiLIBDAAQgWBgg4AwQg8AzhkAAQh5AAhChWgAh6irQgsA2gJBQIFfAAQgDhQgsg3Qgxg7hNAAQhLAAgyA8g");
	this.shape_23.setTransform(65.5,-36.5,0.13,0.13);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FFFFFF").s().p("AiuDKQhChPAAh7QAAh6BChPQBHhWB3AAQBaAAA7AvQA9AyALBaIhDAAQgOg/glghQgogjg/AAQhZAAg1BJQgvBBgBBdQABBeAvBBQA1BJBZAAQA+AAAtgsQAtgrAHhEIBCAAQgNBig9A4Qg8A5hbAAQh3AAhHhWg");
	this.shape_24.setTransform(58.7,-36.5,0.13,0.13);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#FFFFFF").s().p("AiuDKQhChPAAh7QAAh6BChPQBIhWB2AAQBaAAA6AvQA+AyALBaIhCAAQgPg/glghQgngjhAAAQhYAAg1BJQgxBBAABdQAABeAxBBQA1BJBYAAQA+AAAtgsQAtgrAGhEIBDAAQgOBig7A4Qg9A5hbAAQh2AAhIhWg");
	this.shape_25.setTransform(51.9,-36.5,0.13,0.13);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#FFFFFF").s().p("AjFD5Qg2gqAAhOQAAhmBcgkQAtgSCagSQAvgGAQgLQAWgPAAgqQAAg/gqgbQgigWhBAAQhBAAgmAeQgpAhgBBAIhDAAQAEhcA+gwQA5grBiAAQDHAAAACwIAAEfQAAApAnAAQAJAAAMgFIAAA4QgTAEgYABQgvAAgSgaQgOgWAAgwIgCAAQgmA6gnAYQgvAdhIAAQhRAAgwgngABDAAIhVAMQg1AHgdAKQhVAaAABFQAAAwAmAfQAjAdAxAAQBNAAA2guQA6gwgBhNIAAhVIgCAAQgJARgvAHg");
	this.shape_26.setTransform(45.2,-36.5,0.13,0.13);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#FFFFFF").s().p("AiYDyQg8gxgIhhIBCAAQAEBBAuAkQArAjBCAAQA4AAAqgXQA0gcAAg0QgBgrgkgaQgagRg5gOIhTgTQhNgSgggbQgsgiAAhBQAAhNBCgpQA5gjBRAAQBVAAA1ArQA6AvADBWIhCAAQgDg8gpgfQgmgdg7AAQg0AAgjAVQgqAZAAAwQAAAnAoAZQAZAQAwAMIBXAUQBBALApAfQAxApAABCQAABShHAsQg8AmhXAAQhhAAg6gug");
	this.shape_27.setTransform(35,-36.5,0.13,0.13);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#FFFFFF").s().p("AjFFiQg2gqAAhPQAAhlBcgmQAsgSCagSQAwgGAQgLQAWgPAAgoQAAg/gqgbQgigWhBAAQhBAAgmAeQgpAhgCA/IhCAAQAEhcA+gvQA5grBiAAQDHAAAACvIAAEgQAAAoAnAAQAJAAAMgEIAAA4QgTAEgYAAQgwAAgRgaQgOgVAAgwIgCAAQgmA6gnAYQgvAdhJAAQhQAAgwgngABDBnIhWANQg0AIgdAKQhVAaAABFQAAAwAmAfQAjAdAxAAQBNAAA2guQA6gwgBhNIAAhXIgCAAQgJAQgvAIgAhKjzIBtiVIBTAAIiKCVg");
	this.shape_28.setTransform(28.7,-37.8,0.13,0.13);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#FFFFFF").s().p("AiFEUIAAogIA9AAIAACAIACAAQAahCAzgkQA2gkBJADIAABDQhYgFg4A6Qg5A4AABWIAAEhg");
	this.shape_29.setTransform(23.5,-36.5,0.13,0.13);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#FFFFFF").s().p("Ai+EqQg8hOAAh8QAAh5A8hPQBDhWB2AAQA+AAAyAeQA3AgAUA5IACAAIAAk5IBDAAIAALxIg9AAIAAhnIgCAAQgVA0g6AiQg3Ahg7AAQh2AAhDhXgAiOg8QgqA9AABfQAABfAqBAQAxBKBYAAQBgAAAzhKQAqg+AAhhQAAhggqg8QgzhKhgAAQhYAAgxBKg");
	this.shape_30.setTransform(17.2,-37.7,0.13,0.13);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#FFFFFF").s().p("ACaEYIAAlSQAAhOgcgoQgjgvhLAAQhMAAgvA1QgtA0gBBSIAAE8IhDAAIAAogIBDAAIAABfIABAAQATgxAxgfQAxgeA4AAQBtAAAxA4QAqAyAABoIAAFdg");
	this.shape_31.setTransform(10.1,-36.6,0.13,0.13);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#FFFFFF").s().p("Ai4DKQg6hMAAh+QAAh1A6hQQBDhaB4AAQB7AABABgQA5BTgEB9ImiAAQABBVApA7QAxBHBXAAQBGAAAsgnQAogjARhBIBDAAQgXBgg4AwQg7AzhkAAQh5AAhChWgAh6irQgtA2gIBQIFfAAQgDhQgsg3Qgxg7hNAAQhLAAgyA8g");
	this.shape_32.setTransform(3.2,-36.5,0.13,0.13);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#FFFFFF").s().p("AgOFLQgagbAAhFIAAlzIhfAAIAAg5IBfAAIAAijIBBAAIAACjIBvAAIAAA5IhvAAIAAFuQAAAkAJAPQAMASAhACQAcAAAdgDIAAA5Ig7ACQhDAAgYgag");
	this.shape_33.setTransform(-2.3,-37.5,0.13,0.13);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#FFFFFF").s().p("Ai4DKQg6hMAAh+QAAh1A6hQQBDhaB4AAQB7AABABgQA5BTgEB9ImiAAQABBVApA7QAxBHBXAAQBGAAAsgnQAogjARhBIBDAAQgWBgg4AwQg8AzhkAAQh5AAhChWgAh6irQgtA2gIBQIFfAAQgDhQgsg3Qgxg7hNAAQhLAAgyA8g");
	this.shape_34.setTransform(-10.8,-36.5,0.13,0.13);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#FFFFFF").s().p("AjcBJIAAlgIBCAAIAAFhQADBNAgAjQAjAmBNAAQBOAAAthDQAmg8ABhbIAAkdIBCAAIAAIgIg9AAIAAhjIgDAAQgZA2gzAfQgxAdg9AAQi/AAAAjPg");
	this.shape_35.setTransform(-17.7,-36.4,0.13,0.13);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#FFFFFF").s().p("AC4F9IAAkxIgBAAQgVA4g2AhQgzAeg+AAQh2AAhDhXQg8hOAAh6QAAh7A8hPQBDhWB2AAQA7AAA4AhQA5AiAUA0IADAAIAAhoIA9AAIAALqgAiNj6QgqA/AABfQAABdAqBAQAvBKBZAAQBhAAAyhKQAqg+AAhfQAAhggqg+QgyhKhhAAQhZAAgvBKg");
	this.shape_36.setTransform(-25.2,-35.3,0.13,0.13);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#FFFFFF").s().p("AjFD5Qg2gqAAhOQAAhmBcgkQAtgSCagSQAvgGAQgLQAWgPAAgqQAAg/gqgbQgigWhAAAQhCAAglAeQgqAhgBBAIhDAAQAFhcA9gwQA5grBiAAQDHAAAACwIAAEfQAAApAnAAQAKAAALgFIAAA4QgSAEgZABQgvAAgSgaQgNgWAAgwIgCAAQgmA5goAZQgvAdhIAAQhRAAgwgngABDAAIhVAMQg0AHgeAKQhVAaAABFQAAAwAmAfQAjAdAxAAQBOAAA2guQA5gwgBhNIAAhVIgCAAQgJARgvAHg");
	this.shape_37.setTransform(-35.5,-36.5,0.13,0.13);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#FFFFFF").s().p("AggF5IAArxIBBAAIAALxg");
	this.shape_38.setTransform(-40.2,-37.8,0.13,0.13);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#FFFFFF").s().p("ACaEYIAAlSQAAhOgcgoQgigvhMAAQhLAAgwA1QgsA0gDBSIAAE8IhCAAIAAogIBCAAIAABfIADAAQASgxAxgfQAxgeA4AAQBuAAAvA4QArAyAABoIAAFdg");
	this.shape_39.setTransform(-48.3,-36.6,0.13,0.13);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#FFFFFF").s().p("Ai+DKQhChPAAh7QAAh6BChPQBHhWB3AAQB4AABHBWQBCBPAAB6QAAB7hCBPQhHBWh4AAQh3AAhHhWgAiOieQgwBBAABdQAABeAwBBQA1BJBZAAQBaAAA1hJQAwhBAAheQAAhdgwhBQg1hJhaAAQhZAAg1BJg");
	this.shape_40.setTransform(-55.4,-36.5,0.13,0.13);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#FFFFFF").s().p("AiuDKQhChPAAh7QAAh6BChPQBHhWB3AAQBaAAA7AvQA9AyALBaIhDAAQgOg/glghQgogjg/AAQhZAAg1BJQgvBBAABdQAABeAvBBQA1BJBZAAQA+AAAtgsQAtgrAHhEIBCAAQgNBjg8A3Qg9A5hbAAQh3AAhHhWg");
	this.shape_41.setTransform(-62.4,-36.5,0.13,0.13);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#FFFFFF").s().p("AhBBXQBBgIAAhUIhBAAIAAiPICDAAIAACPQAAA8gkArQgiArg9AHg");
	this.shape_42.setTransform(63.9,-55.8,0.13,0.13);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#FFFFFF").s().p("Ag7F5IAArxIB3AAIAALxg");
	this.shape_43.setTransform(60.7,-52.8,0.13,0.13);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#FFFFFF").s().p("ACHERQgZgQgHgkQgiAhg2ARQgvARg0gBQhPABg0goQg4gsAAhMQAAhcBDgmQAsgbBjgLQArgIBFgKQAygOAAguQAAgqgngSQgcgNgsAAQg1AAgfAUQghAXgEArIh4AAQAGhhBMgvQA/glBngBQBZABA7AjQBFAqAABRIAAEXQAAAXAGAJQAGAKARAAQAQAAANgDIAABUQgOAFgXAEQgYAFgPgBQgnAAgWgOgAAZAVQgzAGgbAFQgtAHgXASQgeAWAAAsQAAAkAoATQAfAPAoAAQAvAAAngYQAvgdAAgzIAAhZQgWAOguAHg");
	this.shape_44.setTransform(55.7,-51.5,0.13,0.13);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#FFFFFF").s().p("AgmFCQgcgegChKIAAlBIhbAAIAAhaIBbAAIAAikIB3AAIAACkIBtAAIAABaIhtAAIAAEjQAAApAJAOQAMATAlAAQAiAAARgEIAABdQg0AGgaABQhXAAghgkg");
	this.shape_45.setTransform(49.7,-52.5,0.13,0.13);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#FFFFFF").s().p("Ag7F5IAAohIB3AAIAAIhgAg7kGIAAhyIB3AAIAAByg");
	this.shape_46.setTransform(46.2,-52.8,0.13,0.13);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#FFFFFF").s().p("AihFgQhNgtgHhYIB4AAQAKAuAmATQAdAPA0AAQCNAAAAiMIAAhTIgCAAQgaAtgrAaQgsAZgxAAQh7AAhBhWQg5hMAAh8QAAhyBBhOQBFhRBxgBQA0AAApAXQAtAWAWAtIACAAIAAhLIB4AAIAAIEQAAB6hFA/QhFA8iAABQhfgBhBgkgAhwjnQggAzAABOQAABKAiAwQAnA4BHAAQBIABAng9QAigxAAhOQAAhOgigwQgng3hIAAQhKgBgmA+g");
	this.shape_47.setTransform(40.7,-50.2,0.13,0.13);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#FFFFFF").s().p("Ag7F5IAAohIB3AAIAAIhgAg7kGIAAhyIB3AAIAAByg");
	this.shape_48.setTransform(35.4,-52.8,0.13,0.13);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#FFFFFF").s().p("AlCF5IAArxIE5AAQClAABXBuQBQBkAACmQAACmhQBkQhXBvilAAgAi9ENICCAAQCOAAA7hOQAwg/AAiAQAAh/gwhAQg7hNiOAAIiCAAg");
	this.shape_49.setTransform(29.4,-52.8,0.13,0.13);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#FFFFFF").s().p("ABnDdQgiAhg2ARQgvARg0gBQhPABgzgoQg6gsAAhMQAAhcBEgmQAsgbBjgLQArgIBFgKQAygOAAguQAAgqgmgSQgdgNgsAAQg1AAgfAUQghAXgEArIh4AAQAGhhBMgvQA/glBngBQBYABA8AjQBFAqAABRIAAEXQAAAXAGAJQAGAKARAAQAQAAANgDIAABUQgOAFgXAEQgYAFgPgBQhQAAgNhCgAAaAVQg0AGgaAFQgvAHgWASQgeAWAAAsQAAAkAoATQAfAPAoAAQAvAAAngYQAvgdAAgzIAAhZQgWAOgtAHg");
	this.shape_50.setTransform(17.4,-51.5,0.13,0.13);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#FFFFFF").s().p("AhBERIjGohICDAAICIGiIACAAICGmiIB8AAIjDIhg");
	this.shape_51.setTransform(10.2,-51.5,0.13,0.13);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#FFFFFF").s().p("Ag7F5IAAohIB3AAIAAIhgAg7kGIAAhyIB3AAIAAByg");
	this.shape_52.setTransform(5.3,-52.8,0.13,0.13);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#FFFFFF").s().p("AgmFCQgcgegChKIAAlBIhbAAIAAhaIBbAAIAAikIB3AAIAACkIBsAAIAABaIhsAAIAAEjQAAAqAJANQALATAmAAIAZAAQAOgBALgDIAABdIgmAEQgYADgQAAQhWAAghgkg");
	this.shape_53.setTransform(1.6,-52.5,0.13,0.13);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#FFFFFF").s().p("Ag7F5IAArxIB3AAIAALxg");
	this.shape_54.setTransform(-1.9,-52.8,0.13,0.13);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("#FFFFFF").s().p("Ai+DiQgwg0AAhsIAAlZIB4AAIAAFNQAABGAbAgQAaAdA0AAQCEAAAAiVIAAk7IB4AAIAAIhIh2AAIAAhNIgCAAQgWApgtAZQgqAZgtAAQhqAAgxg2g");
	this.shape_55.setTransform(-7.1,-51.4,0.13,0.13);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("#FFFFFF").s().p("AEKF5IAApFIgDAAIjRJFIhrAAIjRpFIgCAAIAAJFIh+AAIAArxIC6AAIDOJNIACAAIDLpNIC4AAIAALxg");
	this.shape_56.setTransform(-16.9,-52.8,0.13,0.13);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("#FFFFFF").s().p("ABnDdQgiAhg2ARQgvARg0gBQhPABgzgoQg6gsAAhMQABhcBDgmQAtgbBigLQArgIBFgKQAygOAAguQAAgqgmgSQgdgNgsAAQg0AAggAUQghAXgDArIh6AAQAGhhBNgvQA/glBngBQBYABA8AjQBFAqAABRIAAEXQAAAXAGAJQAGAKARAAQARAAANgDIAABUQgPAFgXAEQgZAFgOgBQhQAAgNhCgAAZAVQgzAGgaAFQgvAHgWASQgeAWAAAsQAAAkAoATQAeAPApAAQAvAAAngYQAvgdAAgzIAAhZQgWAOguAHg");
	this.shape_57.setTransform(-29.7,-51.5,0.13,0.13);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("#FFFFFF").s().p("Ai/DPQhGhOAAiBQAAh2BHhSQBLhXB0AAQB+ABBMBhQBIBfgQB9ImPAAQAABEAkAtQAnAwBGABQBlgBAghaIByAAQgTBXhGAzQhCAvhcAAQh8AAhIhQgAhjiWQgnApgCA/IEXAAQgDg9glgoQgngtg7ABQg7gBgpAqg");
	this.shape_58.setTransform(-37.1,-51.5,0.13,0.13);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("#FFFFFF").s().p("AB3EYIAAlWQgChAgagdQgZgdg2AAQg5AAglAqQgkAoAAA+IAAFAIh5AAIAAohIBzAAIAABRIACACQAbguAtgZQAtgaAzAAQBbAAAyAvQA1AxAABaIAAF1g");
	this.shape_59.setTransform(-44.6,-51.6,0.13,0.13);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("#FFFFFF").s().p("AhjGCIAAohIB3AAIAAIhgAh1jqIBfiXICMAAIiUCXg");
	this.shape_60.setTransform(-49.4,-52.9,0.13,0.13);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("#FFFFFF").s().p("AkBF5IAArxICFAAIAAJ/IF9AAIAAByg");
	this.shape_61.setTransform(-54.7,-52.8,0.13,0.13);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("#FFFFFF").s().p("AhBCUIAAiPQAAg3AngqQAignA6gRIAAA9QggAMgQAYQgRAZAAAfIBBAAIAACPg");
	this.shape_62.setTransform(-60.7,-55.8,0.13,0.13);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("#FFFFFF").s().p("AjFD6Qg2grAAhPQAAhkBcglQAtgRCagTQAvgGAQgLQAWgQAAgpQAAg+gqgbQgigXhBAAQhBAAgmAeQgpAhgCA/IhCAAQAEhcA+guQA5gsBiAAQDHAAAACwIAAEfQAAAoAnAAQAKAAALgEIAAA4QgWAFgVgBQgvAAgSgaQgOgVAAgwIgCAAQgmA6gnAYQgvAdhIAAQhRAAgwgmgABjgHQgKADgWAEIhWALQg0AIgdAKQhVAaAABFQAAAxAmAeQAjAdAxAAQBNAAA2gtQA6gxgBhNIAAhVIgCAAQgFALgTAGg");
	this.shape_63.setTransform(88.3,-66.5,0.13,0.13);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f("#FFFFFF").s().p("AiFEUIAAogIA9AAIAACAIACAAQAahCAzgkQA2gkBJADIAABDQhYgFg4A6Qg5A4AABWIAAEhg");
	this.shape_64.setTransform(83.2,-66.5,0.13,0.13);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f("#FFFFFF").s().p("AgOFLQgagaAAhGIAAlzIhfAAIAAg4IBfAAIAAikIBBAAIAACkIBvAAIAAA4IhvAAIAAFuQAAAkAJAPQAMATAhACQAcAAAdgDIAAA5Ig7ABQhDABgYgbg");
	this.shape_65.setTransform(78.7,-67.5,0.13,0.13);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f("#FFFFFF").s().p("AiYDyQg8gygIhgIBDAAQAEBBAsAkQArAjBEAAQA3AAArgXQAygcAAg1QABgqgmgZQgZgSg5gOIhUgTQhMgTghgaQgrgjAAhAQAAhNBDgpQA4gjBQAAQBWAAA1AsQA6AuADBWIhDAAQgCg8gqgfQgmgdg7AAQgzAAgjAVQgqAYAAAxQAAAnAnAZQAaAQAvAMIBXAUQBCAKApAgQAxApAABCQAABShHAsQg9AmhXAAQhhAAg5gug");
	this.shape_66.setTransform(73.9,-66.5,0.13,0.13);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f("#FFFFFF").s().p("Ai4DKQg6hNAAh9QAAh2A6hPQBDhaB4AAQB7AABBBgQA4BUgEB8ImiAAQABBUApA8QAxBHBXAAQBGAAAsgnQAogjARhCIBDAAQgWBgg4AwQg8A0hkAAQh5AAhChWgAh6irQgsA1gJBSIFfAAQgChRgtg2Qgxg8hNAAQhLAAgyA8g");
	this.shape_67.setTransform(67.4,-66.5,0.13,0.13);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f("#FFFFFF").s().p("AjcBJIAAlgIBDAAIAAFhQACBNAgAjQAiAmBNAAQBPAAAshEQAng7AAhcIAAkcIBDAAIAAIgIg9AAIAAhjIgCAAQgaA2g0AfQgxAdg8AAQi/AAAAjPg");
	this.shape_68.setTransform(60.4,-66.4,0.13,0.13);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f("#FFFFFF").s().p("ACbEYIAAlSQAAhOgegoQgigvhLAAQhMAAgvA1QgtA0gCBSIAAE8IhCAAIAAogIBCAAIAABeIACAAQATgwAxgfQAxgeA4AAQBuAAAvA4QArAyAABoIAAFdg");
	this.shape_69.setTransform(53.4,-66.6,0.13,0.13);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f("#FFFFFF").s().p("ACbEYIAAlSQAAhOgdgoQgjgvhLAAQhMAAguA1QguA0gCBSIAAE8IhCAAIAAogIBCAAIAABeIADAAQARgwAygfQAwgeA5AAQBuAAAvA4QArAyAABoIAAFdg");
	this.shape_70.setTransform(42.9,-66.6,0.13,0.13);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f("#FFFFFF").s().p("Ai+DLQhDhRAAh6QAAh6BDhPQBHhWB3AAQB4AABHBWQBCBPAAB6QAAB6hCBRQhHBVh4AAQh3AAhHhVgAiOifQgwBCAABdQAABeAwBCQA1BIBZAAQBaAAA2hIQAvhCAAheQAAhdgvhCQg2hIhaAAQhZAAg1BIg");
	this.shape_71.setTransform(35.7,-66.5,0.13,0.13);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f("#FFFFFF").s().p("AiuDLQhChRAAh6QAAh6BChPQBHhWB3AAQBaAAA7AuQA9AyALBbIhDAAQgOg/glghQgogjg/AAQhZAAg1BIQgwBCAABdQAABeAwBCQA1BIBZAAQA+AAAtgsQAtgrAHhEIBCAAQgNBig9A5Qg8A4hbAAQh3AAhHhVg");
	this.shape_72.setTransform(28.7,-66.5,0.13,0.13);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f("#FFFFFF").s().p("AjFD6Qg2grAAhPQAAhkBcglQAtgRCagTQAvgGAQgLQAWgQAAgpQAAg+gqgbQgigXhAAAQhCAAglAeQgqAhgBA/IhDAAQAFhcA9guQA5gsBiAAQDHAAAACwIAAEfQAAAoAnAAQALAAAKgEIAAA4QgVAFgWgBQgvAAgSgaQgNgVAAgwIgCAAQgmA6goAYQgvAdhIAAQhRAAgwgmgABjgHIggAHIhVALQg0AIgeAKQhVAaAABFQAAAxAmAeQAjAdAxAAQBOAAA2gtQA5gxgBhNIAAhVIgCAAQgFALgTAGg");
	this.shape_73.setTransform(18.6,-66.5,0.13,0.13);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f("#FFFFFF").s().p("Ai+ErQg8hPAAh8QAAh5A8hOQBChXB3AAQA+AAAyAeQA3AhAUA4IACAAIAAk5IBDAAIAALxIg9AAIAAhnIgCAAQgVAzg6AjQg3Ahg7AAQh3AAhChWgAiOg8QgqA+AABeQAABfAqBAQAxBKBYAAQBgAAAzhKQAqg+AAhhQAAhggqg8QgzhKhgAAQhYAAgxBKg");
	this.shape_74.setTransform(11.1,-67.7,0.13,0.13);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f("#FFFFFF").s().p("AjFD6Qg2grAAhPQAAhkBcglQAtgRCagTQAvgGAQgLQAXgQAAgpQAAg+gqgbQgjgXhAAAQhCAAglAeQgqAhgBA/IhDAAQAFhcA9guQA5gsBiAAQDHAAAACwIAAEfQAAAoAnAAQALAAAKgEIAAA4QgVAFgWgBQgvAAgRgaQgOgVAAgwIgCAAQgmA6goAYQgvAdhIAAQhRAAgwgmgABjgHIggAHIhVALQg0AIgeAKQhUAaAABFQAAAxAlAeQAjAdAxAAQBOAAA2gtQA5gxAAhNIAAhVIgDAAQgFALgTAGg");
	this.shape_75.setTransform(4.2,-66.5,0.13,0.13);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f("#FFFFFF").s().p("AjiEQIAAg2IFimxIlKAAIAAg4IGfAAIAAAvIlnG4IF1AAIAAA4g");
	this.shape_76.setTransform(-2.3,-66.5,0.13,0.13);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f("#FFFFFF").s().p("AggF5IAAogIBBAAIAAIggAggkNIAAhrIBBAAIAABrg");
	this.shape_77.setTransform(-6.4,-67.8,0.13,0.13);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f("#FFFFFF").s().p("AggF5IAArxIBBAAIAALxg");
	this.shape_78.setTransform(-8.6,-67.8,0.13,0.13);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.f("#FFFFFF").s().p("AjFD6Qg2grAAhPQAAhkBcglQAsgRCagTQAwgGAQgLQAWgQAAgpQAAg+gqgbQgigXhBAAQhBAAgmAeQgpAhgCA/IhCAAQAEhcA+guQA5gsBiAAQDHAAAACwIAAEfQAAAoAnAAQAKAAALgEIAAA4QgWAFgVgBQgvAAgSgaQgOgVAAgwIgCAAQgmA6gnAYQgvAdhIAAQhRAAgwgmgABjgHQgKADgWAEIhWALQg0AIgdAKQhVAaAABFQAAAxAmAeQAjAdAxAAQBNAAA2gtQA6gxgBhNIAAhVIgCAAQgFALgTAGg");
	this.shape_79.setTransform(-13,-66.5,0.13,0.13);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.f("#FFFFFF").s().p("ACbEYIAAlSQgBhOgcgoQgigvhMAAQhMAAguA1QguA0gCBSIAAE8IhCAAIAAogIBCAAIAABeIADAAQARgwAygfQAwgeA5AAQBuAAAvA4QArAyAABoIAAFdg");
	this.shape_80.setTransform(-20,-66.6,0.13,0.13);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.f("#FFFFFF").s().p("Ai+DLQhDhRAAh6QAAh6BDhPQBHhWB3AAQB4AABHBWQBCBPAAB6QAAB6hCBRQhHBVh4AAQh3AAhHhVgAiOifQgwBCAABdQAABeAwBCQA1BIBZAAQBaAAA2hIQAvhCAAheQAAhdgvhCQg2hIhaAAQhZAAg1BIg");
	this.shape_81.setTransform(-27.2,-66.5,0.13,0.13);

	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.f("#FFFFFF").s().p("AiXDyQg9gygIhgIBDAAQADBBAuAkQAqAjBDAAQA4AAAqgXQAzgcAAg1QAAgqglgZQgagSg4gOIhUgTQhMgTgggaQgsgjAAhAQAAhNBCgpQA5gjBQAAQBWAAA1AsQA6AuADBWIhDAAQgCg8gqgfQgmgdg6AAQg0AAgjAVQgqAYAAAxQAAAnAnAZQAaAQAwAMIBXAUQBBAKApAgQAxApAABCQAABShHAsQg9AmhXAAQhgAAg5gug");
	this.shape_82.setTransform(-34,-66.5,0.13,0.13);

	this.shape_83 = new cjs.Shape();
	this.shape_83.graphics.f("#FFFFFF").s().p("AiGEUIAAogIA+AAIAACAIACAAQAahCAzgkQA3gkBIADIAABDQhYgFg4A6Qg5A4AABWIAAEhg");
	this.shape_83.setTransform(-38.7,-66.5,0.13,0.13);

	this.shape_84 = new cjs.Shape();
	this.shape_84.graphics.f("#FFFFFF").s().p("Ai4DKQg6hNAAh9QAAh2A6hPQBDhaB3AAQB8AABABgQA5BUgEB8ImiAAQABBUApA8QAxBHBWAAQBGAAAtgnQAogjARhCIBCAAQgWBgg4AwQg7A0hlAAQh5AAhBhWgAh6irQgtA1gIBSIFfAAQgDhRgtg2Qgwg8hOAAQhLAAgxA8g");
	this.shape_84.setTransform(-44.4,-66.5,0.13,0.13);

	this.shape_85 = new cjs.Shape();
	this.shape_85.graphics.f("#FFFFFF").s().p("Aj6F9IAArpIA9AAIAABnIADAAQAWg3A1ggQA0ggBBAAQB2AABDBXQA8BOAAB7QAAB6g8BPQhDBWh2AAQg+AAgzgeQg2ghgVg4IgBAAIAAExgAiPj+QgoA6AABoQAABfAqA+QAyBKBhAAQBYAAAwhKQAqhAABhdQgBhegqhAQgwhKhYAAQhlAAgwBGg");
	this.shape_85.setTransform(-51.5,-65.2,0.13,0.13);

	this.shape_86 = new cjs.Shape();
	this.shape_86.graphics.f("#FFFFFF").s().p("ACbEYIAAlSQAAhOgdgoQgigvhMAAQhMAAguA1QguA0gCBSIAAE8IhCAAIAAofIBCAAIAABeIADAAQASgxAxgfQAxgeA4AAQBtAAAxA4QAqAyAABoIAAFdg");
	this.shape_86.setTransform(36.5,-81.6,0.13,0.13);

	this.shape_87 = new cjs.Shape();
	this.shape_87.graphics.f("#FFFFFF").s().p("Ai+EzQhDhQAAh7QAAh5BDhQQBHhWB3AAQB4AABHBWQBDBQAAB5QAAB7hDBQQhHBWh4AAQh3AAhHhWgAiOg2QgwBAAABeQAABfAwBBQA1BJBZAAQBaAAA2hJQAvhBAAhfQAAhegvhAQg2hJhaAAQhZAAg1BJgAg9jzIBtiVIBSAAIiJCVg");
	this.shape_87.setTransform(29.4,-82.8,0.13,0.13);

	this.shape_88 = new cjs.Shape();
	this.shape_88.graphics.f("#FFFFFF").s().p("AggF5IAAogIBBAAIAAIggAggkNIAAhrIBBAAIAABrg");
	this.shape_88.setTransform(24.6,-82.8,0.13,0.13);

	this.shape_89 = new cjs.Shape();
	this.shape_89.graphics.f("#FFFFFF").s().p("AitDLQhDhQAAh7QAAh5BDhQQBHhWB2AAQBaAAA7AvQA9AxALBbIhDAAQgNg/gmghQgogjg/AAQhZAAg1BJQgvBBAABdQAABeAvBCQA1BIBZAAQA+AAAtgrQAtgsAHhEIBCAAQgOBig7A5Qg9A4hbAAQh2AAhHhVg");
	this.shape_89.setTransform(20.2,-81.4,0.13,0.13);

	this.shape_90 = new cjs.Shape();
	this.shape_90.graphics.f("#FFFFFF").s().p("ACbEYIAAlSQAAhOgdgoQgjgvhLAAQhMAAguA1QguA0gBBSIAAE8IhDAAIAAofIBDAAIAABeIACAAQASgxAxgfQAxgeA4AAQBtAAAxA4QAqAyAABoIAAFdg");
	this.shape_90.setTransform(13.2,-81.6,0.13,0.13);

	this.shape_91 = new cjs.Shape();
	this.shape_91.graphics.f("#FFFFFF").s().p("Ai4DKQg6hMAAh+QAAh2A6hPQBDhaB4AAQB7AABBBgQA4BUgEB9ImiAAQABBUApA7QAyBHBWAAQBGAAAsgnQAogjARhBIBDAAQgWBfg4AxQg8AzhkAAQh5AAhChWgAh6irQgsA2gJBRIFfAAQgDhQgsg3Qgxg8hNAAQhLAAgyA8g");
	this.shape_91.setTransform(6.4,-81.4,0.13,0.13);

	this.shape_92 = new cjs.Shape();
	this.shape_92.graphics.f("#FFFFFF").s().p("AgOFLQgagbAAhFIAAl0IhfAAIAAg4IBfAAIAAijIBBAAIAACjIBvAAIAAA4IhvAAIAAFuQAAAlAJAPQALASAhACQAdAAAdgCIAAA4Ig7ACQhEAAgXgag");
	this.shape_92.setTransform(0.9,-82.5,0.13,0.13);

	this.shape_93 = new cjs.Shape();
	this.shape_93.graphics.f("#FFFFFF").s().p("AjFD6Qg2grAAhOQAAhlBcgkQAtgSCagTQAvgFAQgMQAWgPAAgqQAAg+gqgcQgigWhAAAQhBAAgmAeQgqAhgBBAIhDAAQAFhdA9gvQA5grBiAAQDHAAAACvIAAEgQAAAoAnAAQAKAAALgEIAAA4QgUAEgXAAQgvAAgSgaQgNgUAAgxIgCAAQgmA6goAYQgvAdhIAAQhRAAgwgmgABjgHIggAHIhVAMQg0AIgeAJQhVAbAABEQAAAxAmAeQAjAdAxAAQBOAAA2gtQA5gxgBhNIAAhVIgCAAQgFALgTAGg");
	this.shape_93.setTransform(-4.1,-81.4,0.13,0.13);

	this.shape_94 = new cjs.Shape();
	this.shape_94.graphics.f("#FFFFFF").s().p("AiFEUIAAofIA9AAIAACAIACAAQAahDAzgjQA2glBJADIAABDQhZgFg3A6Qg5A4AABXIAAEgg");
	this.shape_94.setTransform(-12.7,-81.5,0.13,0.13);

	this.shape_95 = new cjs.Shape();
	this.shape_95.graphics.f("#FFFFFF").s().p("Ai+DLQhDhQAAh7QAAh5BDhQQBHhWB3AAQB4AABHBWQBCBQAAB5QAAB7hCBQQhHBVh4AAQh3AAhHhVgAiOieQgwBBAABdQAABeAwBCQA1BIBZAAQBaAAA2hIQAvhCAAheQAAhdgvhBQg2hJhaAAQhZAAg1BJg");
	this.shape_95.setTransform(-18.7,-81.4,0.13,0.13);

	this.shape_96 = new cjs.Shape();
	this.shape_96.graphics.f("#FFFFFF").s().p("AhQHcIAAg3QAYACAMgBQAkAAAMgXQAKgRAAgnIAApjIBDAAIAAJTQAABGgXAkQgcAthAAAIgugCgAAOlyIAAhrIBDAAIAABrg");
	this.shape_96.setTransform(-24.1,-81.5,0.13,0.13);

	this.shape_97 = new cjs.Shape();
	this.shape_97.graphics.f("#FFFFFF").s().p("Ai4DKQg6hMAAh+QAAh2A6hPQBDhaB4AAQB7AABABgQA5BUgEB9ImiAAQABBUApA7QAxBHBXAAQBGAAAsgnQAogjARhBIBCAAQgWBgg4AwQg7AzhkAAQh5AAhChWgAh6irQgtA2gIBRIFfAAQgDhQgtg3Qgwg8hNAAQhLAAgyA8g");
	this.shape_97.setTransform(-27.9,-81.4,0.13,0.13);

	this.shape_98 = new cjs.Shape();
	this.shape_98.graphics.f("#FFFFFF").s().p("AE2EYIAAlsQAAhGgdghQgfgkhFAAQhQAAglA8QgfAyAABXIAAEyIhBAAIAAlwQABg8gagjQgdgog8AAQhSAAgqA6QgmAzgBBcIAAEuIhCAAIAAofIA9AAIAABcIADAAQA6hsB5AAQA4AAAqAaQAqAdAOA0QAYg0AwgdQAtgaA5AAQC1AAAAC/IAAFwg");
	this.shape_98.setTransform(-36.9,-81.6,0.13,0.13);

	this.shape_99 = new cjs.Shape();
	this.shape_99.graphics.f("#FFFFFF").s().p("Ai7FwIAAg4QAaAFATAAQAoAAAWgYQANgOAUgvIAYg/IjaodIBHAAICxHPICpnPIBCAAIjtJzQgbBHgaAXQgcAYg9AAQgpgBgJgEg");
	this.shape_99.setTransform(-49,-80.1,0.13,0.13);

	this.shape_100 = new cjs.Shape();
	this.shape_100.graphics.f("#FFFFFF").s().p("AjFD6Qg2grAAhOQAAhlBcgkQAugTCZgSQAvgFAQgMQAWgPAAgqQAAg+gqgcQgigWhBAAQhBAAgmAeQgpAhgCBAIhCAAQAEhdA+gvQA5grBiAAQDHAAAACvIAAEgQAAAoAnAAQAKAAALgEIAAA4QgUAEgXAAQgvAAgSgaQgOgVAAgwIgCAAQgmA6gnAYQgvAdhIAAQhRAAgwgmgABDAAIhVAMQg1AIgdAJQhVAbAABEQAAAwAmAfQAjAdAxAAQBNAAA2gtQA6gxgBhNIAAhVIgCAAQgIAQgwAIg");
	this.shape_100.setTransform(87.8,-96.4,0.13,0.13);

	this.shape_101 = new cjs.Shape();
	this.shape_101.graphics.f("#FFFFFF").s().p("AgfEQIjSofIBKAAICpHdIACAAICpndIBFAAIjMIfg");
	this.shape_101.setTransform(81.2,-96.4,0.13,0.13);

	this.shape_102 = new cjs.Shape();
	this.shape_102.graphics.f("#FFFFFF").s().p("Ai4DKQg6hNAAh9QAAh2A6hPQBDhaB4AAQB7AABABgQA5BUgEB9ImiAAQABBUApA7QAxBHBXAAQBGAAAsgnQAogjARhBIBCAAQgWBgg4AwQg7AzhkAAQh5AAhChWgAh6irQgtA2gIBQIFfAAQgDhPgtg3Qgwg8hNAAQhLAAgyA8g");
	this.shape_102.setTransform(74.9,-96.4,0.13,0.13);

	this.shape_103 = new cjs.Shape();
	this.shape_103.graphics.f("#FFFFFF").s().p("AjcBJIAAlgIBDAAIAAFhQACBNAhAjQAiAmBMAAQBPAAAthEQAmg8AAhbIAAkcIBDAAIAAIfIg9AAIAAhiIgCAAQgbA2gyAeQgyAeg7AAQjAAAAAjPg");
	this.shape_103.setTransform(67.9,-96.3,0.13,0.13);

	this.shape_104 = new cjs.Shape();
	this.shape_104.graphics.f("#FFFFFF").s().p("ACbEYIAAlSQAAhOgdgoQgigvhMAAQhLAAgwA1QgtA0gCBSIAAE8IhCAAIAAofIBCAAIAABeIADAAQASgxAxgfQAxgeA5AAQBtAAAvA4QArAyAABoIAAFdg");
	this.shape_104.setTransform(60.9,-96.5,0.13,0.13);

	this.shape_105 = new cjs.Shape();
	this.shape_105.graphics.f("#FFFFFF").s().p("AjFD6Qg2grAAhOQAAhlBcgkQAugTCZgSQAvgFAQgMQAWgPAAgqQAAg+gqgcQgigWhAAAQhCAAglAeQgqAhgBBAIhDAAQAFhdA9gvQA5grBiAAQDHAAAACvIAAEgQAAAoAnAAQALAAAKgEIAAA4QgTAEgYAAQgvAAgSgaQgNgUAAgxIgCAAQgmA6goAYQgvAdhIAAQhRAAgwgmgABDAAIhVAMQg1AIgdAJQhVAbAABEQAAAwAmAfQAjAdAxAAQBOAAA2gtQA5gxgBhNIAAhVIgCAAQgIAQgwAIg");
	this.shape_105.setTransform(50.7,-96.4,0.13,0.13);

	this.shape_106 = new cjs.Shape();
	this.shape_106.graphics.f("#FFFFFF").s().p("ACaEYIAAlSQAAhOgdgoQghgvhNAAQhLAAgvA1QgtA0gCBSIAAE8IhCAAIAAofIBCAAIAABeIACAAQATgxAxgfQAxgeA4AAQBuAAAvA4QArAyAABoIAAFdg");
	this.shape_106.setTransform(43.6,-96.5,0.13,0.13);

	this.shape_107 = new cjs.Shape();
	this.shape_107.graphics.f("#FFFFFF").s().p("AjcBJIAAlgIBDAAIAAFhQACBNAgAjQAiAmBOAAQBOAAAthEQAng8gBhbIAAkcIBDAAIAAIfIg9AAIAAhiIgDAAQgaA2gyAeQgyAeg8AAQi/AAAAjPg");
	this.shape_107.setTransform(36.5,-96.3,0.13,0.13);

	this.shape_108 = new cjs.Shape();
	this.shape_108.graphics.f("#FFFFFF").s().p("ACaEYIAAlSQAAhOgcgoQgjgvhLAAQhMAAguA1QguA0gBBSIAAE8IhDAAIAAofIBDAAIAABeIACAAQASgxAxgfQAxgeA4AAQBtAAAxA4QAqAyAABoIAAFdg");
	this.shape_108.setTransform(26,-96.5,0.13,0.13);

	this.shape_109 = new cjs.Shape();
	this.shape_109.graphics.f("#FFFFFF").s().p("Ai+DLQhDhQAAh7QAAh5BDhQQBHhWB3AAQB4AABHBWQBDBQAAB5QAAB7hDBQQhHBVh4AAQh3AAhHhVgAiOieQgwBBAABdQAABeAwBCQA1BIBZAAQBaAAA1hIQAwhCAAheQAAhdgwhBQg1hJhaAAQhZAAg1BJg");
	this.shape_109.setTransform(18.9,-96.4,0.13,0.13);

	this.shape_110 = new cjs.Shape();
	this.shape_110.graphics.f("#FFFFFF").s().p("AiuDLQhChQAAh7QAAh5BChQQBHhWB3AAQBaAAA7AvQA9AxALBbIhDAAQgOg/glghQgogjg/AAQhZAAg1BJQgvBBAABdQAABeAvBCQA1BIBZAAQA+AAAtgrQAtgsAHhEIBCAAQgNBig8A5Qg9A4hbAAQh3AAhHhVg");
	this.shape_110.setTransform(11.9,-96.4,0.13,0.13);

	this.shape_111 = new cjs.Shape();
	this.shape_111.graphics.f("#FFFFFF").s().p("AiFEUIAAofIA9AAIAACAIACAAQAahDAzgjQA2glBJADIAABDQhZgFg3A6Qg5A4AABXIAAEgg");
	this.shape_111.setTransform(3.4,-96.5,0.13,0.13);

	this.shape_112 = new cjs.Shape();
	this.shape_112.graphics.f("#FFFFFF").s().p("AjFD6Qg2grAAhOQAAhlBcgkQAugTCZgSQAvgFAQgMQAWgPAAgqQAAg+gqgcQgigWhAAAQhCAAglAeQgqAhgBBAIhDAAQAFhdA9gvQA5grBiAAQDHAAAACvIAAEgQAAAoAnAAQAKAAALgEIAAA4QgUAEgXAAQgvAAgSgaQgNgUAAgxIgDAAQgmA6gnAYQgvAdhIAAQhRAAgwgmgABDAAIhVAMQg1AIgdAJQhVAbAABEQAAAwAmAfQAjAdAxAAQBNAAA2gtQA6gxgBhNIAAhVIgCAAQgIAQgwAIg");
	this.shape_112.setTransform(-2.3,-96.4,0.13,0.13);

	this.shape_113 = new cjs.Shape();
	this.shape_113.graphics.f("#FFFFFF").s().p("AgPFLQgZgbAAhFIAAlzIhfAAIAAg5IBfAAIAAikIBBAAIAACkIBvAAIAAA5IhvAAIAAFuQAAAkAJAOQALATAiADQAeAAAbgEIAAA6Ig7ACQhEgBgYgag");
	this.shape_113.setTransform(-7.9,-97.5,0.13,0.13);

	this.shape_114 = new cjs.Shape();
	this.shape_114.graphics.f("#FFFFFF").s().p("ACaEYIAAlSQAAhOgcgoQgigvhMAAQhLAAgwA1QgsA0gCBSIAAE8IhDAAIAAofIBDAAIAABeIACAAQASgxAxgfQAxgeA5AAQBtAAAvA4QArAyAABoIAAFdg");
	this.shape_114.setTransform(-13.1,-96.5,0.13,0.13);

	this.shape_115 = new cjs.Shape();
	this.shape_115.graphics.f("#FFFFFF").s().p("Ai+DLQhChQAAh7QAAh5BChQQBHhWB3AAQB4AABIBWQBCBQgBB5QABB7hCBQQhIBVh4AAQh3AAhHhVgAiOieQgwBBAABdQAABeAwBCQA1BIBZAAQBaAAA1hIQAwhCAAheQAAhdgwhBQg1hJhaAAQhZAAg1BJg");
	this.shape_115.setTransform(-20.2,-96.4,0.13,0.13);

	this.shape_116 = new cjs.Shape();
	this.shape_116.graphics.f("#FFFFFF").s().p("AiuDLQhChQAAh7QAAh5BChQQBHhWB3AAQBaAAA6AvQA+AxALBbIhDAAQgOg/gmghQgngjg/AAQhYAAg1BJQgxBBABBdQgBBeAxBCQA1BIBYAAQA+AAAtgrQAtgsAGhEIBDAAQgOBig7A5Qg9A4hbAAQh3AAhHhVg");
	this.shape_116.setTransform(-27.2,-96.4,0.13,0.13);

	this.shape_117 = new cjs.Shape();
	this.shape_117.graphics.f("#FFFFFF").s().p("Ai4DKQg6hNAAh9QAAh2A6hPQBDhaB4AAQB7AABABgQA5BUgEB9ImiAAQABBUApA7QAxBHBXAAQBGAAAsgnQAogjARhBIBCAAQgWBfg4AxQg7AzhkAAQh5AAhChWgAh6irQgtA2gIBQIFfAAQgDhPgtg3Qgwg8hNAAQhLAAgyA8g");
	this.shape_117.setTransform(-37.5,-96.4,0.13,0.13);

	this.shape_118 = new cjs.Shape();
	this.shape_118.graphics.f("#FFFFFF").s().p("Ai+EqQg8hOAAh7QAAh6A8hPQBDhXB2ABQA+gBAzAfQA2AgAUA5IADAAIAAk5IBCAAIAALxIg9AAIAAhnIgCAAQgVAzg6AjQg3Ahg7AAQh2AAhDhXgAiOg9QgqA/AABfQAABeAqBAQAxBKBYAAQBgAAAzhKQArg+AAhgQAAhhgrg9QgzhJhgAAQhYAAgxBJg");
	this.shape_118.setTransform(-44.9,-97.7,0.13,0.13);

	this.shape_119 = new cjs.Shape();
	this.shape_119.graphics.f("#FFFFFF").s().p("AiYDyQg8gxgIhhIBCAAQAFBBAtAlQArAiBCAAQA4AAArgXQAzgdAAg0QgBgqgkgZQgbgSg4gOIhTgTQhNgSgggbQgsgjAAhAQAAhNBCgpQA5gjBQAAQBWAAA1ArQA6AvADBVIhDAAQgCg7gpgfQgngdg6AAQg1AAgiAUQgrAZAAAxQAAAnAoAZQAaAPAwANIBXAUQBBAKApAgQAxApAABCQAABShIAtQg8AlhXAAQhgAAg6gug");
	this.shape_119.setTransform(91.4,-111.4,0.13,0.13);

	this.shape_120 = new cjs.Shape();
	this.shape_120.graphics.f("#FFFFFF").s().p("Ai+DKQhChQAAh6QAAh6BChQQBHhVB3AAQB4AABHBVQBCBQAAB6QAAB6hCBQQhHBWh4AAQh3AAhHhWgAiOieQgwBBAABdQAABeAwBBQA1BJBZAAQBaAAA1hJQAwhBAAheQAAhdgwhBQg1hJhaAAQhZAAg1BJg");
	this.shape_120.setTransform(84.6,-111.4,0.13,0.13);

	this.shape_121 = new cjs.Shape();
	this.shape_121.graphics.f("#FFFFFF").s().p("AggF5IAAofIBBAAIAAIfgAggkNIAAhrIBBAAIAABrg");
	this.shape_121.setTransform(79.8,-112.8,0.13,0.13);

	this.shape_122 = new cjs.Shape();
	this.shape_122.graphics.f("#FFFFFF").s().p("AiuDKQhChQAAh6QAAh6BChQQBHhVB3AAQBaAAA7AvQA9AxALBbIhDAAQgOg/glghQgogjg/AAQhZAAg1BJQgwBBAABdQAABeAwBBQA1BJBZAAQA+AAAtgrQAtgsAGhEIBDAAQgNBig9A5Qg8A4hbAAQh3AAhHhWg");
	this.shape_122.setTransform(75.4,-111.4,0.13,0.13);

	this.shape_123 = new cjs.Shape();
	this.shape_123.graphics.f("#FFFFFF").s().p("ACEF5IAAofIBDAAIAAIfgAhpF5IAAnoIhdAAIAAg3IBdAAIAAgzQgBhNAbgmQAfgsBJAAQAdAAAbAEIAAA5QgcgFgUAAQgwAAgOAeQgIASgBA6IAAAwIBqAAIAAA3IhqAAIAAHogACEkNIAAhrIBDAAIAABrg");
	this.shape_123.setTransform(68.7,-112.8,0.13,0.13);

	this.shape_124 = new cjs.Shape();
	this.shape_124.graphics.f("#FFFFFF").s().p("Ai4DKQg6hNAAh9QAAh2A6hPQBDhaB4AAQB7AABBBgQA4BUgEB8ImiAAQABBVApA7QAxBHBXAAQBGAAAsgnQAogjARhBIBDAAQgWBfg4AxQg8AzhkAAQh5AAhChWgAh6irQgsA1gJBRIFfAAQgChQgtg3Qgxg7hNAAQhLAAgyA8g");
	this.shape_124.setTransform(62.9,-111.4,0.13,0.13);

	this.shape_125 = new cjs.Shape();
	this.shape_125.graphics.f("#FFFFFF").s().p("ACbEYIAAlSQgBhOgcgoQgigvhMAAQhMAAguA1QguA0gBBSIAAE8IhDAAIAAofIBDAAIAABeIACAAQASgxAxgfQAxgeA5AAQBtAAAvA4QArAyAABoIAAFdg");
	this.shape_125.setTransform(55.9,-111.5,0.13,0.13);

	this.shape_126 = new cjs.Shape();
	this.shape_126.graphics.f("#FFFFFF").s().p("Ai4DKQg6hNAAh9QAAh2A6hPQBDhaB4AAQB7AABABgQA5BUgEB8ImiAAQABBVApA7QAxBHBXAAQBGAAAsgnQAogjARhBIBCAAQgWBfg4AxQg7AzhkAAQh5AAhChWgAh6irQgtA2gIBQIFfAAQgDhQgtg3Qgwg7hNAAQhLAAgyA8g");
	this.shape_126.setTransform(49,-111.4,0.13,0.13);

	this.shape_127 = new cjs.Shape();
	this.shape_127.graphics.f("#FFFFFF").s().p("AhvFhQg0gggYg3IgCAAIAABnIg9AAIAArxIBCAAIAAE5IADAAQAUg4A2ghQAzgeA+AAQB3AABCBWQA8BOAAB6QAAB8g8BPQhCBWh3AAQhBAAg0gggAiNg9QgrA9AABgQAABhArA+QAyBKBhAAQBZAAAwhKQApg/ABhgQgBhfgpg+QgwhJhZgBQhhABgyBJg");
	this.shape_127.setTransform(42,-112.7,0.13,0.13);

	this.shape_128 = new cjs.Shape();
	this.shape_128.graphics.f("#FFFFFF").s().p("AiYDyQg8gxgIhhIBCAAQAEBBAuAlQArAiBCAAQA4AAAqgXQA0gdAAg0QgBgqgkgZQgbgSg4gOIhTgTQhNgSgggbQgsgjAAhAQAAhNBCgpQA5gjBQAAQBWAAA1ArQA6AvADBVIhCAAQgDg7gpgfQgngdg6AAQg1AAgiAUQgrAZAAAxQAAAnAoAZQAaAPAwANIBXAUQBBAKApAgQAxApAABCQAABShIAtQg8AlhXAAQhgAAg6gug");
	this.shape_128.setTransform(31.4,-111.4,0.13,0.13);

	this.shape_129 = new cjs.Shape();
	this.shape_129.graphics.f("#FFFFFF").s().p("Ai+DKQhChQAAh6QAAh6BChQQBHhVB3AAQB4AABIBVQBCBQgBB6QABB6hCBQQhIBWh4AAQh3AAhHhWgAiOieQgwBBAABdQAABeAwBBQA1BJBZAAQBaAAA1hJQAwhBAAheQAAhdgwhBQg1hJhaAAQhZAAg1BJg");
	this.shape_129.setTransform(24.6,-111.4,0.13,0.13);

	this.shape_130 = new cjs.Shape();
	this.shape_130.graphics.f("#FFFFFF").s().p("AggF5IAArxIBBAAIAALxg");
	this.shape_130.setTransform(19.9,-112.8,0.13,0.13);

	this.shape_131 = new cjs.Shape();
	this.shape_131.graphics.f("#FFFFFF").s().p("AjFD6Qg2grAAhPQAAhlBcgjQAtgTCagSQAvgFAQgMQAWgPAAgqQAAg/gqgbQgigWhAAAQhCAAglAeQgqAhgBBAIhDAAQAEhdA+gvQA5grBiAAQDHAAAACvIAAEgQAAAoAnAAQAKAAALgEIAAA4QgUAEgXAAQgvAAgSgaQgNgUAAgxIgDAAQgmA6gnAYQgvAdhIAAQhQAAgxgmgABDAAQh2ANgxAQQhVAaAABFQAAAwAmAfQAjAdAxAAQBNAAA2gtQA6gxgBhNIAAhVIgCAAQgJAQgvAIg");
	this.shape_131.setTransform(12.1,-111.4,0.13,0.13);

	this.shape_132 = new cjs.Shape();
	this.shape_132.graphics.f("#FFFFFF").s().p("ACaF5IAAlUQAAhMgcgoQgigwhMAAQhLABgwA1QgsAzgCBRIAAE+IhDAAIAArxIBDAAIAAEvIACAAQASgwAxgfQAxgeA5AAQBtAAAvA4QArAyAABmIAAFfg");
	this.shape_132.setTransform(5,-112.8,0.13,0.13);

	this.shape_133 = new cjs.Shape();
	this.shape_133.graphics.f("#FFFFFF").s().p("AiuDKQhChQAAh6QAAh6BChQQBHhVB3AAQBaAAA6AvQA+AxALBbIhDAAQgOg/gmghQgngjg/AAQhYAAg1BJQgxBBAABdQAABeAxBBQA0BJBZAAQA+AAAtgrQAtgsAGhEIBDAAQgOBig7A5Qg9A4hbAAQh3AAhHhWg");
	this.shape_133.setTransform(-1.9,-111.4,0.13,0.13);

	this.shape_134 = new cjs.Shape();
	this.shape_134.graphics.f("#FFFFFF").s().p("Ai4DKQg6hNAAh9QAAh2A6hPQBDhaB4AAQB7AABABgQA5BUgEB8ImiAAQABBVApA7QAxBHBXAAQBGAAAsgnQAogjARhBIBCAAQgWBgg4AwQg7AzhkAAQh5AAhChWgAh6irQgtA2gIBQIFfAAQgDhQgtg3Qgwg7hNAAQhLAAgyA8g");
	this.shape_134.setTransform(-8.6,-111.4,0.13,0.13);

	this.shape_135 = new cjs.Shape();
	this.shape_135.graphics.f("#FFFFFF").s().p("AgfEQIjSofIBKAAICpHdIACAAICpndIBFAAIjMIfg");
	this.shape_135.setTransform(-15.1,-111.4,0.13,0.13);

	this.shape_136 = new cjs.Shape();
	this.shape_136.graphics.f("#FFFFFF").s().p("Ai+DKQhChQAAh6QAAh6BChQQBGhVB4AAQB4AABHBVQBDBQAAB6QAAB6hDBQQhHBWh4AAQh4AAhGhWgAiOieQgwBBAABdQAABeAwBBQA1BJBZAAQBaAAA1hJQAvhBABheQgBhdgvhBQg1hJhaAAQhZAAg1BJg");
	this.shape_136.setTransform(-21.8,-111.4,0.13,0.13);

	this.shape_137 = new cjs.Shape();
	this.shape_137.graphics.f("#FFFFFF").s().p("AiGEUIAAofIA+AAIAACAIACAAQAahDAzgjQA3glBIADIAABDQhYgFg4A6Qg4A4AABXIAAEgg");
	this.shape_137.setTransform(-26.7,-111.5,0.13,0.13);

	this.shape_138 = new cjs.Shape();
	this.shape_138.graphics.f("#FFFFFF").s().p("Aj6F9IAArpIA9AAIAABnIACAAQAXg3A1ggQA1ggBAAAQB2AABDBWQA8BPAAB7QAAB6g8BPQhDBWh2AAQg+AAgzgeQg2ghgUg4IgDAAIAAExgAiPj+QgpA6AABoQAABfArA+QAzBKBgAAQBYAAAxhKQAqhAAAhdQAAhfgqg/QgxhKhYAAQhlAAgwBGg");
	this.shape_138.setTransform(-32.8,-110.2,0.13,0.13);

	this.shape_139 = new cjs.Shape();
	this.shape_139.graphics.f("#FFFFFF").s().p("AEHF5IhcjrIlWAAIhbDrIhNAAIEwrxIBPAAIEoLxgAiVBRIEnAAIiSmBg");
	this.shape_139.setTransform(-40.9,-112.8,0.13,0.13);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_139},{t:this.shape_138},{t:this.shape_137},{t:this.shape_136},{t:this.shape_135},{t:this.shape_134},{t:this.shape_133},{t:this.shape_132},{t:this.shape_131},{t:this.shape_130},{t:this.shape_129},{t:this.shape_128},{t:this.shape_127},{t:this.shape_126},{t:this.shape_125},{t:this.shape_124},{t:this.shape_123},{t:this.shape_122},{t:this.shape_121},{t:this.shape_120},{t:this.shape_119},{t:this.shape_118},{t:this.shape_117},{t:this.shape_116},{t:this.shape_115},{t:this.shape_114},{t:this.shape_113},{t:this.shape_112},{t:this.shape_111},{t:this.shape_110},{t:this.shape_109},{t:this.shape_108},{t:this.shape_107},{t:this.shape_106},{t:this.shape_105},{t:this.shape_104},{t:this.shape_103},{t:this.shape_102},{t:this.shape_101},{t:this.shape_100},{t:this.shape_99},{t:this.shape_98},{t:this.shape_97},{t:this.shape_96},{t:this.shape_95},{t:this.shape_94},{t:this.shape_93},{t:this.shape_92},{t:this.shape_91},{t:this.shape_90},{t:this.shape_89},{t:this.shape_88},{t:this.shape_87},{t:this.shape_86},{t:this.shape_85},{t:this.shape_84},{t:this.shape_83},{t:this.shape_82},{t:this.shape_81},{t:this.shape_80},{t:this.shape_79},{t:this.shape_78},{t:this.shape_77},{t:this.shape_76},{t:this.shape_75},{t:this.shape_74},{t:this.shape_73},{t:this.shape_72},{t:this.shape_71},{t:this.shape_70},{t:this.shape_69},{t:this.shape_68},{t:this.shape_67},{t:this.shape_66},{t:this.shape_65},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-69,-117.7,163.3,100);


(lib.Símbolo4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("Am3KEIAA0HIDhAAIAAREIKOAAIAADDg");
	this.shape.setTransform(83,-52.5,0.095,0.095);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AF2KEIh6lVIoAAAIh6FVIjoAAIHv0HIDtAAIHxUHgAjHCEIGHAAIjAopIgEAAg");
	this.shape_1.setTransform(71.6,-52.5,0.095,0.095);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AhwKEIAAxEImZAAIAAjDIQTAAIAADDImaAAIAAREg");
	this.shape_2.setTransform(62.2,-52.5,0.095,0.095);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AhvKEIAA0HIDfAAIAAUHg");
	this.shape_3.setTransform(54.5,-52.5,0.095,0.095);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AmrHbQiki9AAkeQAAkdCki9QCsjIEYAAQDcAACVBvQCfB3AZDTIjdAAQgQh6hhhGQhahBiBAAQjAAAhqCZQhcCGAADLQAADMBcCGQBqCZDAAAQCqACBghgQBcheADimIlXAAIAAiqIIlAAIAAKlIiRAAIgiiYQhZBlhbAqQhYAoh4AAQkYAAisjIg");
	this.shape_4.setTransform(45.3,-52.5,0.095,0.095);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AhwKEIAA0HIDgAAIAAUHg");
	this.shape_5.setTransform(36.4,-52.5,0.095,0.095);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AomKEIAA0HIIWAAQEaAACWC9QCHCrAAEbQAAEdiHCqQiWC9kaAAgAlFHMIDfAAQD0AABmiFQBShsAAjbQAAjahShsQhmiFj0AAIjfAAg");
	this.shape_6.setTransform(28,-52.5,0.095,0.095);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AF2KEIh5lVIoBAAIh5FVIjpAAIHv0HIDuAAIHwUHgAjHCEIGIAAIjBopIgEAAg");
	this.shape_7.setTransform(10.6,-52.5,0.095,0.095);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AiCKEImt0HIDrAAIFDP6IABAAIFLv6IDlAAIm5UHg");
	this.shape_8.setTransform(0.4,-52.5,0.095,0.095);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AhwKEIAA0HIDgAAIAAUHg");
	this.shape_9.setTransform(-7.4,-52.5,0.095,0.095);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AhwKEIAAxEImZAAIAAjDIQSAAIAADDImZAAIAAREg");
	this.shape_10.setTransform(-15,-52.5,0.095,0.095);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("Am3KEIAA0HIDhAAIAAREIKOAAIAADDg");
	this.shape_11.setTransform(-23,-52.5,0.095,0.095);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("Al+IYQiSiCAAjxIAAs4IDiAAIAALuQAACvAqBNQBDB6DBgBQDCABBDh6QAqhNAAivIAAruIDiAAIAAM4QAADxiRCCQiLB8j1AAQjzAAiLh8g");
	this.shape_12.setTransform(-34.9,-52.4,0.095,0.095);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AHGKEIAAvhIgEAAIlmPhIi3AAIlmvhIgEAAIAAPhIjXAAIAA0HIE+AAIFiPvIAEAAIFavvIE7AAIAAUHg");
	this.shape_13.setTransform(-48.9,-52.5,0.095,0.095);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AHBKEIidmRIpJAAIicGRIiDAAIII0HICHAAIH6UHgAj/CLIH5AAIj5qUg");
	this.shape_14.setTransform(33.4,-69.1,0.095,0.095);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AnBKEIAA0HIN5AAIAABoIr9AAIAAHSILNAAIAABnIrNAAIAAH+IMGAAIAABog");
	this.shape_15.setTransform(23.1,-69.1,0.095,0.095);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AFyKEIruxBIgDAAIAARBIh7AAIAA0HICJAAILuRBIADAAIAAxBIB7AAIAAUHg");
	this.shape_16.setTransform(11.4,-69.1,0.095,0.095);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("Ah3M3IAA0HIB5AAIAAUHgAiko3IC8j/ICNAAIjtD/g");
	this.shape_17.setTransform(3.9,-70.8,0.095,0.095);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AmlKEIAA0HIB7AAIAASfILQAAIAABog");
	this.shape_18.setTransform(-2.7,-69.1,0.095,0.095);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-55.2,-78.6,142.4,32.6);


(lib.Símbolo3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#225792").s().p("EgblAyoMAnHhlPIQEAAMgnHBlPg");
	this.shape.setTransform(-32.6,55.9);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-209.2,-268.1,353.3,648.1);


(lib.Símbolo2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#225792").s().p("EgY2AvBMAksheBINBAAMgksBeBg");
	this.shape.setTransform(-67.2,56.5,1.078,1.078);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-238.8,-268,343.3,649.1);


(lib.Símbolo1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.instance = new lib.multiva_fondo_IVR_HB();
	this.instance.setTransform(-397,-249.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-397,-249.5,470,600);


(lib.Símbolo9 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_38 = function() {
		/* Detener en este fotograma
		La línea de tiempo se detendrá/pausará en el fotograma en el que se inserte este código.
		También se puede utilizar para detener/pausar la línea de tiempo de clips de película.
		*/
		
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(38).call(this.frame_38).wait(1));

	// Capa 4
	this.instance = new lib.Símbolo13();
	this.instance.setTransform(-4.2,-38);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(19).to({_off:false},0).to({x:-26.7,alpha:1},19,cjs.Ease.get(1)).wait(1));

	// Capa 2
	this.instance_1 = new lib.Símbolo11();
	this.instance_1.setTransform(0,12.5);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(11).to({_off:false},0).to({alpha:1},19,cjs.Ease.get(1)).wait(9));

	// Capa 3
	this.instance_2 = new lib.Símbolo12();
	this.instance_2.setTransform(-70.9,-59.5);
	this.instance_2.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).to({x:-87.9,y:-11,alpha:1},19,cjs.Ease.get(1)).wait(20));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-89,-94.8,36.2,70.7);


(lib.Símbolo7 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1 copia
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AhCC9IAii9IhFAAIAAi8IDKAAIAACnIg+DSg");
	this.shape.setTransform(139.3,28.3,0.234,0.234);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AjrFcIAAiZIClAAIAACZQAABOBGAAQBHAAABhOIAAiCQgBhSiYhvQiahtAAidIAAhrQAAjwDrAAQDsAAAADwIAACaIikAAIAAiaQgBhMhHgBIAAAAQhHAAABBNIAABoQAABMCYBuQCaBtAACZIAACQQAADxjsAAQjrgBAAjwg");
	this.shape_1.setTransform(128.3,14.9,0.234,0.234);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AjrFcIAAq4QAAjwDrAAQDsAAAADwIAAK4QAADwjsABQjrAAAAjxgAhGlcIAAK4QAABOBGAAQBHAAAAhOIAAq4QAAhMhHgBIAAAAQhGAAAABNg");
	this.shape_2.setTransform(114.2,14.9,0.234,0.234);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("ABII6IiVp/IAAJ/IieAAIAAx0IClAAICZKVIAAqVICZAAIAAR0g");
	this.shape_3.setTransform(99.9,14.9,0.234,0.234);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("ABMI6IiSn2IgVADIAAHzIilAAIAAx0IDwAAQDZACAADvIAACrQAACXiBAuIC5ITgAhbhQIAmAAQAiAAANgFQArgSAAg3IAAirQAAhOhGAAIg6AAg");
	this.shape_4.setTransform(86.2,14.9,0.234,0.234);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AjUI6IAAx0IGpAAIAACjIkFAAIAAFHIDgAAIAAChIjgAAIAAFHIEFAAIAACig");
	this.shape_5.setTransform(72.3,14.9,0.234,0.234);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AjrI6IAAx0ID8AAQDbACAADvIAAKUQAADvjmAAgAhGGYIBGAAQBHAAAAhNIAAqUQAAhOhHAAIhGAAg");
	this.shape_6.setTransform(58.5,14.9,0.234,0.234);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("ABHI6IiUp/IAAJ/IieAAIAAx0ICkAAICbKVIAAqVICYAAIAAR0g");
	this.shape_7.setTransform(44,14.9,0.234,0.234);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AjUI6IAAx0IGpAAIAACjIkEAAIAAFHIDgAAIAAChIjgAAIAAFHIEEAAIAACig");
	this.shape_8.setTransform(30.6,14.9,0.234,0.234);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("ABMI6IiSn2IgVADIAAHzIilAAIAAx0IDwAAQDZACAADvIAACrQAACXiCAuIC6ITgAhbhQIAmAAQAiAAANgFQArgSAAg3IAAirQAAhOhGAAIg6AAg");
	this.shape_9.setTransform(17.4,14.9,0.234,0.234);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AjkI6IAAx0IDtAAQDcACAADvIAACrQAACvidA0QgmAMhGAAIgbAAIAAHpgAg/hQIAmAAQAgAAAMgFQAtgSAAg3IAAirQAAhOhFAAIg6AAg");
	this.shape_10.setTransform(3.2,14.9,0.234,0.234);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("ABMI6IiSn2IgVADIAAHzIilAAIAAx0IDwAAQDZACAADvIAACrQAACXiCAuIC6ITgAhbhQIAmAAQAiAAANgFQArgSAAg3IAAirQAAhOhGAAIg6AAg");
	this.shape_11.setTransform(-10.4,14.9,0.234,0.234);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AjrFcIAAq4QAAjwDrAAQDsAAAADwIAAK4QAADwjsABQjrAAAAjxgAhGlcIAAK4QgBBOBHAAQBIAAAAhOIAAq4QgBhMhHgBIAAAAQhGAAAABNg");
	this.shape_12.setTransform(-25.2,14.9,0.234,0.234);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AjrFcIAAiZIClAAIAACZQgBBOBHAAQBHAAABhOIAAiCQAAhSiZhvQiahsAAieIAAhrQAAjwDrAAQDsAAAADwIAACaIikAAIAAiaQgBhMhHgBIAAAAQhHAAABBNIAABoQAABMCYBuQCaBtAACZIAACQQAADxjsAAQjrgBAAjwg");
	this.shape_13.setTransform(-39.2,14.9,0.234,0.234);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("ABzI6IgfjyIinAAIggDyIimAAIA1mTIB0rhIDgAAIB0LfIA2GVgAg+ClIB8AAIg+nYg");
	this.shape_14.setTransform(-60.3,14.9,0.234,0.234);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("ABMI6IiSn2IgVADIAAHzIilAAIAAx0IDwAAQDaACAADvIAACrQAACXiCAuIC5ITgAhbhQIAmAAQAiAAANgFQArgSAAg3IAAirQAAhOhGAAIg6AAg");
	this.shape_15.setTransform(-73.9,14.9,0.234,0.234);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AjrFcIAAq4QAAjwDrAAQDsAAAADwIAACaIilAAIAAiaQAAhMhHgBIAAAAQhHAAABBNIAAK4QAABOBGAAQBHAAAAhOIAAkLIhRAAIAAihID2AAIAAGsQAADwjsABQjrAAAAjxg");
	this.shape_16.setTransform(-88.7,14.9,0.234,0.234);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AjrFcIAAq4QAAjwDrAAQDsAAAADwIAAK4QAADwjsABQjrAAAAjxgAhGlcIAAK4QAABOBGAAQBHAAAAhOIAAq4QAAhMhHgBIAAAAQhGAAAABNg");
	this.shape_17.setTransform(-102.8,14.9,0.234,0.234);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AjUI6IAAx0IClAAIAAPSIEEAAIAACig");
	this.shape_18.setTransform(-115.3,14.9,0.234,0.234);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AjUI6IAAxzIGpAAIAACiIkFAAIAAFHIDhAAIAAChIjhAAIAAFHIEFAAIAACig");
	this.shape_19.setTransform(137.2,-22.1,0.234,0.234);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("ABNI6IiTn2IgVADIAAHzIikAAIAAxzIDvAAQDaAAAADwIAACsQAACWiDAuIC6ITgAhbhQIAmAAQAiAAANgFQArgSAAg2IAAisQAAhOhGAAIg6AAg");
	this.shape_20.setTransform(124.1,-22.1,0.234,0.234);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("AjkI6IAAxzIDuAAQDbAAAADwIAACsQAACvidAzQgmAMhHAAIgbAAIAAHpgAhAhQIAnAAQAgAAANgFQAsgSABg2IAAisQAAhOhGAAIg7AAg");
	this.shape_21.setTransform(109.8,-22.1,0.234,0.234);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("ADHI6IAAp+IiNJ+IhtAAIiRp+IAAJ+IigAAIAAxzIClAAIDAMMIC/sMIClAAIAARzg");
	this.shape_22.setTransform(92.6,-22.1,0.234,0.234);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFFFFF").s().p("AjUI6IAAxzIGpAAIAACiIkEAAIAAFHIDgAAIAAChIjgAAIAAFHIEEAAIAACig");
	this.shape_23.setTransform(76.4,-22.1,0.234,0.234);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FFFFFF").s().p("AhRI6IAAxzICjAAIAARzg");
	this.shape_24.setTransform(65.9,-22.1,0.234,0.234);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#FFFFFF").s().p("AjrFdIAAiaIClAAIAACaQAABNBGAAQBIAAAAhNIAAiDQAAhSiZhvQiahtAAidIAAhrQAAjwDrABQDsgBAADwIAACZIikAAIAAiZQAAhNhIAAIAAAAQhGgBAABOIAABoQAABLCYBwQCaBsAACZIAACRQAADwjsAAQjrAAAAjwg");
	this.shape_25.setTransform(55.1,-22.1,0.234,0.234);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#FFFFFF").s().p("ABzI6IgfjyIinAAIggDyIimAAIA1mTIB1rgIDfAAIB1LeIA1GVgAg9ClIB7AAIg+nZg");
	this.shape_26.setTransform(34,-22.1,0.234,0.234);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#FFFFFF").s().p("AhaKaIAAxzICiAAIAARzgAhooGIBSiTIB/AAIh2CTg");
	this.shape_27.setTransform(23.3,-24.4,0.234,0.234);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#FFFFFF").s().p("AjrFdIAAq5QAAjwDrABQDsgBAADwIAACZIikAAIAAiZQAAhNhIAAIAAAAQhGgBAABOIAAK5QAABNBGAAQBHAAABhNIAAkNIhRAAIAAihID1AAIAAGuQAADwjsAAQjrAAAAjwg");
	this.shape_28.setTransform(12.3,-22.1,0.234,0.234);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#FFFFFF").s().p("AjrFdIAAq5QAAjwDrABQDsgBAADwIAAK5QAADwjsAAQjrAAAAjwgAhHlcIAAK5QAABNBHAAQBHAAAAhNIAAq5QAAhNhHAAIAAAAQhGgBgBBOg");
	this.shape_29.setTransform(-1.7,-22.1,0.234,0.234);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#FFFFFF").s().p("AjUI6IAAxzICkAAIAAPRIEFAAIAACig");
	this.shape_30.setTransform(-14.3,-22.1,0.234,0.234);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#FFFFFF").s().p("AjrFdIAAq5QAAjwDrABQDsgBAADwIAAK5QAADwjsAAQjrAAAAjwgAhGlcIAAK5QAABNBGAAQBHAAAAhNIAAq5QAAhNhHAAIAAAAQhGgBAABOg");
	this.shape_31.setTransform(-28.1,-22.1,0.234,0.234);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#FFFFFF").s().p("ABII6IiVp/IAAJ/IieAAIAAxzIClAAICZKUIAAqUICZAAIAARzg");
	this.shape_32.setTransform(-42.4,-22.1,0.234,0.234);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#FFFFFF").s().p("AjrFdIAAq5QAAjwDrABQDsgBAADwIAACZIilAAIAAiZQABhNhIAAIAAAAQhHgBAABOIAAK5QAABNBHAAQBHAAAAhNIAAiaIClAAIAACaQAADwjsAAQjrAAAAjwg");
	this.shape_33.setTransform(-56.6,-22.1,0.234,0.234);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#FFFFFF").s().p("AjUI6IAAxzIGpAAIAACiIkEAAIAAFHIDfAAIAAChIjfAAIAAFHIEEAAIAACig");
	this.shape_34.setTransform(-69.7,-22.1,0.234,0.234);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#FFFFFF").s().p("AhRI6IAAvRIiaAAIAAiiIHXAAIAACiIiaAAIAAPRg");
	this.shape_35.setTransform(-82.7,-22.1,0.234,0.234);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#FFFFFF").s().p("AB0I6IghjyIilAAIghDyIimAAIA2mTIB0rgIDgAAIBzLeIA2GVgAg+ClIB8AAIg+nZg");
	this.shape_36.setTransform(-102.9,-22.1,0.234,0.234);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#FFFFFF").s().p("AjUI6IAAxzIClAAIAAPRIEEAAIAACig");
	this.shape_37.setTransform(-115.6,-22.1,0.234,0.234);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#C0E3F7").s().p("Ag4A5IAAhxIBxAAIAABxg");
	this.shape_38.setTransform(136.7,51.1,0.22,0.22);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#C0E3F7").s().p("AiNDSIAAmkQAAiRCNAAQCOAAAACRIAAGkQAACSiOgBQiNABAAiSgAgqjSIAAGkQAAAvAqAAQArAAAAgvIAAmkQAAgugrAAIAAAAQgqAAAAAug");
	this.shape_39.setTransform(130.5,44.8,0.22,0.22);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#C0E3F7").s().p("AiNDSIAAmkQAAiRCNAAQCOAAAACRIAABeIhjAAIAAheQAAgugrAAIAAAAQgqAAAAAuIAAGkQAAAvAqAAQArAAAAgvIAAhcIBjAAIAABcQAACSiOgBQiNABAAiSg");
	this.shape_40.setTransform(122.6,44.8,0.22,0.22);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#C0E3F7").s().p("AArFYIhZmBIAAGBIhgAAIAAqwIBkAAIBcGPIAAmPIBcAAIAAKwg");
	this.shape_41.setTransform(114.4,44.8,0.22,0.22);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#C0E3F7").s().p("ABFFYIgTiSIhjAAIgUCSIhkAAIAgjzIBHm9ICGAAIBGG8IAgD0gAglBkIBLAAIgmkdg");
	this.shape_42.setTransform(106.2,44.8,0.22,0.22);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#C0E3F7").s().p("AiOFYIAAqwICYAAQCEABABCRIAABnQgBBFg2AaQA2AcABBDIAABpQAACQiMAAgAgqD2IAqAAQArAAAAguIAAhpQAAgggbgLQgIgDgSgBIggAAgAgqgwIAgAAQASAAAIgCQAbgMAAghIAAhnQAAgwgrAAIgqAAg");
	this.shape_43.setTransform(98.2,44.8,0.22,0.22);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#C0E3F7").s().p("AAuFYIhYkvIgMACIAAEtIhkAAIAAqwICRAAQCCABAACRIAABnQAABchOAaIBwFBgAg2gwIAWAAQAVAAAIgCQAZgMAAghIAAhnQAAgwgqAAIgiAAg");
	this.shape_44.setTransform(86.5,44.8,0.22,0.22);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#C0E3F7").s().p("AiNDSIAAmkQAAiRCNAAQCOAAAACRIAAGkQAACSiOgBQiNABAAiSgAgqjSIAAGkQAAAvAqAAQArAAAAgvIAAmkQAAgugrAAIAAAAQgqAAAAAug");
	this.shape_45.setTransform(78.1,44.8,0.22,0.22);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#C0E3F7").s().p("AiODNIAAgpIBkAAIAAApQAAAvAqAAQArAAAAgvIAAoqIBjAAIAAIqQABCRiPAAQiNAAgBiRg");
	this.shape_46.setTransform(69.9,44.9,0.22,0.22);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#C0E3F7").s().p("Ah/FYIAAqwID/AAIAABiIicAAIAADGICGAAIAABgIiGAAIAADGICcAAIAABig");
	this.shape_47.setTransform(63.1,44.8,0.22,0.22);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#C0E3F7").s().p("AB4FYIAAmAIhVGAIhBAAIhYmAIAAGAIhhAAIAAqwIBkAAIBzHXIB0nXIBjAAIAAKwg");
	this.shape_48.setTransform(53.5,44.8,0.22,0.22);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#C0E3F7").s().p("AArFYIhZmBIAAGBIhfAAIAAqwIBjAAIBcGPIAAmPIBcAAIAAKwg");
	this.shape_49.setTransform(39.7,44.8,0.22,0.22);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#C0E3F7").s().p("AiODNIAAoqIBkAAIAAIqQAAAvAqAAQArAAAAgvIAAoqIBjAAIAAIqQABCRiPAAQiNAAgBiRg");
	this.shape_50.setTransform(31.5,44.9,0.22,0.22);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#C0E3F7").s().p("AArFYIhZmBIAAGBIhfAAIAAqwIBjAAIBcGPIAAmPIBcAAIAAKwg");
	this.shape_51.setTransform(19.3,44.8,0.22,0.22);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#C0E3F7").s().p("AiAGSIAAqwIEBAAIAABiIidAAIAADEICGAAIAABiIiGAAIAADGICdAAIAABigAg5k4IAzhZIBLAAIhHBZg");
	this.shape_52.setTransform(11.7,43.5,0.22,0.22);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#C0E3F7").s().p("AgwFYIAAqwIBhAAIAAKwg");
	this.shape_53.setTransform(5.7,44.8,0.22,0.22);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#C0E3F7").s().p("AiNFYIAAqwICXAAQCEABAACRIAABnQAABFg2AaQA2AcAABDIAABpQAACQiKAAgAgqD2IAqAAQArAAAAguIAAhpQAAgggbgLQgJgDgSgBIgfAAgAgqgwIAfAAQATAAAIgCQAbgMAAghIAAhnQAAgwgrAAIgqAAg");
	this.shape_54.setTransform(-0.3,44.8,0.22,0.22);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("#C0E3F7").s().p("AB4FYIAAmAIhVGAIhBAAIhYmAIAAGAIhhAAIAAqwIBkAAIBzHXIB0nXIBjAAIAAKwg");
	this.shape_55.setTransform(-10.2,44.8,0.22,0.22);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("#C0E3F7").s().p("ABGFYIgUiSIhjAAIgUCSIhkAAIAgjzIBGm9ICHAAIBGG8IAgD0gAglBkIBKAAIglkdg");
	this.shape_56.setTransform(-20.1,44.8,0.22,0.22);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("#C0E3F7").s().p("AgxFYIAApOIhcAAIAAhiIEcAAIAABiIheAAIAAJOg");
	this.shape_57.setTransform(-27.2,44.8,0.22,0.22);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("#C0E3F7").s().p("Ag4A5IAAhxIBxAAIAABxg");
	this.shape_58.setTransform(136.7,51.1,0.22,0.22);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("#C0E3F7").s().p("AiNDSIAAmkQAAiRCNAAQCOAAAACRIAAGkQAACSiOgBQiNABAAiSgAgqjSIAAGkQAAAvAqAAQArAAAAgvIAAmkQAAgugrAAIAAAAQgqAAAAAug");
	this.shape_59.setTransform(130.5,44.8,0.22,0.22);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("#C0E3F7").s().p("AiNDSIAAmkQAAiRCNAAQCOAAAACRIAABeIhjAAIAAheQAAgugrAAIAAAAQgqAAAAAuIAAGkQAAAvAqAAQArAAAAgvIAAhcIBjAAIAABcQAACSiOgBQiNABAAiSg");
	this.shape_60.setTransform(122.6,44.8,0.22,0.22);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("#C0E3F7").s().p("AArFYIhZmBIAAGBIhgAAIAAqwIBkAAIBcGPIAAmPIBcAAIAAKwg");
	this.shape_61.setTransform(114.4,44.8,0.22,0.22);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("#C0E3F7").s().p("ABFFYIgTiSIhjAAIgUCSIhkAAIAgjzIBHm9ICGAAIBGG8IAgD0gAglBkIBLAAIgmkdg");
	this.shape_62.setTransform(106.2,44.8,0.22,0.22);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("#C0E3F7").s().p("AiOFYIAAqwICYAAQCEABABCRIAABnQgBBFg2AaQA2AcABBDIAABpQAACQiMAAgAgqD2IAqAAQArAAAAguIAAhpQAAgggbgLQgIgDgSgBIggAAgAgqgwIAgAAQASAAAIgCQAbgMAAghIAAhnQAAgwgrAAIgqAAg");
	this.shape_63.setTransform(98.2,44.8,0.22,0.22);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f("#C0E3F7").s().p("AAuFYIhYkvIgMACIAAEtIhkAAIAAqwICRAAQCCABAACRIAABnQAABchOAaIBwFBgAg2gwIAWAAQAVAAAIgCQAZgMAAghIAAhnQAAgwgqAAIgiAAg");
	this.shape_64.setTransform(86.5,44.8,0.22,0.22);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f("#C0E3F7").s().p("AiNDSIAAmkQAAiRCNAAQCOAAAACRIAAGkQAACSiOgBQiNABAAiSgAgqjSIAAGkQAAAvAqAAQArAAAAgvIAAmkQAAgugrAAIAAAAQgqAAAAAug");
	this.shape_65.setTransform(78.1,44.8,0.22,0.22);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f("#C0E3F7").s().p("AiODNIAAgpIBkAAIAAApQAAAvAqAAQArAAAAgvIAAoqIBjAAIAAIqQABCRiPAAQiNAAgBiRg");
	this.shape_66.setTransform(69.9,44.9,0.22,0.22);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f("#C0E3F7").s().p("Ah/FYIAAqwID/AAIAABiIicAAIAADGICGAAIAABgIiGAAIAADGICcAAIAABig");
	this.shape_67.setTransform(63.1,44.8,0.22,0.22);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f("#C0E3F7").s().p("AB4FYIAAmAIhVGAIhBAAIhYmAIAAGAIhhAAIAAqwIBkAAIBzHXIB0nXIBjAAIAAKwg");
	this.shape_68.setTransform(53.5,44.8,0.22,0.22);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f("#C0E3F7").s().p("AArFYIhZmBIAAGBIhfAAIAAqwIBjAAIBcGPIAAmPIBcAAIAAKwg");
	this.shape_69.setTransform(39.7,44.8,0.22,0.22);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f("#C0E3F7").s().p("AiODNIAAoqIBkAAIAAIqQAAAvAqAAQArAAAAgvIAAoqIBjAAIAAIqQABCRiPAAQiNAAgBiRg");
	this.shape_70.setTransform(31.5,44.9,0.22,0.22);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f("#C0E3F7").s().p("AArFYIhZmBIAAGBIhfAAIAAqwIBjAAIBcGPIAAmPIBcAAIAAKwg");
	this.shape_71.setTransform(19.3,44.8,0.22,0.22);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f("#C0E3F7").s().p("AiAGSIAAqwIEBAAIAABiIidAAIAADEICGAAIAABiIiGAAIAADGICdAAIAABigAg5k4IAzhZIBLAAIhHBZg");
	this.shape_72.setTransform(11.7,43.5,0.22,0.22);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f("#C0E3F7").s().p("AgwFYIAAqwIBhAAIAAKwg");
	this.shape_73.setTransform(5.7,44.8,0.22,0.22);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f("#C0E3F7").s().p("AiNFYIAAqwICXAAQCEABAACRIAABnQAABFg2AaQA2AcAABDIAABpQAACQiKAAgAgqD2IAqAAQArAAAAguIAAhpQAAgggbgLQgJgDgSgBIgfAAgAgqgwIAfAAQATAAAIgCQAbgMAAghIAAhnQAAgwgrAAIgqAAg");
	this.shape_74.setTransform(-0.3,44.8,0.22,0.22);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f("#C0E3F7").s().p("AB4FYIAAmAIhVGAIhBAAIhYmAIAAGAIhhAAIAAqwIBkAAIBzHXIB0nXIBjAAIAAKwg");
	this.shape_75.setTransform(-10.2,44.8,0.22,0.22);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f("#C0E3F7").s().p("ABGFYIgUiSIhjAAIgUCSIhkAAIAgjzIBGm9ICHAAIBGG8IAgD0gAglBkIBKAAIglkdg");
	this.shape_76.setTransform(-20.1,44.8,0.22,0.22);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f("#C0E3F7").s().p("AgxFYIAApOIhcAAIAAhiIEcAAIAABiIheAAIAAJOg");
	this.shape_77.setTransform(-27.2,44.8,0.22,0.22);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_77},{t:this.shape_76},{t:this.shape_75},{t:this.shape_74},{t:this.shape_73},{t:this.shape_72},{t:this.shape_71},{t:this.shape_70},{t:this.shape_69},{t:this.shape_68},{t:this.shape_67},{t:this.shape_66},{t:this.shape_65},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	// Layer 1
	this.instance = new lib.Símbolo15();
	this.instance.setTransform(0.1,9.2);
	this.instance.shadow = new cjs.Shadow("#000000",1,1,4);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-126.8,-43.3,276,105);


// stage content:
(lib.multiva_IVR_HB = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgfApIAAhRIA/AAIAABRg");
	this.shape.setTransform(255.1,585.3,0.15,0.15);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AiQC3QgogfAAg6QAAhKBEgaQAhgNBwgOQAigEAMgIQARgLAAgfQAAgugfgUQgZgQgvAAQgwAAgbAWQgfAYgBAvIgxAAQAEhEAtgiQApggBIAAQCSAAAACAIAADTQAAAeAcAAQAKAAAGgEIAAAqQgQADgQAAQgiAAgNgTQgKgQAAgjIgCAAQgcAqgdASQgiAVg1AAQg6AAgkgcgABIgFQgGADgRACQh2AUgEABQg+AUAAAyQAAAjAbAXQAaAVAkAAQA5AAAnghQAqgkAAg4IAAg+IgCAAQgEAIgOAEg");
	this.shape_1.setTransform(250.3,582.9,0.15,0.15);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgWDIIibmPIA3AAIB7FeIACAAIB8leIAzAAIiWGPg");
	this.shape_2.setTransform(244.3,582.9,0.15,0.15);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgXEVIAAmPIAvAAIAAGPgAgXjFIAAhPIAvAAIAABPg");
	this.shape_3.setTransform(240.3,581.8,0.15,0.15);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgKDyQgTgTAAgzIAAkQIhFAAIAAgpIBFAAIAAh4IAvAAIAAB4IBSAAIAAApIhSAAIAAEMQAAAbAHALQAIAOAYABQATAAAYgDIAAAqIgsACQgxAAgRgUg");
	this.shape_4.setTransform(237.1,582,0.15,0.15);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgXEVIAAopIAvAAIAAIpg");
	this.shape_5.setTransform(234.2,581.8,0.15,0.15);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AihA2IAAkCIAxAAIAAEDQABA4AYAaQAaAcA4AAQA5AAAhgyQAcgsAAhDIAAjQIAxAAIAAGOIgtAAIAAhIIgCAAQgTAogkAWQglAVgrAAQiNAAAAiXg");
	this.shape_6.setTransform(229.8,583,0.15,0.15);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("ADXEVIAAneIgBAAIi+HeIgvAAIi+neIgCAAIAAHeIg1AAIAAopIBOAAIC+HkIC/nkIBNAAIAAIpg");
	this.shape_7.setTransform(221.6,581.8,0.15,0.15);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AjMEVIAAopID0AAQBMAAAsAqQAtAqAABLQAABKgtArQgsAnhMAAIi/AAIAADugAiXgEIC0AAQA4AAAhgcQAigeAAg3QAAg4gigeQghgcg4AAIi0AAg");
	this.shape_8.setTransform(209.6,581.8,0.15,0.15);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgZEVIAAn8IjBAAIAAgtIG1AAIAAAtIjBAAIAAH8g");
	this.shape_9.setTransform(202.2,581.8,0.15,0.15);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AjCDIQhChQAAh4QAAh4BChPQBHhYB7AAQB8AABIBYQBBBPAAB4QAAB4hBBQQhIBYh8AAQh7AAhHhYgAidimQgyBDAABjQAABkAyBCQA4BNBlAAQBmAAA5hNQAxhCAAhkQAAhjgxhDQg5hMhmAAQhlAAg4BMg");
	this.shape_10.setTransform(194.4,581.8,0.15,0.15);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("ABxDOIAAj4QAAg5gVgeQgZgjg3AAQg3AAgjAoQghAmgBA8IAADoIgxAAIAAmPIAxAAIAABFIABAAQAOgjAkgXQAkgXAoABQBRAAAjApQAfAlAABMIAAEAg");
	this.shape_11.setTransform(183.3,582.8,0.15,0.15);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AiLCUQgxg6AAhaQAAhZAxg6QA0g/BXAAQBYAAA0A/QAxA6AABZQAABagxA6Qg0A/hYAAQhXAAg0g/gAhoh0QgjAwAABEQAABFAjAwQAnA1BBAAQBCAAAng1QAjgwAAhFQAAhEgjgwQgng1hCAAQhBAAgnA1g");
	this.shape_12.setTransform(176.7,582.9,0.15,0.15);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("Ah/CUQgxg6AAhaQAAhZAxg6QA0g/BXAAQBCAAArAiQAtAkAIBDIgxAAQgWhghbAAQhBAAgnA1QgjAwAABEQAABFAjAwQAnA1BBAAQAtAAAhggQAhggAFgyIAxAAQgKBIgsAqQgsAphDAAQhXAAg0g/g");
	this.shape_13.setTransform(170.2,582.9,0.15,0.15);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AhhDLIAAmPIAtAAIAABeIACAAQASgxAlgaQAogaA2ACIAAAxQhCgEgoArQgqApAAA/IAADUg");
	this.shape_14.setTransform(162,582.9,0.15,0.15);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AiQC3QgogfAAg6QAAhKBEgaQAhgNBwgOQAigEAMgIQARgLAAgfQAAgugfgUQgZgQgvAAQgwAAgbAWQgfAYgBAvIgxAAQAEhEAtgiQApggBIAAQCSAAAACAIAADTQAAAeAcAAQAKAAAGgEIAAAqQgQADgQAAQgiAAgNgTQgKgQAAgjIgCAAQgcAqgdASQgiAVg1AAQg6AAgkgcgABIgFQgGADgRACQh2AUgEABQg+AUAAAyQAAAjAbAXQAaAVAkAAQA5AAAnghQAqgkAAg4IAAg+IgCAAQgEAIgOAEg");
	this.shape_15.setTransform(156.7,582.9,0.15,0.15);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AgKDyQgTgTAAgzIAAkQIhGAAIAAgpIBGAAIAAh4IAvAAIAAB4IBSAAIAAApIhSAAIAAEMQAAAbAHALQAIAOAZABQASAAAYgDIAAAqIgsACQgxAAgRgUg");
	this.shape_16.setTransform(151.5,582,0.15,0.15);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("ABxDOIAAj4QAAg5gVgeQgZgjg3AAQg3AAgjAoQghAmgBA8IAADoIgxAAIAAmPIAxAAIAABFIACAAQANgjAjgXQAlgXAoABQBRAAAjApQAfAlAABMIAAEAg");
	this.shape_17.setTransform(146.5,582.8,0.15,0.15);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AiLCUQgxg6AAhaQAAhZAxg6QA0g/BXAAQBYAAA0A/QAxA6AABZQAABagxA6Qg0A/hYAAQhXAAg0g/gAhoh0QgjAwAABEQAABFAjAwQAnA1BBAAQBCAAAng1QAjgwAAhFQAAhEgjgwQgng1hCAAQhBAAgnA1g");
	this.shape_18.setTransform(139.9,582.9,0.15,0.15);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("Ah/CUQgxg6AAhaQAAhZAxg6QA0g/BWAAQBDAAAqAiQAuAkAIBDIgxAAQgWhghcAAQhAAAgnA1QgjAwAABEQAABFAjAwQAnA1BAAAQAuAAAhggQAhggAFgyIAxAAQgKBIgsAqQgtAphDAAQhWAAg0g/g");
	this.shape_19.setTransform(133.5,582.9,0.15,0.15);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AiHCUQgqg4AAhcQAAhWAqg6QAxhCBXAAQBbAAAvBGQAqA+gDBbIkzAAQABA+AfArQAkA0A+AAQA0AAAggcQAegaAMgwIAxAAQgQBGgpAkQgsAlhKAAQhYAAgwg/gAhah9QggAngHA8IECAAQgCg7ghgoQgkgsg5AAQg2AAglAsg");
	this.shape_20.setTransform(123.7,582.9,0.15,0.15);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("AgXEVIAAopIAvAAIAAIpg");
	this.shape_21.setTransform(119.4,581.8,0.15,0.15);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("AhREDQgngYgRgoIgBAAIAABMIgtAAIAAooIAxAAIAADlIABAAQAPgpAogYQAlgWAtAAQBXAAAxA/QAsA6AABZQAABagsA6QgxA/hXAAQguAAgngXgAhngsQgfAsAABHQAABHAfAtQAlA2BGAAQBBAAAkg2QAegvAAhFQAAhGgegtQgkg2hBAAQhGAAglA2g");
	this.shape_22.setTransform(114.8,581.8,0.15,0.15);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFFFFF").s().p("AiQC3QgogfAAg6QAAhKBEgaQAhgNBwgOQAjgEALgIQARgLAAgfQAAgugfgUQgagQguAAQgwAAgcAWQgeAYgBAvIgxAAQAEhEAtgiQApggBIAAQCSAAAACAIAADTQAAAeAdAAQAIAAAHgEIAAAqQgQADgQAAQgjAAgMgTQgKgQAAgjIgCAAQgbAqgeASQgjAVg0AAQg7AAgjgcgAAxAAQh2AUgEABQg+AUAAAyQAAAjAcAXQAZAVAkAAQA4AAAoghQAqgkAAg4IAAg+IgCAAQgFALgkAGg");
	this.shape_23.setTransform(108.3,582.9,0.15,0.15);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FFFFFF").s().p("AhvCxQgsgkgGhHIAxAAQADAwAhAbQAfAZAxAAQApAAAfgRQAlgVAAgmQAAgfgbgTQgTgMgpgLIg9gOQg3gNgZgTQgggaAAgvQAAg4AxgfQApgZA7AAQA/AAAmAgQArAiACA+IgwAAQgCgrgfgXQgcgVgrAAQgmAAgZAPQgfASAAAkQAAAdAdASQATALAjAJIA/APQAwAIAeAXQAkAeAAAwQAAA8g0AhQgsAbhAAAQhGAAgrgig");
	this.shape_24.setTransform(102.1,582.9,0.15,0.15);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#FFFFFF").s().p("ABxDOIAAj4QAAg5gVgeQgZgjg3AAQg3AAgjAoQghAmgBA8IAADoIgxAAIAAmPIAxAAIAABFIABAAQAOgjAkgXQAkgXAoABQBRAAAjApQAfAlAABMIAAEAg");
	this.shape_25.setTransform(95.9,582.8,0.15,0.15);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#FFFFFF").s().p("AiGCUQgrg4AAhcQAAhWArg6QAwhCBYAAQBaAAAvBGQAqA+gDBbIkyAAQAAA+AfArQAkA0A/AAQAzAAAggcQAegaAMgwIAxAAQgQBGgpAkQgsAlhJAAQhZAAgvg/gAhZh9QghAngGA8IEBAAQgCg7ghgoQgkgsg4AAQg3AAgkAsg");
	this.shape_26.setTransform(89.6,582.9,0.15,0.15);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#FFFFFF").s().p("Ai3EXIAAoiIAtAAIAABMIACAAQAQgoAngYQAngYAuABQBXAAAxA/QAsA6AABaQAABZgsA6QgxA/hXAAQgtAAglgWQgogYgPgqIgBAAIAADggAhpi6QgdArAABMQAABGAfAtQAlA2BGAAQBCAAAjg2QAegvAAhEQAAhFgegwQgjg2hCAAQhJAAgkA0g");
	this.shape_27.setTransform(83.1,583.9,0.15,0.15);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#FFFFFF").s().p("AhuCxQgtgkgGhHIAxAAQADAwAhAbQAgAZAwAAQApAAAfgRQAmgVgBgmQAAgfgbgTQgTgMgqgLIg8gOQg3gNgZgTQgggaAAgvQAAg4AxgfQApgZA7AAQA+AAAoAgQAqAiADA+IgyAAQgBgrgfgXQgcgVgqAAQgnAAgZAPQgfASAAAkQAAAdAdASQASALAkAJIA/APQAwAIAeAXQAkAeAAAwQAAA8g0AhQgtAbg/AAQhHAAgpgig");
	this.shape_28.setTransform(76.6,582.9,0.15,0.15);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#FFFFFF").s().p("AgXEVIAAmPIAvAAIAAGPgAgXjFIAAhPIAvAAIAABPg");
	this.shape_29.setTransform(72.5,581.8,0.15,0.15);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#FFFFFF").s().p("AiLDbQgsg6AAhaQAAhZAsg6QAxg/BXAAQAtAAAlAWQAoAYAPApIABAAIAAjlIAxAAIAAIoIgtAAIAAhMIgBAAQgQAmgqAZQgoAYgrAAQhXAAgxg/gAhogsQgeAtAABGQAABFAeAvQAkA2BBAAQBGAAAlg2QAfgtAAhHQAAhHgfgsQglg2hGAAQhBAAgkA2g");
	this.shape_30.setTransform(67.7,581.8,0.15,0.15);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#FFFFFF").s().p("ABxDOIAAj4QAAg5gVgeQgZgjg3AAQg3AAgjAoQghAmgBA8IAADoIgxAAIAAmPIAxAAIAABFIABAAQAOgjAkgXQAkgXAoABQBRAAAjApQAfAlAABMIAAEAg");
	this.shape_31.setTransform(61.1,582.8,0.15,0.15);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#FFFFFF").s().p("AgXEVIAAmPIAvAAIAAGPgAgXjFIAAhPIAvAAIAABPg");
	this.shape_32.setTransform(56.7,581.8,0.15,0.15);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#FFFFFF").s().p("AhvCxQgsgkgGhHIAxAAQACAwAiAbQAfAZAxAAQApAAAegRQAmgVAAgmQAAgfgbgTQgTgNgpgKIg9gOQg4gNgYgTQgggaAAgvQAAg4AxgfQApgZA6AAQBAAAAmAgQArAiACA+IgxAAQgCgrgegXQgcgVgrAAQglAAgaAPQgfASAAAkQAAAdAdASQASALAkAJIA/APQAwAIAeAXQAkAeAAAwQAAA8g1AhQgrAbhBAAQhGAAgqgig");
	this.shape_33.setTransform(49.1,582.9,0.15,0.15);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#FFFFFF").s().p("AiHCUQgqg4AAhcQAAhWAqg6QAxhCBYAAQBaAAAvBGQAqA+gDBbIkyAAQAAA+AfArQAkA0A/AAQBjAAAahmIAxAAQgQBGgpAkQgsAlhJAAQhZAAgwg/gAhZh9QghAngGA8IEBAAQgCg7ghgoQgkgsg4AAQg3AAgkAsg");
	this.shape_34.setTransform(43.1,582.9,0.15,0.15);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#FFFFFF").s().p("AhvCyQgsgkgGhIIAxAAQADAwAhAbQAfAZAxAAQApAAAfgRQAlgVAAgmQAAgfgbgTQgTgMgqgLIg8gOQg4gNgYgTQgggaAAgvQAAg5AxgeQApgZA6AAQA/AAAnAfQArAjACA/IgxAAQgCgsgegXQgcgVgrAAQgmAAgZAPQgfATAAAjQAAAdAdASQASALAkAJIA/APQAwAIAeAXQAkAdAAAxQAAA8g0AhQgtAchAAAQhGgBgqghg");
	this.shape_35.setTransform(291.3,565,0.15,0.15);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#FFFFFF").s().p("AiGCVQgrg5AAhcQAAhWArg6QAxhCBXAAQBaAAAwBGQApA9gDBcIkyAAQABA+AeArQAkA0A/AAQBjAAAahmIAxAAQgQBGgpAjQgsAnhJAAQhYgBgwg+gAhZh9QghAngGA8IEBAAQgCg7ghgoQgkgsg4AAQg3AAgkAsg");
	this.shape_36.setTransform(285.3,565,0.15,0.15);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#FFFFFF").s().p("ABxDNIAAj3QAAg5gVgeQgZgig3AAQg3AAgiAoQgiAlgBA8IAADnIgxAAIAAmNIAxAAIAABFIABAAQAOglAkgWQAkgWAoAAQBRAAAjApQAfAlAABMIAAD/g");
	this.shape_37.setTransform(278.9,564.9,0.15,0.15);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#FFFFFF").s().p("AiLCVQgxg7AAhaQAAhZAxg6QA0g/BXAAQBYAAA0A/QAxA6AABZQAABagxA7Qg0A+hYABQhXgBg0g+gAhoh0QgjAwAABEQAABFAjAwQAnA1BBAAQBCAAAng1QAjgwAAhFQAAhEgjgwQgng1hCAAQhBAAgnA1g");
	this.shape_38.setTransform(272.3,565,0.15,0.15);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#FFFFFF").s().p("AgXEUIAAmNIAvAAIAAGNgAgXjFIAAhOIAvAAIAABOg");
	this.shape_39.setTransform(267.8,563.8,0.15,0.15);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#FFFFFF").s().p("Ah/CVQgxg7AAhaQAAhZAxg6QA0g/BWAAQBDgBAqAjQAuAlAIBCIgxAAQgVhghdAAQhAAAgnA1QgjAwAABEQAABFAjAwQAnA1BAAAQAuAAAhggQAhggAFgyIAxAAQgKBIgsAqQgtAqhDAAQhWgBg0g+g");
	this.shape_40.setTransform(263.5,565,0.15,0.15);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#FFFFFF").s().p("AiQC3QgogfAAg6QAAhKBEgaQAggNBxgOQAjgEALgIQARgLAAgfQAAgugfgUQgZgQgvAAQgwAAgcAWQgeAYgBAvIgxAAQAEhEAtgjQApgfBIAAQCSgBAACCIAADSQAAAdAdABQAHAAAIgEIAAAqQgNACgTAAQgjABgMgUQgKgOAAgkIgCAAQgbAqgeASQgjAWg0AAQg7AAgjgdgAAxAAIh6AVQg+ATAAAzQAAAkAcAWQAZAVAkAAQA5AAAngiQAqgiAAg6IAAg9IgCAAQgGAMgjAFg");
	this.shape_41.setTransform(257.3,565,0.15,0.15);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#FFFFFF").s().p("AhiDKIAAmOIAtAAIAABeIACAAQATgxAlgaQAogaA1ACIAAAxQhAgEgpArQgpApAAA/IAADTg");
	this.shape_42.setTransform(252.4,564.9,0.15,0.15);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#FFFFFF").s().p("AiHCVQgqg5AAhcQAAhWAqg6QAxhCBYAAQBaAAAvBGQAqA9gDBcIkyAAQAAA+AfArQAkA0A/AAQBjAAAahmIAxAAQghCQiNAAQhZgBgwg+gAhZh9QghAngGA8IEBAAQgCg7ghgoQgkgsg4AAQg3AAgkAsg");
	this.shape_43.setTransform(247,565,0.15,0.15);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#FFFFFF").s().p("Ai3EYIAAojIAtAAIAABMIABAAQASgoAmgYQAmgYAvAAQBXAAAxBAQAsA5AABbQAABZgsA6QgxA/hXAAQgtAAglgWQgogYgPgqIgBAAIAADhgAhoi6QgeArAABMQgBBFAgAuQAlA2BGAAQBBAAAjg2QAfgvAAhEQAAhFgfgvQgjg2hBAAQhJAAgjAzg");
	this.shape_44.setTransform(240.5,566,0.15,0.15);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#FFFFFF").s().p("AiLCVQgxg7AAhaQAAhZAxg6QA0g/BXAAQBYAAA0A/QAxA6AABZQAABagxA7Qg0A+hYABQhXgBg0g+gAhoh0QgjAwAABEQAABFAjAwQAnA1BBAAQBCAAAng1QAjgwAAhFQAAhEgjgwQgng1hCAAQhBAAgnA1g");
	this.shape_45.setTransform(233.6,565,0.15,0.15);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#FFFFFF").s().p("AhvCyQgtgkgFhIIAxAAQADAwAgAbQAgAZAwAAQAqAAAegRQAmgVAAgmQAAgfgbgTQgUgMgogLIg9gOQg4gNgYgTQgggaAAgvQAAg5AxgeQApgZA7AAQA+AAAnAfQArAjACA/IgxAAQgCgrgegYQgcgVgrAAQgmAAgZAPQgfATAAAjQAAAdAdASQATALAjAJIA/APQAwAIAeAXQAkAdAAAxQAAA8g1AhQgrAchAAAQhHgBgqghg");
	this.shape_46.setTransform(223.8,565,0.15,0.15);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#FFFFFF").s().p("AiRC3QgngfAAg6QAAhKBEgaQAggNBxgOQAjgEAMgIQAQgLAAgfQAAgugfgUQgagQguAAQgwAAgbAWQgfAYgBAvIgxAAQADhEAtgjQAqgfBIAAQCRgBAACCIAADSQAAAdAdABQAIAAAIgEIAAAqQgNACgTAAQgjABgNgUQgKgOAAgkIgBAAQgcAqgdASQgjAWg0AAQg6AAglgdgAAxAAIh6AVQg+ATAAAzQAAAkAbAWQAaAVAkAAQA5AAAngiQAqgiAAg6IAAg9IgCAAQgGAMgjAFg");
	this.shape_47.setTransform(217.9,565,0.15,0.15);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#FFFFFF").s().p("AgKDzQgUgUABgzIAAkQIhGAAIAAgpIBGAAIAAh4IAvAAIAAB4IBSAAIAAApIhSAAIAAEMQAAAbAHALQAJANAXACQAYAAATgCIAAAqIgsABQgxAAgRgTg");
	this.shape_48.setTransform(212.7,564.1,0.15,0.15);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#FFFFFF").s().p("AhvCyQgsgkgGhIIAwAAQADAwAhAbQAgAZAwAAQAqAAAegRQAmgVAAgmQAAgfgbgTQgUgMgogLIg9gOQg4gNgYgTQghgaAAgvQAAg5AygeQApgZA6AAQA/AAAnAfQArAjACA/IgxAAQgCgrgfgYQgbgVgrAAQgmAAgaAPQgeATAAAjQAAAcAdATQASALAjAJIBAAPQAvAIAfAXQAkAdAAAxQAAA8g1AhQgrAchBAAQhGgBgqghg");
	this.shape_49.setTransform(208.1,565,0.15,0.15);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#FFFFFF").s().p("AiHCVQgqg5AAhcQAAhWAqg6QAxhCBXAAQBbAAAvBGQAqA9gDBcIkyAAQAAA9AfAsQAkA0A+AAQA0AAAggcQAegaAMgwIAxAAQghCQiOAAQhYgBgwg+gAhZh9QghAngGA8IEBAAQgCg7ghgoQgkgsg5AAQg2AAgkAsg");
	this.shape_50.setTransform(202.1,565,0.15,0.15);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#FFFFFF").s().p("AhhDKIAAmOIAtAAIAABeIABAAQATgxAlgaQAogaA2ACIAAAxQhCgEgoArQgqApAAA/IAADTg");
	this.shape_51.setTransform(193.8,564.9,0.15,0.15);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#FFFFFF").s().p("AiQC3QgogfAAg6QAAhKBEgaQAggNBxgOQAjgEALgIQARgLAAgfQAAgugfgUQgZgQgvAAQgwAAgcAWQgeAYgBAvIgxAAQADhEAugjQApgfBIAAQCSgBAACCIAADSQAAAdAdABQAHAAAIgEIAAAqQgNACgTAAQgiABgNgUQgKgOAAgkIgCAAQgbAqgeASQgjAWg0AAQg7AAgjgdgAAxAAIh6AVQg+ATAAAzQAAAkAcAWQAZAVAkAAQA5AAAngiQAqgiAAg6IAAg9IgCAAQgHAMgiAFg");
	this.shape_52.setTransform(188.5,565,0.15,0.15);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#FFFFFF").s().p("AimDHIAAgnIEEk+IjyAAIAAgoIEwAAIAAAiIkHFDIESAAIAAAog");
	this.shape_53.setTransform(182.4,565,0.15,0.15);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#FFFFFF").s().p("AgXEUIAAmNIAvAAIAAGNgAgXjFIAAhOIAvAAIAABOg");
	this.shape_54.setTransform(178.4,563.8,0.15,0.15);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("#FFFFFF").s().p("AgXEUIAAonIAvAAIAAIng");
	this.shape_55.setTransform(176,563.8,0.15,0.15);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("#FFFFFF").s().p("AiRC3QgngfAAg6QAAhKBEgaQAggNBxgOQAjgEALgIQAQgLABgfQgBgugegUQgagQguAAQgwAAgbAWQgfAYgBAvIgxAAQAEhEAsgjQAqgfBIAAQCRgBAACCIAADSQAAAdAdABQAIAAAIgEIAAAqQgNACgTAAQgiABgOgUQgJgOgBgkIgBAAQgbAqgeASQgiAWg1AAQg6AAglgdgAAxAAQhWAKglALQg9ATgBAzQAAAkAcAWQAaAVAkAAQA4AAAogiQAqgiAAg6IAAg9IgCAAQgGAMgjAFg");
	this.shape_56.setTransform(171.8,565,0.15,0.15);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("#FFFFFF").s().p("AiHCVQgqg5AAhcQAAhWAqg6QAxhCBYAAQBaAAAwBGQApA9gDBcIkyAAQABA+AeArQAkA0A/AAQBjAAAahmIAxAAQgQBGgpAjQgsAnhJAAQhZgBgwg+gAhZh9QghAngGA8IEBAAQgCg7ghgoQgkgsg4AAQg3AAgkAsg");
	this.shape_57.setTransform(165.5,565,0.15,0.15);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("#FFFFFF").s().p("AhhDKIAAmOIAsAAIAABeIACAAQATgxAlgaQAogaA2ACIAAAxQhCgEgoArQgqApAAA/IAADTg");
	this.shape_58.setTransform(160.9,564.9,0.15,0.15);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("#FFFFFF").s().p("AiRC3QgngfAAg6QAAhKBEgaQAggNBxgOQAjgEAMgIQAQgLAAgfQAAgugfgUQgZgQgvAAQgwAAgbAWQgfAYgBAvIgwAAQADhEAtgjQAqgfBIAAQCRgBAACCIAADSQAAAdAcABQAIAAAIgEIAAAqQgNACgSAAQgkABgMgUQgKgOAAgkIgCAAQgcAqgcASQgjAWg0AAQg8AAgkgdgAAxAAQhWAKgkALQg+ATAAAzQAAAkAbAWQAbAVAjAAQA5AAAngiQAqgiAAg6IAAg9IgBAAQgHAMgjAFg");
	this.shape_59.setTransform(152.1,565,0.15,0.15);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("#FFFFFF").s().p("AhhDKIAAmOIAtAAIAABeIABAAQATgxAlgaQAogaA1ACIAAAxQhBgEgoArQgqApAAA/IAADTg");
	this.shape_60.setTransform(147.3,564.9,0.15,0.15);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("#FFFFFF").s().p("AiQC3QgogfAAg6QAAhKBEgaQAggNBxgOQAjgEAMgIQAQgLAAgfQAAgugfgUQgZgQgvAAQgwAAgcAWQgeAYgBAvIgxAAQADhEAugjQApgfBJAAQCRgBAACCIAADSQAAAdAcABQAIAAAIgEIAAAqQgNACgTAAQgjABgMgUQgKgOAAgkIgCAAQgcAqgdASQgjAWgzAAQg8AAgjgdgAAxAAIh6AVQg+ATAAAzQAAAkAbAWQAaAVAkAAQA5AAAngiQAqgiAAg6IAAg9IgCAAQgGAMgjAFg");
	this.shape_61.setTransform(142,565,0.15,0.15);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("#FFFFFF").s().p("AjLEUIAAonID0AAQBKgBAsAqQAtArAABKQAABKgtArQgsAnhKAAIjAAAIAADtgAiXgDIC0AAQA4AAAggcQAjgeAAg4QAAg3gjgeQgggdg4ABIi0AAg");
	this.shape_62.setTransform(135.2,563.8,0.15,0.15);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("#FFFFFF").s().p("AgfAoIAAhQIA/AAIAABQg");
	this.shape_63.setTransform(125.9,567.4,0.15,0.15);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f("#FFFFFF").s().p("AjMEUIAAonID0AAQBMgBAsAqQAtArAABKQAABKgtArQgsAnhMAAIi/AAIAADtgAiXgDIC0AAQA4AAAhgcQAigeAAg4QAAg3gigeQghgdg4ABIi0AAg");
	this.shape_64.setTransform(122.4,563.8,0.15,0.15);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f("#FFFFFF").s().p("AgZEUIAAn6IjBAAIAAgtIG1AAIAAAtIjBAAIAAH6g");
	this.shape_65.setTransform(115.1,563.8,0.15,0.15);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f("#FFFFFF").s().p("AjCDJQhChQABh5QgBh4BChQQBHhXB7AAQB8AABIBXQBABQABB4QgBB5hABQQhIBXh8AAQh7AAhHhXgAieimQgxBDAABjQAABkAxBDQA5BMBlAAQBmAAA4hMQAyhDAAhkQAAhjgyhDQg4hMhmAAQhlAAg5BMg");
	this.shape_66.setTransform(107.3,563.8,0.15,0.15);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f("#FFFFFF").s().p("ABxDNIAAj3QAAg5gVgeQgZgig4AAQg2AAgjAoQghAlgCA8IAADnIgwAAIAAmNIAwAAIAABFIACAAQANglAlgWQAjgWAqAAQBQAAAjApQAfAlAABMIAAD/g");
	this.shape_67.setTransform(96.1,564.9,0.15,0.15);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f("#FFFFFF").s().p("AiLCVQgwg7gBhaQABhZAwg6QA0g/BXAAQBYAAA0A/QAwA6AABZQAABagwA7Qg0A+hYABQhXgBg0g+gAhoh0QgjAwAABEQAABFAjAwQAnA1BBAAQBCAAAng1QAjgwAAhFQAAhEgjgwQgng1hCAAQhBAAgnA1g");
	this.shape_68.setTransform(89.5,565,0.15,0.15);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f("#FFFFFF").s().p("Ah/CVQgxg7AAhaQAAhZAxg6QA0g/BWAAQBDgBAqAjQAuAlAIBCIgxAAQgWhghcAAQhAAAgnA1QgjAwAABEQAABFAjAwQAnA1BAAAQAuAAAhggQAhggAFgyIAxAAQgKBIgsAqQgtAqhDAAQhWgBg0g+g");
	this.shape_69.setTransform(83.1,565,0.15,0.15);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f("#FFFFFF").s().p("AhvCyQgsgkgGhIIAxAAQADAwAhAbQAfAZAxAAQApAAAegRQAmgVAAgmQAAgfgbgTQgTgNgpgKIg9gOQg4gNgYgTQgggaAAgvQAAg5AxgeQApgZA6AAQBAAAAmAfQArAjACA/IgxAAQgCgsgegXQgcgVgrAAQglAAgaAPQgfATAAAjQAAAdAdASQASALAkAJIA/APQAwAIAeAXQAkAdAAAxQAAA8g1AhQgrAchBAAQhFgBgrghg");
	this.shape_70.setTransform(73.5,565,0.15,0.15);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f("#FFFFFF").s().p("AiHCVQgqg5AAhcQAAhWAqg6QAxhCBYAAQBaAAAvBGQAqA9gDBcIkyAAQABA+AeArQAkA0A/AAQBjAAAahmIAxAAQgQBGgpAjQgsAnhJAAQhZgBgwg+gAhZh9QghAngGA8IEBAAQgCg7ghgoQgkgsg4AAQg3AAgkAsg");
	this.shape_71.setTransform(67.5,565,0.15,0.15);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f("#FFFFFF").s().p("ABxDNIAAj3QAAg5gVgeQgZgig3AAQg4AAgiAoQghAlgBA8IAADnIgxAAIAAmNIAxAAIAABFIACAAQANglAjgWQAlgWAoAAQBRAAAjApQAfAlAABMIAAD/g");
	this.shape_72.setTransform(61.1,564.9,0.15,0.15);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f("#FFFFFF").s().p("AiLCVQgxg7AAhaQAAhZAxg6QA0g/BXAAQBYAAA0A/QAxA6AABZQAABagxA7Qg0A+hYABQhXgBg0g+gAhoh0QgjAwAABEQAABFAjAwQAnA1BBAAQBCAAAng1QAjgwAAhFQAAhEgjgwQgng1hCAAQhBAAgnA1g");
	this.shape_73.setTransform(54.5,565,0.15,0.15);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f("#FFFFFF").s().p("AgXEUIAAmNIAvAAIAAGNgAgXjFIAAhOIAvAAIAABOg");
	this.shape_74.setTransform(50,563.8,0.15,0.15);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f("#FFFFFF").s().p("Ah/CVQgxg7AAhaQAAhZAxg6QA0g/BWAAQBDgBAqAjQAuAlAHBCIgwAAQgWhghcAAQhAAAgnA1QgjAwAABEQAABFAjAwQAnA1BAAAQAuAAAhggQAhggAFgyIAxAAQgKBIgsAqQgtAqhDAAQhWgBg0g+g");
	this.shape_75.setTransform(45.7,565,0.15,0.15);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f("#FFFFFF").s().p("AiQC3QgogfAAg6QAAhKBEgaQAhgNBwgOQAigEAMgIQAQgLAAgfQAAgugegUQgagQguAAQgwAAgcAWQgeAYgBAvIgxAAQAEhEAsgjQAqgfBIAAQCRgBAACCIAADSQABAdAdABQAHAAAIgEIAAAqQgNACgTAAQgiABgNgUQgLgOAAgkIgBAAQgbAqgeASQgiAWg1AAQg7AAgjgdgAAxAAIh6AVQg+ATAAAzQAAAkAcAWQAZAVAkAAQA4AAAogiQAqgigBg6IAAg9IgBAAQgHAMgiAFg");
	this.shape_76.setTransform(39.5,565,0.15,0.15);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f("#FFFFFF").s().p("AhhDKIAAmOIAtAAIAABeIACAAQASgxAlgaQAogaA2ACIAAAxQhCgEgoArQgqApAAA/IAADTg");
	this.shape_77.setTransform(34.6,564.9,0.15,0.15);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f("#FFFFFF").s().p("AiHCVQgqg5AAhcQAAhWAqg6QAxhCBXAAQBbAAAvBGQAqA9gDBcIkzAAQABA+AfArQAkA0A+AAQA0AAAggcQAegaAMgwIAxAAQghCQiOAAQhYgBgwg+gAhah9QggAngHA8IECAAQgCg7ghgoQgkgsg5AAQg2AAglAsg");
	this.shape_78.setTransform(29.3,565,0.15,0.15);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.f("#FFFFFF").s().p("Ai3EYIAAojIAtAAIAABMIABAAQARgoAngYQAngYAuAAQBXAAAxBAQAsA5AABbQAABZgsA6QgxA/hXAAQgtAAglgWQgngYgQgqIgBAAIAADhgAhoi6QgeArAABMQAABFAfAuQAlA2BGAAQBBAAAkg2QAegvAAhEQAAhFgegvQgkg2hBAAQhJAAgjAzg");
	this.shape_79.setTransform(22.7,566,0.15,0.15);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.f("#FFFFFF").s().p("AjCDJQhBhQAAh5QAAh4BBhQQBIhXB6AAQB8AABHBXQBCBQAAB4QAAB5hCBQQhHBXh8AAQh6AAhIhXgAidimQgxBDAABjQAABkAxBDQA5BMBkAAQBnAAA4hMQAxhDAAhkQAAhjgxhDQg4hMhnAAQhkAAg5BMg");
	this.shape_80.setTransform(14.7,563.8,0.15,0.15);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.f("#FFFFFF").s().p("AAAAeIg4BOIgagSIA5hMIhZgcIALgdIBZAgIAAhgIAdAAIAABgIBZggIALAdIhcAcIA4BMIgZASg");
	this.shape_81.setTransform(8.1,561.3,0.15,0.15);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_81},{t:this.shape_80},{t:this.shape_79},{t:this.shape_78},{t:this.shape_77},{t:this.shape_76},{t:this.shape_75},{t:this.shape_74},{t:this.shape_73},{t:this.shape_72},{t:this.shape_71},{t:this.shape_70},{t:this.shape_69},{t:this.shape_68},{t:this.shape_67},{t:this.shape_66},{t:this.shape_65},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]},252).wait(171));

	// Layer 1
	this.instance = new lib.Símbolo9();
	this.instance.setTransform(150.7,265.5,0.89,0.89);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(252).to({_off:false},0).wait(171));

	// Layer 1
	this.instance_1 = new lib.Símbolo10();
	this.instance_1.setTransform(149.9,397.7,1.1,1.1);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(252).to({_off:false},0).to({scaleX:0.89,scaleY:0.89,x:150.8,y:395.5,alpha:1},20,cjs.Ease.get(1)).wait(151));

	// Capa 5 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_228 = new cjs.Graphics().p("EgMJAwkMAlqhhHIA6AAMglqBhHg");
	var mask_graphics_229 = new cjs.Graphics().p("EAOqgwgIIjAAMglnBg/IoyACg");
	var mask_graphics_230 = new cjs.Graphics().p("EALEgwcIP5AAMgllBg3IwUACg");
	var mask_graphics_231 = new cjs.Graphics().p("EAHpgwaIW6AAMgljBgwI3iAFg");
	var mask_graphics_232 = new cjs.Graphics().p("EAEYgwXIdlAAMglhBgqI+YAFg");
	var mask_graphics_233 = new cjs.Graphics().p("EABSgwUMAj7AAAMglfBgjMgk6AAGg");
	var mask_graphics_234 = new cjs.Graphics().p("EgBogwRMAp7AAAMglfBgdMgrGAAGg");
	var mask_graphics_235 = new cjs.Graphics().p("EgEbgwPMAvoAAAMglcBgXMgw9AAIg");
	var mask_graphics_236 = new cjs.Graphics().p("EgHDgwNMA1AAAAMglbBgSMg2eAAJg");
	var mask_graphics_237 = new cjs.Graphics().p("EgJhgwLMA6DAAAMglZBgNMg7qAAJg");
	var mask_graphics_238 = new cjs.Graphics().p("EgL1gwIMA+yAAAMglYBgIMhAhAAJg");
	var mask_graphics_239 = new cjs.Graphics().p("EgN+gwHMBDLAAAMglWBgEMhFDAAKg");
	var mask_graphics_240 = new cjs.Graphics().p("EgP9gwFMBHQAAAMglVBgAMhJQAALg");
	var mask_graphics_241 = new cjs.Graphics().p("EgRygwDMBK/AAAMglUBf7MhNFAAMg");
	var mask_graphics_242 = new cjs.Graphics().p("EgTegwCMBObAAAMglTBf4MhQmAANg");
	var mask_graphics_243 = new cjs.Graphics().p("EgU+gwBMBRhAAAMglSBf2MhTzAAMg");
	var mask_graphics_244 = new cjs.Graphics().p("EgWVgv/MBUTAAAMglRBfyMhWqAANg");
	var mask_graphics_245 = new cjs.Graphics().p("EgXhgv+MBWuAAAMglQBfvMhZKAAOg");
	var mask_graphics_246 = new cjs.Graphics().p("EgYjgv9MBY2AAAMglQBftMhbVAAOg");
	var mask_graphics_247 = new cjs.Graphics().p("EgZcgv9MBapAAAMglPBfsMhdLAAOg");
	var mask_graphics_248 = new cjs.Graphics().p("EgaJgv8MBcGAAAMglOBfqMherAAPg");
	var mask_graphics_249 = new cjs.Graphics().p("Egatgv8MBdQAAAMglOBfpMhf3AAPg");
	var mask_graphics_250 = new cjs.Graphics().p("EgbGgv7MBeDAAAMglNBfoMhgsAAPg");
	var mask_graphics_251 = new cjs.Graphics().p("EgbWgv7MBekAAAMglOBfoMhhMAAPg");
	var mask_graphics_252 = new cjs.Graphics().p("Egbbgv7MBeuAAAMglOBfoMhhXAAPg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(228).to({graphics:mask_graphics_228,x:169.1,y:310.8}).wait(1).to({graphics:mask_graphics_229,x:210.7,y:310.5}).wait(1).to({graphics:mask_graphics_230,x:206.7,y:310.2}).wait(1).to({graphics:mask_graphics_231,x:203,y:309.9}).wait(1).to({graphics:mask_graphics_232,x:199.4,y:309.6}).wait(1).to({graphics:mask_graphics_233,x:196,y:309.3}).wait(1).to({graphics:mask_graphics_234,x:192.8,y:309.1}).wait(1).to({graphics:mask_graphics_235,x:189.7,y:308.8}).wait(1).to({graphics:mask_graphics_236,x:186.8,y:308.6}).wait(1).to({graphics:mask_graphics_237,x:184.2,y:308.4}).wait(1).to({graphics:mask_graphics_238,x:181.6,y:308.2}).wait(1).to({graphics:mask_graphics_239,x:179.3,y:308}).wait(1).to({graphics:mask_graphics_240,x:177.1,y:307.8}).wait(1).to({graphics:mask_graphics_241,x:175.1,y:307.7}).wait(1).to({graphics:mask_graphics_242,x:173.3,y:307.5}).wait(1).to({graphics:mask_graphics_243,x:171.6,y:307.4}).wait(1).to({graphics:mask_graphics_244,x:170.1,y:307.3}).wait(1).to({graphics:mask_graphics_245,x:168.8,y:307.2}).wait(1).to({graphics:mask_graphics_246,x:167.7,y:307.1}).wait(1).to({graphics:mask_graphics_247,x:166.7,y:307}).wait(1).to({graphics:mask_graphics_248,x:165.9,y:306.9}).wait(1).to({graphics:mask_graphics_249,x:165.3,y:306.9}).wait(1).to({graphics:mask_graphics_250,x:164.9,y:306.9}).wait(1).to({graphics:mask_graphics_251,x:164.6,y:306.8}).wait(1).to({graphics:mask_graphics_252,x:164.6,y:306.8}).wait(171));

	// Capa 2
	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.f("#225792").s().p("EgXbAu4MAAAhdvMAu2AAAMAAABdvg");
	this.shape_82.setTransform(150,300);
	this.shape_82._off = true;

	this.shape_82.mask = mask;

	this.timeline.addTween(cjs.Tween.get(this.shape_82).wait(228).to({_off:false},0).wait(195));

	// Layer 1
	this.instance_2 = new lib.Símbolo7();
	this.instance_2.setTransform(129.4,86.8,0.875,0.875);
	this.instance_2.alpha = 0;
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(15).to({_off:false},0).to({x:151.3,alpha:1},18).to({x:163.5},219,cjs.Ease.get(1)).to({_off:true},1).wait(170));

	// Layer 1
	this.instance_3 = new lib.Símbolo6();
	this.instance_3.setTransform(135,522.8,0.855,0.855);
	this.instance_3.alpha = 0;
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(145).to({_off:false},0).to({scaleX:1.06,scaleY:1.06,alpha:1},18,cjs.Ease.get(-0.54)).to({_off:true},90).wait(170));

	// Capa 6
	this.instance_4 = new lib.Símbolo8();
	this.instance_4.setTransform(175.3,412.3,1.05,1.05);
	this.instance_4.alpha = 0;
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(129).to({_off:false},0).to({alpha:1},16,cjs.Ease.get(1)).to({_off:true},120).wait(158));

	// Capa 4 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_94 = new cjs.Graphics().p("EgguAwxIGOw5ICJlqMAY4hASID2qCIAQgqINkAAIOkAAIkHKsIr7ejIj5J+IpSXxIiKFqImMQ5g");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:null,x:0,y:0}).wait(94).to({graphics:mask_1_graphics_94,x:224,y:302}).wait(329));

	// Layer 1
	this.instance_5 = new lib.Símbolo5();
	this.instance_5.setTransform(2.4,416.5,0.94,0.94);
	this.instance_5._off = true;

	this.instance_5.mask = mask_1;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(101).to({_off:false},0).to({x:178.5},16,cjs.Ease.get(1)).to({_off:true},136).wait(170));

	// Layer 1
	this.instance_6 = new lib.Símbolo4();
	this.instance_6.setTransform(17.2,330.9,0.94,0.94);
	this.instance_6._off = true;

	this.instance_6.mask = mask_1;

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(94).to({_off:false},0).to({x:205},16,cjs.Ease.get(1)).to({_off:true},143).wait(170));

	// Capa 3
	this.instance_7 = new lib.Símbolo3();
	this.instance_7.setTransform(474.5,-221.1,0.94,0.94);
	this.instance_7._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(74).to({_off:false},0).to({x:288.3,y:250},20,cjs.Ease.get(1)).to({_off:true},159).wait(170));

	// Layer 1
	this.instance_8 = new lib.Símbolo2();
	this.instance_8.setTransform(53.8,720,0.94,0.94);
	this.instance_8._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(74).to({_off:false},0).to({x:237.8,y:250},20,cjs.Ease.get(1)).to({_off:true},159).wait(170));

	// Capa 1
	this.instance_9 = new lib.Símbolo1();
	this.instance_9.setTransform(282,249.6);

	this.timeline.addTween(cjs.Tween.get(this.instance_9).to({x:230,y:250},252,cjs.Ease.get(1)).to({_off:true},1).wait(170));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(35,300,470,600);

})(lib = lib||{}, images = images||{}, createjs = createjs||{}, ss = ss||{});
var lib, images, createjs, ss;